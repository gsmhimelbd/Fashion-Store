<footer class="bg-gray-900 text-white mt-16">
    <div class="max-w-7xl mx-auto px-4 py-12">
        <div class="grid md:grid-cols-4 gap-8">
            <div>
                <h3 class="text-xl font-bold mb-4"><?= htmlspecialchars(getSetting('store_name') ?: 'Fashion Store') ?></h3>
                <p class="text-gray-400">Your premier destination for fashion accessories. Quality products at affordable prices.</p>
            </div>
            <div>
                <h4 class="text-lg font-semibold mb-4">Quick Links</h4>
                <ul class="space-y-2 text-gray-400">
                    <li><a href="shop.php" class="hover:text-white transition">All Products</a></li>
                    <li><a href="shop.php?category=men-collection" class="hover:text-white transition">Men Collection</a></li>
                    <li><a href="shop.php?category=women-collection" class="hover:text-white transition">Women Collection</a></li>
                    <li><a href="shop.php?category=new-arrivals" class="hover:text-white transition">New Arrivals</a></li>
                </ul>
            </div>
            <div>
                <h4 class="text-lg font-semibold mb-4">Contact Info</h4>
                <ul class="space-y-2 text-gray-400">
                    <li><i class="fas fa-phone mr-2"></i><?= htmlspecialchars(getSetting('contact_phone') ?: '01775153740') ?></li>
                    <li><a href="https://wa.me/88<?= htmlspecialchars($whatsapp) ?>" class="hover:text-white transition"><i class="fab fa-whatsapp mr-2"></i><?= htmlspecialchars($whatsapp) ?></a></li>
                    <?php $fb = getSetting('facebook_page'); if ($fb): ?>
                    <li><a href="<?= htmlspecialchars($fb) ?>" class="hover:text-white transition"><i class="fab fa-facebook mr-2"></i>Facebook</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <div>
                <h4 class="text-lg font-semibold mb-4">Payment Methods</h4>
                <ul class="space-y-2 text-gray-400">
                    <li><i class="fas fa-money-bill-wave mr-2"></i>Cash on Delivery</li>
                    <li><span class="text-pink-400 mr-2">bKash</span> <?= htmlspecialchars(getSetting('bkash_number') ?: '') ?></li>
                    <li><span class="text-orange-400 mr-2">Nagad</span> <?= htmlspecialchars(getSetting('nagad_number') ?: '') ?></li>
                    <li><span class="text-red-400 mr-2">Rocket</span> <?= htmlspecialchars(getSetting('rocket_number') ?: '') ?></li>
                </ul>
            </div>
        </div>
        <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($storeName) ?>. All rights reserved.</p>
        </div>
    </div>
</footer>
<script src="assets/js/script.js"></script>
</body>
</html>
