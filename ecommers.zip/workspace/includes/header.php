<?php require_once __DIR__ . '/../config/database.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars(getSetting('store_name') ?: 'Fashion Store') ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {'50': '#eff6ff','100': '#dbeafe','200': '#bfdbfe','300': '#93c5fd','400': '#60a5fa','500': '#3b82f6','600': '#2563eb','700': '#1d4ed8','800': '#1e40af','900': '#1e3a8a'}
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50">
<?php
$storeName = getSetting('store_name') ?: 'Fashion Store';
$whatsapp = getSetting('whatsapp_number') ?: '01775153740';
$categories = getDB()->query("SELECT * FROM categories ORDER BY name");
?>
<nav class="bg-white shadow-md sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4">
        <div class="flex items-center justify-between h-16">
            <a href="index.php" class="text-2xl font-bold text-gray-800"><?= htmlspecialchars($storeName) ?></a>
            <div class="hidden md:flex items-center space-x-8">
                <a href="index.php" class="text-gray-600 hover:text-blue-600 transition">Home</a>
                <a href="shop.php" class="text-gray-600 hover:text-blue-600 transition">Shop</a>
                <a href="contact.php" class="text-gray-600 hover:text-blue-600 transition">Contact</a>
                <a href="cart.php" class="relative text-gray-600 hover:text-blue-600 transition">
                    <i class="fas fa-shopping-cart text-xl"></i>
                    <span id="cart-badge" class="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center <?= getCartCount() > 0 ? '' : 'hidden' ?>"><?= getCartCount() ?></span>
                </a>
            </div>
            <button id="mobile-menu-btn" class="md:hidden text-gray-600">
                <i class="fas fa-bars text-xl"></i>
            </button>
        </div>
        <div id="mobile-menu" class="hidden md:hidden pb-4 space-y-2">
            <a href="index.php" class="block text-gray-600 hover:text-blue-600 py-1">Home</a>
            <a href="shop.php" class="block text-gray-600 hover:text-blue-600 py-1">Shop</a>
            <a href="contact.php" class="block text-gray-600 hover:text-blue-600 py-1">Contact</a>
            <a href="cart.php" class="block text-gray-600 hover:text-blue-600 py-1">Cart (<?= getCartCount() ?>)</a>
        </div>
    </div>
</nav>
<script>
document.getElementById('mobile-menu-btn')?.addEventListener('click', function() {
    document.getElementById('mobile-menu').classList.toggle('hidden');
});
</script>
