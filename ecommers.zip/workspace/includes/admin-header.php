<?php require_once __DIR__ . '/../config/database.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars(getSetting('store_name') ?: 'Fashion Store') ?> - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {'50': '#eff6ff','100': '#dbeafe','200': '#bfdbfe','300': '#93c5fd','400': '#60a5fa','500': '#3b82f6','600': '#2563eb','700': '#1d4ed8','800': '#1e40af','900': '#1e3a8a'}
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50">
<?php
$storeName = getSetting('store_name') ?: 'Fashion Store';
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<div class="flex h-screen overflow-hidden">
    <aside id="sidebar" class="fixed inset-y-0 left-0 z-30 w-64 bg-white shadow-lg transform -translate-x-full md:translate-x-0 transition-transform duration-200 ease-in-out md:static md:inset-auto md:h-screen overflow-y-auto">
        <div class="flex items-center justify-between p-4 border-b">
            <span class="text-lg font-bold text-gray-800"><?= htmlspecialchars($storeName) ?></span>
            <button id="sidebar-close" class="md:hidden text-gray-500 hover:text-gray-700">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
        <nav class="mt-4 px-2 space-y-1">
            <a href="dashboard.php" class="flex items-center px-4 py-3 rounded-lg transition <?= $currentPage === 'dashboard.php' ? 'bg-primary-50 text-primary-600' : 'text-gray-600 hover:bg-gray-100' ?>">
                <i class="fas fa-tachometer-alt w-5"></i>
                <span class="ml-3">Dashboard</span>
            </a>
            <a href="products.php" class="flex items-center px-4 py-3 rounded-lg transition <?= $currentPage === 'products.php' ? 'bg-primary-50 text-primary-600' : 'text-gray-600 hover:bg-gray-100' ?>">
                <i class="fas fa-box w-5"></i>
                <span class="ml-3">Products</span>
            </a>
            <a href="categories.php" class="flex items-center px-4 py-3 rounded-lg transition <?= $currentPage === 'categories.php' ? 'bg-primary-50 text-primary-600' : 'text-gray-600 hover:bg-gray-100' ?>">
                <i class="fas fa-tags w-5"></i>
                <span class="ml-3">Categories</span>
            </a>
            <a href="orders.php" class="flex items-center px-4 py-3 rounded-lg transition <?= $currentPage === 'orders.php' ? 'bg-primary-50 text-primary-600' : 'text-gray-600 hover:bg-gray-100' ?>">
                <i class="fas fa-shopping-cart w-5"></i>
                <span class="ml-3">Orders</span>
            </a>
            <a href="banners.php" class="flex items-center px-4 py-3 rounded-lg transition <?= $currentPage === 'banners.php' ? 'bg-primary-50 text-primary-600' : 'text-gray-600 hover:bg-gray-100' ?>">
                <i class="fas fa-images w-5"></i>
                <span class="ml-3">Banners</span>
            </a>
            <a href="settings.php" class="flex items-center px-4 py-3 rounded-lg transition <?= $currentPage === 'settings.php' ? 'bg-primary-50 text-primary-600' : 'text-gray-600 hover:bg-gray-100' ?>">
                <i class="fas fa-cog w-5"></i>
                <span class="ml-3">Settings</span>
            </a>
            <hr class="my-2 border-gray-200">
            <a href="logout.php" class="flex items-center px-4 py-3 rounded-lg text-red-500 hover:bg-red-50 transition">
                <i class="fas fa-sign-out-alt w-5"></i>
                <span class="ml-3">Logout</span>
            </a>
        </nav>
    </aside>
    <div id="sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-20 hidden md:hidden"></div>
    <div class="flex-1 flex flex-col min-h-screen overflow-y-auto">
        <header class="bg-white shadow-sm px-4 md:px-6 py-3 flex items-center justify-between">
            <div class="flex items-center">
                <button id="sidebar-toggle" class="md:hidden mr-3 text-gray-500 hover:text-gray-700">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <h1 class="text-lg font-semibold text-gray-800 capitalize"><?= str_replace('.php', '', $currentPage) ?></h1>
            </div>
            <div class="flex items-center space-x-3">
                <a href="../index.php" target="_blank" class="text-sm text-gray-500 hover:text-primary-600 transition">
                    <i class="fas fa-external-link-alt mr-1"></i>View Site
                </a>
            </div>
        </header>
        <main class="flex-1 p-4 md:p-6">
<script>
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    const toggleBtn = document.getElementById('sidebar-toggle');
    const closeBtn = document.getElementById('sidebar-close');

    function openSidebar() {
        sidebar.classList.remove('-translate-x-full');
        overlay.classList.remove('hidden');
    }
    function closeSidebar() {
        sidebar.classList.add('-translate-x-full');
        overlay.classList.add('hidden');
    }

    toggleBtn?.addEventListener('click', openSidebar);
    closeBtn?.addEventListener('click', closeSidebar);
    overlay?.addEventListener('click', closeSidebar);
});
</script>
