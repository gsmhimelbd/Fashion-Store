<?php require_once 'includes/header.php'; ?>

<?php
$orderId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db = getDB();

$stmt = $db->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param('i', $orderId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order):
?>

<div class="max-w-7xl mx-auto px-4 py-20 text-center">
    <div class="text-8xl text-gray-300 mb-6"><i class="fas fa-exclamation-circle"></i></div>
    <h1 class="text-4xl font-bold text-gray-800 mb-4">Order Not Found</h1>
    <p class="text-gray-500 mb-8">The order you're looking for doesn't exist.</p>
    <a href="shop.php" class="inline-block bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition font-medium">Continue Shopping</a>
</div>

<?php else:

$itemStmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
$itemStmt->bind_param('i', $orderId);
$itemStmt->execute();
$orderItems = $itemStmt->get_result();

$currency = getCurrency();
$storeName = getSetting('store_name') ?: 'Fashion Store';
$contactPhone = getSetting('contact_phone') ?: '01775153740';
$whatsapp = getSetting('whatsapp_number') ?: '01775153740';
?>

<div class="max-w-3xl mx-auto px-4 py-12">
    <div class="bg-white rounded-xl shadow p-8 text-center">
        <div class="text-6xl text-green-500 mb-4"><i class="fas fa-check-circle"></i></div>
        <h1 class="text-3xl font-bold text-gray-800 mb-2">Order Placed Successfully!</h1>
        <p class="text-gray-500">Thank you for your order. Your order ID is <strong class="text-blue-600">#<?= $order['id'] ?></strong></p>

        <div class="mt-8 text-left bg-gray-50 rounded-lg p-6">
            <h3 class="font-semibold text-gray-800 mb-3">Order Details</h3>
            <div class="space-y-2 text-sm">
                <?php while ($item = $orderItems->fetch_assoc()): ?>
                <div class="flex justify-between">
                    <span class="text-gray-600"><?= htmlspecialchars($item['product_name']) ?> x <?= $item['quantity'] ?></span>
                    <span class="font-semibold"><?= $currency ?><?= number_format($item['price'] * $item['quantity'], 2) ?></span>
                </div>
                <?php endwhile; ?>
                <hr>
                <div class="flex justify-between">
                    <span class="text-gray-600">Subtotal</span>
                    <span class="font-semibold"><?= $currency ?><?= number_format($order['subtotal'], 2) ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-600">Delivery Charge</span>
                    <span class="font-semibold"><?= $currency ?><?= number_format($order['delivery_charge'], 2) ?></span>
                </div>
                <hr>
                <div class="flex justify-between text-lg">
                    <span class="font-bold text-gray-800">Total</span>
                    <span class="font-bold text-blue-600"><?= $currency ?><?= number_format($order['grand_total'], 2) ?></span>
                </div>
            </div>
        </div>

        <div class="mt-6 text-left bg-blue-50 rounded-lg p-6">
            <h3 class="font-semibold text-gray-800 mb-3">Delivery Address</h3>
            <p class="text-gray-600 text-sm">
                <strong><?= htmlspecialchars($order['customer_name']) ?></strong><br>
                Phone: <?= htmlspecialchars($order['phone']) ?><br>
                <?php if ($order['whatsapp']): ?>WhatsApp: <?= htmlspecialchars($order['whatsapp']) ?><br><?php endif; ?>
                <?= htmlspecialchars($order['address']) ?>, <?= htmlspecialchars($order['upazila']) ?>, <?= htmlspecialchars($order['district']) ?>
                <?php if ($order['notes']): ?><br>Notes: <?= htmlspecialchars($order['notes']) ?><?php endif; ?>
            </p>
        </div>

        <div class="mt-8 p-6 bg-green-50 rounded-lg">
            <p class="text-gray-700">Thank you for shopping with <strong><?= htmlspecialchars($storeName) ?></strong>!</p>
            <p class="text-gray-500 text-sm mt-2">We will contact you shortly to confirm your order.</p>
            <?php if ($whatsapp): ?>
            <a href="https://wa.me/88<?= htmlspecialchars($whatsapp) ?>?text=Hello, I have a question about my order #<?= $order['id'] ?>" target="_blank" class="inline-flex items-center gap-2 mt-4 bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 transition">
                <i class="fab fa-whatsapp"></i> Contact via WhatsApp
            </a>
            <?php endif; ?>
        </div>

        <a href="shop.php" class="inline-block mt-8 bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition font-medium">Continue Shopping</a>
    </div>
</div>

<?php endif; ?>
<?php require_once 'includes/footer.php'; ?>
