<?php require_once 'includes/header.php'; ?>

<!-- Hero Banner -->
<section class="bg-gradient-to-r from-blue-600 to-blue-800 text-white">
    <div class="max-w-7xl mx-auto px-4 py-20">
        <?php
        $bannerResult = getDB()->query("SELECT * FROM banners WHERE is_active = 1 LIMIT 1");
        $banner = $bannerResult->fetch_assoc();
        ?>
        <?php if ($banner && $banner['image_path']): ?>
        <div class="relative rounded-xl overflow-hidden" style="height: 400px;">
            <img src="<?= htmlspecialchars($banner['image_path']) ?>" alt="<?= htmlspecialchars($banner['title'] ?? '') ?>" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                <div class="text-center">
                    <h1 class="text-4xl md:text-6xl font-bold mb-4"><?= htmlspecialchars($banner['title'] ?? '') ?></h1>
                    <?php if (!empty($banner['subtitle'])): ?>
                    <p class="text-xl md:text-2xl text-blue-200"><?= htmlspecialchars($banner['subtitle']) ?></p>
                    <?php endif; ?>
                    <a href="shop.php" class="inline-block mt-8 bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-blue-50 transition">Shop Now</a>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="text-center py-12">
            <h1 class="text-4xl md:text-6xl font-bold mb-4">Fashion Accessories</h1>
            <p class="text-xl md:text-2xl text-blue-200 mb-8">Discover the latest trends in fashion accessories</p>
            <a href="shop.php" class="inline-block bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-blue-50 transition">Shop Now</a>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Categories -->
<section class="max-w-7xl mx-auto px-4 py-16">
    <h2 class="text-3xl font-bold text-gray-800 mb-8 text-center">Shop by Category</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <?php
        $catResult = getDB()->query("SELECT * FROM categories ORDER BY name");
        while ($cat = $catResult->fetch_assoc()):
        ?>
        <a href="shop.php?category=<?= htmlspecialchars($cat['slug']) ?>" class="group bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition">
            <div class="h-48 bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                <div class="text-6xl text-blue-400 group-hover:scale-110 transition-transform">
                    <i class="fas fa-tag"></i>
                </div>
            </div>
            <div class="p-6">
                <h3 class="text-xl font-semibold text-gray-800 group-hover:text-blue-600 transition"><?= htmlspecialchars($cat['name']) ?></h3>
                <p class="text-gray-500 mt-2">Browse Collection &rarr;</p>
            </div>
        </a>
        <?php endwhile; ?>
    </div>
</section>

<!-- Featured Products -->
<section class="bg-white py-16">
    <div class="max-w-7xl mx-auto px-4">
        <h2 class="text-3xl font-bold text-gray-800 mb-8 text-center">Featured Products</h2>
        <?php
        $featured = getDB()->query("SELECT p.*, (SELECT image_path FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as image FROM products p WHERE p.is_featured = 1 ORDER BY p.created_at DESC LIMIT 8");
        if ($featured->num_rows > 0):
        ?>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
            <?php while ($row = $featured->fetch_assoc()): ?>
            <div class="bg-gray-50 rounded-xl overflow-hidden shadow hover:shadow-lg transition group">
                <a href="product.php?id=<?= $row['id'] ?>">
                    <div class="h-48 bg-gray-200 flex items-center justify-center overflow-hidden">
                        <?php if ($row['image']): ?>
                        <img src="<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['name']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform">
                        <?php else: ?>
                        <div class="text-gray-400 text-5xl"><i class="fas fa-tshirt"></i></div>
                        <?php endif; ?>
                    </div>
                </a>
                <div class="p-4">
                    <a href="product.php?id=<?= $row['id'] ?>" class="text-gray-800 font-semibold hover:text-blue-600 transition line-clamp-2"><?= htmlspecialchars($row['name']) ?></a>
                    <p class="text-blue-600 font-bold text-lg mt-1"><?= getCurrency() ?><?= number_format($row['price'], 2) ?></p>
                    <button onclick="addToCart(<?= $row['id'] ?>)" class="mt-3 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium">Add to Cart</button>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        <?php else: ?>
        <p class="text-center text-gray-500">No featured products available yet.</p>
        <?php endif; ?>
    </div>
</section>

<!-- New Arrivals -->
<section class="max-w-7xl mx-auto px-4 py-16">
    <h2 class="text-3xl font-bold text-gray-800 mb-8 text-center">New Arrivals</h2>
    <?php
    $newArrivals = getDB()->query("SELECT p.*, (SELECT image_path FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as image FROM products p ORDER BY p.created_at DESC LIMIT 8");
    if ($newArrivals->num_rows > 0):
    ?>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
        <?php while ($row = $newArrivals->fetch_assoc()): ?>
        <div class="bg-white rounded-xl overflow-hidden shadow hover:shadow-lg transition group">
            <a href="product.php?id=<?= $row['id'] ?>">
                <div class="h-48 bg-gray-100 flex items-center justify-center overflow-hidden">
                    <?php if ($row['image']): ?>
                    <img src="<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['name']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform">
                    <?php else: ?>
                    <div class="text-gray-400 text-5xl"><i class="fas fa-tshirt"></i></div>
                    <?php endif; ?>
                </div>
            </a>
            <div class="p-4">
                <a href="product.php?id=<?= $row['id'] ?>" class="text-gray-800 font-semibold hover:text-blue-600 transition line-clamp-2"><?= htmlspecialchars($row['name']) ?></a>
                <p class="text-blue-600 font-bold text-lg mt-1"><?= getCurrency() ?><?= number_format($row['price'], 2) ?></p>
                <button onclick="addToCart(<?= $row['id'] ?>)" class="mt-3 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium">Add to Cart</button>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php else: ?>
    <p class="text-center text-gray-500">No new arrivals yet.</p>
    <?php endif; ?>
</section>

<!-- Why Choose Us -->
<section class="bg-gray-100 py-16">
    <div class="max-w-7xl mx-auto px-4">
        <h2 class="text-3xl font-bold text-gray-800 mb-12 text-center">Why Choose Us</h2>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-white p-6 rounded-xl shadow text-center">
                <div class="text-4xl text-blue-600 mb-4"><i class="fas fa-certificate"></i></div>
                <h3 class="text-lg font-semibold text-gray-800">Quality Products</h3>
                <p class="text-gray-500 mt-2 text-sm">Premium quality accessories with assured satisfaction</p>
            </div>
            <div class="bg-white p-6 rounded-xl shadow text-center">
                <div class="text-4xl text-blue-600 mb-4"><i class="fas fa-truck"></i></div>
                <h3 class="text-lg font-semibold text-gray-800">Fast Delivery</h3>
                <p class="text-gray-500 mt-2 text-sm">Quick delivery across all districts in Bangladesh</p>
            </div>
            <div class="bg-white p-6 rounded-xl shadow text-center">
                <div class="text-4xl text-blue-600 mb-4"><i class="fas fa-undo"></i></div>
                <h3 class="text-lg font-semibold text-gray-800">Easy Returns</h3>
                <p class="text-gray-500 mt-2 text-sm">Hassle-free return policy within 7 days</p>
            </div>
            <div class="bg-white p-6 rounded-xl shadow text-center">
                <div class="text-4xl text-blue-600 mb-4"><i class="fas fa-headset"></i></div>
                <h3 class="text-lg font-semibold text-gray-800">24/7 Support</h3>
                <p class="text-gray-500 mt-2 text-sm">Always here to help with any questions</p>
            </div>
        </div>
    </div>
</section>

<script>
function addToCart(productId) {
    fetch('cart.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=add&product_id=' + productId + '&quantity=1'
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            const badge = document.getElementById('cart-badge');
            badge.textContent = data.count;
            badge.classList.remove('hidden');
            alert('Product added to cart!');
        }
    });
}
</script>

<?php require_once 'includes/footer.php'; ?>
