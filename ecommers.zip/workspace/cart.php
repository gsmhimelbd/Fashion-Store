<?php
require_once 'config/database.php';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $productId = intval($_POST['product_id'] ?? 0);
        $quantity = intval($_POST['quantity'] ?? 1);
        if ($productId > 0 && $quantity > 0) {
            if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
            if (isset($_SESSION['cart'][$productId])) {
                $_SESSION['cart'][$productId] += $quantity;
            } else {
                $_SESSION['cart'][$productId] = $quantity;
            }
        }
        echo json_encode(['success' => true, 'count' => getCartCount()]);
        exit;
    }

    if ($action === 'update') {
        $productId = intval($_POST['product_id'] ?? 0);
        $quantity = intval($_POST['quantity'] ?? 0);
        if ($productId > 0 && isset($_SESSION['cart'][$productId])) {
            if ($quantity > 0) {
                $_SESSION['cart'][$productId] = $quantity;
            } else {
                unset($_SESSION['cart'][$productId]);
            }
        }
        echo json_encode(['success' => true, 'count' => getCartCount()]);
        exit;
    }

    if ($action === 'remove') {
        $productId = intval($_POST['product_id'] ?? 0);
        if ($productId > 0 && isset($_SESSION['cart'][$productId])) {
            unset($_SESSION['cart'][$productId]);
        }
        echo json_encode(['success' => true, 'count' => getCartCount()]);
        exit;
    }
}

// GET request - show cart page
require_once 'includes/header.php';

$items = getCartItems();
$subtotal = 0;
foreach ($items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

$district = $_SESSION['delivery_district'] ?? 'Other';
$deliveryCharge = ($district === 'Tangail') ? (float)(getSetting('delivery_charge_tangail') ?: 50) : (float)(getSetting('delivery_charge_other') ?: 150);
$grandTotal = $subtotal + $deliveryCharge;
$currency = getCurrency();
?>

<div class="max-w-7xl mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-8">Shopping Cart</h1>

    <?php if (empty($items)): ?>
    <div class="text-center py-20">
        <div class="text-7xl text-gray-300 mb-6"><i class="fas fa-shopping-cart"></i></div>
        <h2 class="text-2xl font-semibold text-gray-600 mb-2">Your cart is empty</h2>
        <p class="text-gray-400 mb-6">Looks like you haven't added any products yet</p>
        <a href="shop.php" class="inline-block bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition font-medium">Continue Shopping</a>
    </div>
    <?php else: ?>

    <div class="grid lg:grid-cols-3 gap-8">
        <!-- Cart Items -->
        <div class="lg:col-span-2 space-y-4">
            <?php foreach ($items as $item): ?>
            <div class="bg-white rounded-xl shadow p-4 flex items-center gap-4" id="cart-item-<?= $item['id'] ?>">
                <div class="w-20 h-20 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                    <?php if ($item['image']): ?>
                    <img src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>" class="w-full h-full object-cover">
                    <?php else: ?>
                    <div class="w-full h-full flex items-center justify-center text-gray-400 text-2xl"><i class="fas fa-tshirt"></i></div>
                    <?php endif; ?>
                </div>
                <div class="flex-1 min-w-0">
                    <a href="product.php?id=<?= $item['id'] ?>" class="text-gray-800 font-semibold hover:text-blue-600 transition line-clamp-2"><?= htmlspecialchars($item['name']) ?></a>
                    <p class="text-blue-600 font-bold mt-1"><?= $currency ?><?= number_format($item['price'], 2) ?></p>
                </div>
                <div class="flex items-center border rounded-lg">
                    <button onclick="updateCart(<?= $item['id'] ?>, <?= $item['quantity'] - 1 ?>)" class="px-3 py-1 text-gray-600 hover:bg-gray-100 transition">-</button>
                    <span class="px-4 py-1 border-x text-center min-w-[40px]" id="qty-<?= $item['id'] ?>"><?= $item['quantity'] ?></span>
                    <button onclick="updateCart(<?= $item['id'] ?>, <?= $item['quantity'] + 1 ?>)" class="px-3 py-1 text-gray-600 hover:bg-gray-100 transition">+</button>
                </div>
                <div class="text-right min-w-[80px]">
                    <p class="font-bold text-gray-800" id="subtotal-<?= $item['id'] ?>"><?= $currency ?><?= number_format($item['price'] * $item['quantity'], 2) ?></p>
                </div>
                <button onclick="removeFromCart(<?= $item['id'] ?>)" class="text-red-500 hover:text-red-700 transition p-2">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Cart Summary -->
        <div class="bg-white rounded-xl shadow p-6 h-fit sticky top-24">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Order Summary</h2>

            <div class="space-y-3 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-500">Subtotal</span>
                    <span class="font-semibold" id="cart-subtotal"><?= $currency ?><?= number_format($subtotal, 2) ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Delivery Charge</span>
                    <span class="font-semibold" id="cart-delivery"><?= $currency ?><?= number_format($deliveryCharge, 2) ?></span>
                </div>
                <hr>
                <div class="flex justify-between text-lg">
                    <span class="font-bold text-gray-800">Total</span>
                    <span class="font-bold text-blue-600" id="cart-grand-total"><?= $currency ?><?= number_format($grandTotal, 2) ?></span>
                </div>
            </div>

            <div class="mt-4">
                <label class="text-sm text-gray-500 mb-1 block">Delivery District</label>
                <select id="delivery-district" onchange="updateDelivery()" class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="Tangail" <?= $district === 'Tangail' ? 'selected' : '' ?>>Tangail</option>
                    <option value="Other" <?= $district === 'Other' ? 'selected' : '' ?>>Other District</option>
                </select>
            </div>

            <a href="checkout.php" class="mt-6 block w-full bg-blue-600 text-white text-center py-3 rounded-lg hover:bg-blue-700 transition font-medium">Proceed to Checkout</a>
            <a href="shop.php" class="mt-3 block w-full text-blue-600 text-center py-2 hover:text-blue-800 transition text-sm">Continue Shopping</a>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
function updateCart(productId, qty) {
    if (qty < 0) qty = 0;
    fetch('cart.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=update&product_id=' + productId + '&quantity=' + qty
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            if (qty === 0) {
                document.getElementById('cart-item-' + productId).remove();
            } else {
                document.getElementById('qty-' + productId).textContent = qty;
            }
            const badge = document.getElementById('cart-badge');
            badge.textContent = data.count;
            if (data.count === 0) {
                badge.classList.add('hidden');
                location.reload();
            }
            updateTotals();
        }
    });
}

function removeFromCart(productId) {
    if (!confirm('Remove this item from cart?')) return;
    fetch('cart.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=remove&product_id=' + productId
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            document.getElementById('cart-item-' + productId).remove();
            const badge = document.getElementById('cart-badge');
            badge.textContent = data.count;
            if (data.count === 0) {
                badge.classList.add('hidden');
                location.reload();
            }
            updateTotals();
        }
    });
}

function updateTotals() {
    location.reload();
}

function updateDelivery() {
    const district = document.getElementById('delivery-district').value;
    fetch('cart.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=update_delivery&district=' + district
    })
    .then(() => location.reload());
}
</script>

<?php require_once 'includes/footer.php'; ?>
