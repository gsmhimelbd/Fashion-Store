<?php
require_once __DIR__ . '/../config/database.php';
requireLogin();
include __DIR__ . '/../includes/admin-header.php';

$db = getDB();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $name = trim($_POST['name'] ?? '');
        $slug = !empty($_POST['slug']) ? slugify($_POST['slug']) : slugify($name);
        $id = intval($_POST['id'] ?? 0);

        if ($name) {
            if ($action === 'add') {
                $stmt = $db->prepare("INSERT INTO categories (name, slug) VALUES (?, ?)");
                $stmt->bind_param('ss', $name, $slug);
                if ($stmt->execute()) $success = 'Category added successfully.';
                else $error = 'Failed to add category.';
            } else {
                $stmt = $db->prepare("UPDATE categories SET name = ?, slug = ? WHERE id = ?");
                $stmt->bind_param('ssi', $name, $slug, $id);
                if ($stmt->execute()) $success = 'Category updated successfully.';
                else $error = 'Failed to update category.';
            }
        } else {
            $error = 'Category name is required.';
        }
    } elseif ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        $stmt = $db->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->bind_param('i', $id);
        if ($stmt->execute()) $success = 'Category deleted successfully.';
        else $error = 'Failed to delete category.';
    }
}

$categories = $db->query("SELECT c.*, (SELECT COUNT(*) FROM products WHERE category_id = c.id) as product_count FROM categories c ORDER BY name");
$editCategory = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->bind_param('i', $_GET['edit']);
    $stmt->execute();
    $editCategory = $stmt->get_result()->fetch_assoc();
}
?>
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <div class="lg:col-span-1">
        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4"><?= $editCategory ? 'Edit Category' : 'Add New Category' ?></h2>
            <?php if ($error): ?><div class="bg-red-50 text-red-600 px-4 py-3 rounded-lg mb-4 text-sm"><?= htmlspecialchars($error) ?></div><?php endif; ?>
            <?php if ($success): ?><div class="bg-green-50 text-green-600 px-4 py-3 rounded-lg mb-4 text-sm"><?= htmlspecialchars($success) ?></div><?php endif; ?>
            <form method="POST">
                <input type="hidden" name="action" value="<?= $editCategory ? 'edit' : 'add' ?>">
                <?php if ($editCategory): ?><input type="hidden" name="id" value="<?= $editCategory['id'] ?>"><?php endif; ?>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Category Name</label>
                    <input type="text" name="name" required value="<?= htmlspecialchars($editCategory['name'] ?? '') ?>" class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Slug (auto-generated if empty)</label>
                    <input type="text" name="slug" value="<?= htmlspecialchars($editCategory['slug'] ?? '') ?>" class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition">
                </div>
                <button type="submit" class="w-full bg-primary-600 hover:bg-primary-700 text-white font-medium py-2.5 rounded-lg transition">
                    <i class="fas fa-<?= $editCategory ? 'save' : 'plus' ?> mr-2"></i><?= $editCategory ? 'Update Category' : 'Add Category' ?>
                </button>
                <?php if ($editCategory): ?>
                <a href="categories.php" class="block text-center mt-2 text-sm text-gray-500 hover:text-gray-700"><i class="fas fa-times mr-1"></i>Cancel</a>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <div class="lg:col-span-2">
        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">All Categories</h2>
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead><tr class="border-b bg-gray-50">
                        <th class="py-3 px-4 text-sm font-semibold text-gray-600">ID</th>
                        <th class="py-3 px-4 text-sm font-semibold text-gray-600">Name</th>
                        <th class="py-3 px-4 text-sm font-semibold text-gray-600">Slug</th>
                        <th class="py-3 px-4 text-sm font-semibold text-gray-600">Products</th>
                        <th class="py-3 px-4 text-sm font-semibold text-gray-600">Actions</th>
                    </tr></thead>
                    <tbody>
                        <?php if ($categories->num_rows === 0): ?>
                        <tr><td colspan="5" class="py-8 text-center text-gray-500">No categories yet</td></tr>
                        <?php else: ?>
                        <?php while ($c = $categories->fetch_assoc()): ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="py-3 px-4"><?= $c['id'] ?></td>
                            <td class="py-3 px-4 font-medium"><?= htmlspecialchars($c['name']) ?></td>
                            <td class="py-3 px-4 text-sm text-gray-500"><?= htmlspecialchars($c['slug']) ?></td>
                            <td class="py-3 px-4"><?= $c['product_count'] ?></td>
                            <td class="py-3 px-4">
                                <a href="?edit=<?= $c['id'] ?>" class="text-blue-600 hover:text-blue-800 mr-3"><i class="fas fa-edit"></i></a>
                                <form method="POST" class="inline-block" onsubmit="return confirm('Delete this category?')">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $c['id'] ?>">
                                    <button type="submit" class="text-red-600 hover:text-red-800"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer-admin.php'; ?>
