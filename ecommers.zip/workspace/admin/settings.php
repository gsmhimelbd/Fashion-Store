<?php
require_once __DIR__ . '/../config/database.php';
requireLogin();
include __DIR__ . '/../includes/admin-header.php';

$db = getDB();
$success = '';
$error = '';

$settingsKeys = [
    'store_name' => 'Store Name',
    'contact_phone' => 'Contact Phone',
    'whatsapp_number' => 'WhatsApp Number',
    'delivery_charge_tangail' => 'Delivery Charge (Tangail)',
    'delivery_charge_other' => 'Delivery Charge (Other)',
    'bkash_number' => 'bKash Number',
    'nagad_number' => 'Nagad Number',
    'rocket_number' => 'Rocket Number',
    'facebook_page' => 'Facebook Page URL',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($settingsKeys as $key => $label) {
        $value = trim($_POST[$key] ?? '');
        $stmt = $db->prepare("REPLACE INTO settings (setting_key, setting_value) VALUES (?, ?)");
        $stmt->bind_param('ss', $key, $value);
        $stmt->execute();
    }

    if (!empty($_FILES['logo']['name'])) {
        $logoPath = uploadImage($_FILES['logo'], __DIR__ . '/../uploads/');
        if ($logoPath) {
            $stmt = $db->prepare("REPLACE INTO settings (setting_key, setting_value) VALUES ('logo', ?)");
            $stmt->bind_param('s', $logoPath);
            $stmt->execute();
        }
    }

    $success = 'Settings updated successfully.';
}
?>
<?php if ($error): ?><div class="bg-red-50 text-red-600 px-4 py-3 rounded-lg mb-4"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="bg-green-50 text-green-600 px-4 py-3 rounded-lg mb-4"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="bg-white rounded-xl shadow-sm p-6">
    <h2 class="text-lg font-semibold text-gray-800 mb-6">Site Settings</h2>
    <form method="POST" enctype="multipart/form-data" class="space-y-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <?php foreach ($settingsKeys as $key => $label): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1"><?= htmlspecialchars($label) ?></label>
                <?php if (strpos($key, 'delivery_charge') !== false): ?>
                <input type="number" step="0.01" name="<?= $key ?>" value="<?= htmlspecialchars(getSetting($key) ?: '') ?>" class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none">
                <?php else: ?>
                <input type="text" name="<?= $key ?>" value="<?= htmlspecialchars(getSetting($key) ?: '') ?>" class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none">
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Site Logo</label>
            <?php $logo = getSetting('logo'); if ($logo): ?>
            <img src="../<?= htmlspecialchars($logo) ?>" class="h-20 object-contain mb-2 rounded-lg border">
            <?php endif; ?>
            <input type="file" name="logo" accept="image/*" class="w-full border border-gray-300 rounded-lg px-4 py-2.5 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary-50 file:text-primary-600">
        </div>
        <div class="flex justify-end">
            <button type="submit" class="px-6 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-lg transition"><i class="fas fa-save mr-2"></i> Save Settings</button>
        </div>
    </form>
</div>
<?php include __DIR__ . '/../includes/footer-admin.php'; ?>
