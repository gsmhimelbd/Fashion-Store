<?php
require_once __DIR__ . '/../config/database.php';
requireLogin();
include __DIR__ . '/../includes/admin-header.php';

$db = getDB();
$success = '';
$error = '';
$statusFilter = $_GET['status'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_status') {
        $orderId = intval($_POST['order_id'] ?? 0);
        $newStatus = $_POST['status'] ?? '';
        $allowed = ['pending','confirmed','processing','shipped','delivered','cancelled'];
        if (in_array($newStatus, $allowed)) {
            $stmt = $db->prepare("UPDATE orders SET status = ? WHERE id = ?");
            $stmt->bind_param('si', $newStatus, $orderId);
            $stmt->execute();
            $success = 'Order #' . $orderId . ' status updated to ' . ucfirst($newStatus) . '.';
        }
    } elseif ($action === 'export_csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=orders-export-' . date('Y-m-d') . '.csv');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Order ID', 'Customer Name', 'Phone', 'WhatsApp', 'District', 'Upazila', 'Address', 'Payment Method', 'Payment Number', 'Transaction ID', 'Subtotal', 'Delivery Charge', 'Grand Total', 'Status', 'Order Date']);
        $query = "SELECT * FROM orders" . ($statusFilter ? " WHERE status = '$statusFilter'" : "") . " ORDER BY id DESC";
        $orders = $db->query($query);
        while ($o = $orders->fetch_assoc()) {
            fputcsv($output, [$o['id'], $o['customer_name'], $o['phone'], $o['whatsapp'], $o['district'], $o['upazila'], $o['address'], $o['payment_method'], $o['payment_number'], $o['transaction_id'], $o['subtotal'], $o['delivery_charge'], $o['grand_total'], $o['status'], $o['id']]);
        }
        fclose($output);
        exit;
    }
}

$where = $statusFilter ? "WHERE status = '" . $db->real_escape_string($statusFilter) . "'" : '';
$orders = $db->query("SELECT * FROM orders $where ORDER BY id DESC LIMIT 50");
$statusCounts = $db->query("SELECT status, COUNT(*) as c FROM orders GROUP BY status");
$counts = ['all' => 0, 'pending' => 0, 'confirmed' => 0, 'processing' => 0, 'shipped' => 0, 'delivered' => 0, 'cancelled' => 0];
while ($s = $statusCounts->fetch_assoc()) {
    $counts[$s['status']] = $s['c'];
    $counts['all'] += $s['c'];
}
$tabs = ['all' => 'All', 'pending' => 'Pending', 'confirmed' => 'Confirmed', 'processing' => 'Processing', 'shipped' => 'Shipped', 'delivered' => 'Delivered', 'cancelled' => 'Cancelled'];

$orderDetail = null;
$orderItems = null;
if (isset($_GET['view'])) {
    $stmt = $db->prepare("SELECT * FROM orders WHERE id = ?");
    $stmt->bind_param('i', $_GET['view']);
    $stmt->execute();
    $orderDetail = $stmt->get_result()->fetch_assoc();
    if ($orderDetail) {
        $stmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $stmt->bind_param('i', $orderDetail['id']);
        $stmt->execute();
        $orderItems = $stmt->get_result();
    }
}
?>
<?php if ($error): ?><div class="bg-red-50 text-red-600 px-4 py-3 rounded-lg mb-4"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="bg-green-50 text-green-600 px-4 py-3 rounded-lg mb-4"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="flex flex-wrap items-center justify-between mb-6">
    <div class="flex flex-wrap gap-2">
        <?php foreach ($tabs as $key => $label): ?>
        <a href="?status=<?= $key === 'all' ? '' : $key ?>" class="px-4 py-2 rounded-lg text-sm font-medium transition <?= ($statusFilter === $key || (!$statusFilter && $key === 'all')) ? 'bg-primary-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-100 border' ?>">
            <?= $label ?> (<?= $counts[$key] ?>)
        </a>
        <?php endforeach; ?>
    </div>
    <form method="POST" class="mt-2 sm:mt-0">
        <input type="hidden" name="action" value="export_csv">
        <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition text-sm"><i class="fas fa-file-csv mr-1"></i> Export CSV</button>
    </form>
</div>

<div class="bg-white rounded-xl shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead><tr class="border-b bg-gray-50">
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Order #</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Customer</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Phone</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Total</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Status</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Date</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Actions</th>
            </tr></thead>
            <tbody>
                <?php if ($orders->num_rows === 0): ?>
                <tr><td colspan="7" class="py-8 text-center text-gray-500">No orders found</td></tr>
                <?php else: ?>
                <?php while ($o = $orders->fetch_assoc()): ?>
                <tr class="border-b hover:bg-gray-50">
                    <td class="py-3 px-4 font-medium">#<?= $o['id'] ?></td>
                    <td class="py-3 px-4"><?= htmlspecialchars($o['customer_name']) ?></td>
                    <td class="py-3 px-4 text-sm"><?= htmlspecialchars($o['phone']) ?></td>
                    <td class="py-3 px-4"><?= getCurrency() ?><?= number_format($o['grand_total'], 2) ?></td>
                    <td class="py-3 px-4">
                        <span class="px-2 py-1 text-xs rounded-full <?php
                            $sc = ['pending'=>'bg-yellow-100 text-yellow-700','confirmed'=>'bg-blue-100 text-blue-700','processing'=>'bg-indigo-100 text-indigo-700','shipped'=>'bg-purple-100 text-purple-700','delivered'=>'bg-green-100 text-green-700','cancelled'=>'bg-red-100 text-red-700'];
                            echo $sc[$o['status']] ?? 'bg-gray-100 text-gray-700';
                        ?>"><?= ucfirst($o['status']) ?></span>
                    </td>
                    <td class="py-3 px-4 text-sm text-gray-500"><?= date('d M Y', strtotime($o['id'])) ?></td>
                    <td class="py-3 px-4">
                        <a href="?view=<?= $o['id'] ?>&status=<?= $statusFilter ?>" class="text-primary-600 hover:text-primary-800"><i class="fas fa-eye"></i></a>
                    </td>
                </tr>
                <?php endwhile; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($orderDetail): ?>
<div id="orderModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div class="flex items-center justify-between p-6 border-b">
            <h3 class="text-lg font-semibold">Order #<?= $orderDetail['id'] ?> Details</h3>
            <div class="flex items-center space-x-2">
                <button onclick="window.print()" class="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 text-sm"><i class="fas fa-print mr-1"></i> Print</button>
                <a href="?status=<?= $statusFilter ?>" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times text-xl"></i></a>
            </div>
        </div>
        <div class="p-6 space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold text-gray-800 mb-2">Customer Information</h4>
                    <div class="space-y-1 text-sm text-gray-600">
                        <p><span class="font-medium">Name:</span> <?= htmlspecialchars($orderDetail['customer_name']) ?></p>
                        <p><span class="font-medium">Phone:</span> <?= htmlspecialchars($orderDetail['phone']) ?></p>
                        <p><span class="font-medium">WhatsApp:</span> <?= htmlspecialchars($orderDetail['whatsapp'] ?: 'N/A') ?></p>
                        <p><span class="font-medium">District:</span> <?= htmlspecialchars($orderDetail['district']) ?></p>
                        <p><span class="font-medium">Upazila:</span> <?= htmlspecialchars($orderDetail['upazila']) ?></p>
                        <p><span class="font-medium">Address:</span> <?= htmlspecialchars($orderDetail['address']) ?></p>
                        <p><span class="font-medium">Notes:</span> <?= htmlspecialchars($orderDetail['notes'] ?: 'N/A') ?></p>
                    </div>
                </div>
                <div>
                    <h4 class="font-semibold text-gray-800 mb-2">Payment Information</h4>
                    <div class="space-y-1 text-sm text-gray-600">
                        <p><span class="font-medium">Method:</span> <?= htmlspecialchars(ucfirst($orderDetail['payment_method'])) ?></p>
                        <p><span class="font-medium">Payment Number:</span> <?= htmlspecialchars($orderDetail['payment_number'] ?: 'N/A') ?></p>
                        <p><span class="font-medium">Transaction ID:</span> <?= htmlspecialchars($orderDetail['transaction_id'] ?: 'N/A') ?></p>
                    </div>
                </div>
            </div>

            <div>
                <h4 class="font-semibold text-gray-800 mb-2">Order Items</h4>
                <table class="w-full text-left border rounded-lg">
                    <thead><tr class="bg-gray-50 border-b">
                        <th class="py-2 px-3 text-sm font-semibold text-gray-600">Product</th>
                        <th class="py-2 px-3 text-sm font-semibold text-gray-600">Price</th>
                        <th class="py-2 px-3 text-sm font-semibold text-gray-600">Qty</th>
                        <th class="py-2 px-3 text-sm font-semibold text-gray-600">Total</th>
                    </tr></thead>
                    <tbody>
                        <?php while ($item = $orderItems->fetch_assoc()): ?>
                        <tr class="border-b">
                            <td class="py-2 px-3"><?= htmlspecialchars($item['product_name']) ?></td>
                            <td class="py-2 px-3"><?= getCurrency() ?><?= number_format($item['price'], 2) ?></td>
                            <td class="py-2 px-3"><?= $item['quantity'] ?></td>
                            <td class="py-2 px-3"><?= getCurrency() ?><?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <div class="flex justify-end">
                <div class="w-64 space-y-1 text-sm">
                    <div class="flex justify-between"><span>Subtotal:</span><span><?= getCurrency() ?><?= number_format($orderDetail['subtotal'], 2) ?></span></div>
                    <div class="flex justify-between"><span>Delivery Charge:</span><span><?= getCurrency() ?><?= number_format($orderDetail['delivery_charge'], 2) ?></span></div>
                    <div class="flex justify-between font-bold text-lg border-t pt-1"><span>Grand Total:</span><span><?= getCurrency() ?><?= number_format($orderDetail['grand_total'], 2) ?></span></div>
                </div>
            </div>

            <div class="border-t pt-4">
                <form method="POST" class="flex items-center space-x-3">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="order_id" value="<?= $orderDetail['id'] ?>">
                    <label class="text-sm font-medium text-gray-700">Update Status:</label>
                    <select name="status" class="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 outline-none">
                        <?php foreach (['pending','confirmed','processing','shipped','delivered','cancelled'] as $s): ?>
                        <option value="<?= $s ?>" <?= $s === $orderDetail['status'] ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 text-sm"><i class="fas fa-check mr-1"></i> Update</button>
                </form>
            </div>
        </div>
    </div>
</div>
<script>document.getElementById('orderModal').addEventListener('click', function(e) { if (e.target === this) window.location.href = '?status=<?= $statusFilter ?>'; });</script>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer-admin.php'; ?>
