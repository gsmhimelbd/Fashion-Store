<?php
require_once __DIR__ . '/../config/database.php';
requireLogin();
include __DIR__ . '/../includes/admin-header.php';

$db = getDB();
$error = '';
$success = '';
const BANNER_DIR = __DIR__ . '/../uploads/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $id = intval($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $subtitle = trim($_POST['subtitle'] ?? '');
        $is_active = isset($_POST['is_active']) ? 1 : 0;

        $existingImage = '';
        if ($action === 'edit') {
            $stmt = $db->prepare("SELECT image_path FROM banners WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $existingImage = ($stmt->get_result()->fetch_assoc())['image_path'] ?? '';
        }

        $imagePath = $existingImage;
        if (!empty($_FILES['image']['name'])) {
            $uploaded = uploadImage($_FILES['image'], BANNER_DIR);
            if ($uploaded) $imagePath = $uploaded;
            else $error = 'Failed to upload image.';
        }

        if (!$error) {
            if ($action === 'add') {
                $stmt = $db->prepare("INSERT INTO banners (image_path, title, subtitle, is_active) VALUES (?, ?, ?, ?)");
                $stmt->bind_param('sssi', $imagePath, $title, $subtitle, $is_active);
                if ($stmt->execute()) $success = 'Banner added successfully.';
                else $error = 'Failed to add banner.';
            } else {
                $stmt = $db->prepare("UPDATE banners SET image_path = ?, title = ?, subtitle = ?, is_active = ? WHERE id = ?");
                $stmt->bind_param('sssii', $imagePath, $title, $subtitle, $is_active, $id);
                if ($stmt->execute()) $success = 'Banner updated successfully.';
                else $error = 'Failed to update banner.';
            }
        }
    } elseif ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        $stmt = $db->prepare("DELETE FROM banners WHERE id = ?");
        $stmt->bind_param('i', $id);
        if ($stmt->execute()) $success = 'Banner deleted successfully.';
        else $error = 'Failed to delete banner.';
    } elseif ($action === 'toggle') {
        $id = intval($_POST['id'] ?? 0);
        $db->query("UPDATE banners SET is_active = NOT is_active WHERE id = $id");
        $success = 'Banner status toggled.';
    }
}

$banners = $db->query("SELECT * FROM banners ORDER BY id DESC");
$editBanner = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM banners WHERE id = ?");
    $stmt->bind_param('i', $_GET['edit']);
    $stmt->execute();
    $editBanner = $stmt->get_result()->fetch_assoc();
}
?>
<?php if ($error): ?><div class="bg-red-50 text-red-600 px-4 py-3 rounded-lg mb-4"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="bg-green-50 text-green-600 px-4 py-3 rounded-lg mb-4"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <div class="lg:col-span-1">
        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4"><?= $editBanner ? 'Edit Banner' : 'Add New Banner' ?></h2>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="<?= $editBanner ? 'edit' : 'add' ?>">
                <?php if ($editBanner): ?><input type="hidden" name="id" value="<?= $editBanner['id'] ?>"><?php endif; ?>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Banner Image</label>
                    <?php if ($editBanner && $editBanner['image_path']): ?>
                    <img src="../<?= htmlspecialchars($editBanner['image_path']) ?>" class="w-full h-32 object-cover rounded-lg mb-2">
                    <?php endif; ?>
                    <input type="file" name="image" accept="image/*" class="w-full border border-gray-300 rounded-lg px-4 py-2.5 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary-50 file:text-primary-600">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Title</label>
                    <input type="text" name="title" value="<?= htmlspecialchars($editBanner['title'] ?? '') ?>" class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-primary-500 outline-none">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Subtitle</label>
                    <input type="text" name="subtitle" value="<?= htmlspecialchars($editBanner['subtitle'] ?? '') ?>" class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-primary-500 outline-none">
                </div>
                <div class="mb-4">
                    <label class="flex items-center space-x-2 cursor-pointer">
                        <input type="checkbox" name="is_active" <?= ($editBanner && $editBanner['is_active']) || !$editBanner ? 'checked' : '' ?> class="rounded border-gray-300 text-primary-600 focus:ring-primary-500">
                        <span class="text-sm text-gray-700">Active</span>
                    </label>
                </div>
                <button type="submit" class="w-full bg-primary-600 hover:bg-primary-700 text-white font-medium py-2.5 rounded-lg transition">
                    <i class="fas fa-<?= $editBanner ? 'save' : 'plus' ?> mr-2"></i><?= $editBanner ? 'Update Banner' : 'Add Banner' ?>
                </button>
                <?php if ($editBanner): ?>
                <a href="banners.php" class="block text-center mt-2 text-sm text-gray-500 hover:text-gray-700"><i class="fas fa-times mr-1"></i>Cancel</a>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <div class="lg:col-span-2">
        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">All Banners</h2>
            <div class="space-y-4">
                <?php if ($banners->num_rows === 0): ?>
                <p class="text-center text-gray-500 py-8">No banners yet</p>
                <?php else: ?>
                <?php while ($b = $banners->fetch_assoc()): ?>
                <div class="flex items-center space-x-4 p-4 border rounded-lg hover:bg-gray-50 transition">
                    <img src="../<?= htmlspecialchars($b['image_path']) ?>" class="w-24 h-16 object-cover rounded-lg flex-shrink-0">
                    <div class="flex-1 min-w-0">
                        <p class="font-medium text-gray-800"><?= htmlspecialchars($b['title'] ?: 'Untitled') ?></p>
                        <p class="text-sm text-gray-500 truncate"><?= htmlspecialchars($b['subtitle'] ?: '') ?></p>
                        <span class="inline-block mt-1 text-xs px-2 py-0.5 rounded-full <?= $b['is_active'] ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500' ?>"><?= $b['is_active'] ? 'Active' : 'Inactive' ?></span>
                    </div>
                    <div class="flex items-center space-x-2 flex-shrink-0">
                        <form method="POST" class="inline">
                            <input type="hidden" name="action" value="toggle">
                            <input type="hidden" name="id" value="<?= $b['id'] ?>">
                            <button type="submit" class="p-2 <?= $b['is_active'] ? 'text-yellow-600 hover:text-yellow-800' : 'text-green-600 hover:text-green-800' ?>"><i class="fas fa-<?= $b['is_active'] ? 'toggle-on' : 'toggle-off' ?>"></i></button>
                        </form>
                        <a href="?edit=<?= $b['id'] ?>" class="p-2 text-blue-600 hover:text-blue-800"><i class="fas fa-edit"></i></a>
                        <form method="POST" class="inline" onsubmit="return confirm('Delete this banner?')">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= $b['id'] ?>">
                            <button type="submit" class="p-2 text-red-600 hover:text-red-800"><i class="fas fa-trash"></i></button>
                        </form>
                    </div>
                </div>
                <?php endwhile; endif; ?>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer-admin.php'; ?>
