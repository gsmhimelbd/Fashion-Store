<?php
require_once __DIR__ . '/../config/database.php';
requireLogin();
include __DIR__ . '/../includes/admin-header.php';

$db = getDB();

$totalProducts = $db->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
$totalOrders = $db->query("SELECT COUNT(*) as c FROM orders")->fetch_assoc()['c'];
$pendingOrders = $db->query("SELECT COUNT(*) as c FROM orders WHERE status='pending'")->fetch_assoc()['c'];
$deliveredOrders = $db->query("SELECT COUNT(*) as c FROM orders WHERE status='delivered'")->fetch_assoc()['c'];
$totalRevenue = $db->query("SELECT COALESCE(SUM(grand_total), 0) as total FROM orders WHERE status='delivered'")->fetch_assoc()['total'];

$recentOrders = $db->query("SELECT * FROM orders ORDER BY id DESC LIMIT 5");
?>
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-blue-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Total Products</p>
                <p class="text-2xl font-bold text-gray-800"><?= $totalProducts ?></p>
            </div>
            <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center"><i class="fas fa-box text-blue-600"></i></div>
        </div>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-green-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Total Orders</p>
                <p class="text-2xl font-bold text-gray-800"><?= $totalOrders ?></p>
            </div>
            <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center"><i class="fas fa-shopping-cart text-green-600"></i></div>
        </div>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-yellow-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Pending Orders</p>
                <p class="text-2xl font-bold text-gray-800"><?= $pendingOrders ?></p>
            </div>
            <div class="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center"><i class="fas fa-clock text-yellow-600"></i></div>
        </div>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-teal-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Delivered</p>
                <p class="text-2xl font-bold text-gray-800"><?= $deliveredOrders ?></p>
            </div>
            <div class="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center"><i class="fas fa-check-circle text-teal-600"></i></div>
        </div>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-purple-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Total Revenue</p>
                <p class="text-2xl font-bold text-gray-800"><?= getCurrency() ?><?= number_format($totalRevenue, 2) ?></p>
            </div>
            <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center"><i class="fas fa-money-bill-wave text-purple-600"></i></div>
        </div>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm p-6">
    <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-semibold text-gray-800">Recent Orders</h2>
        <a href="orders.php" class="text-sm text-primary-600 hover:underline">View All <i class="fas fa-arrow-right ml-1"></i></a>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead><tr class="border-b bg-gray-50">
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Order #</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Customer</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Total</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Status</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Date</th>
            </tr></thead>
            <tbody>
                <?php if ($recentOrders->num_rows === 0): ?>
                <tr><td colspan="5" class="py-8 text-center text-gray-500">No orders yet</td></tr>
                <?php else: ?>
                <?php while ($o = $recentOrders->fetch_assoc()): ?>
                <tr class="border-b hover:bg-gray-50">
                    <td class="py-3 px-4 font-medium">#<?= $o['id'] ?></td>
                    <td class="py-3 px-4"><?= htmlspecialchars($o['customer_name']) ?></td>
                    <td class="py-3 px-4"><?= getCurrency() ?><?= number_format($o['grand_total'], 2) ?></td>
                    <td class="py-3 px-4">
                        <span class="px-2 py-1 text-xs rounded-full <?php
                            $statusClass = ['pending' => 'bg-yellow-100 text-yellow-700', 'confirmed' => 'bg-blue-100 text-blue-700', 'processing' => 'bg-indigo-100 text-indigo-700', 'shipped' => 'bg-purple-100 text-purple-700', 'delivered' => 'bg-green-100 text-green-700', 'cancelled' => 'bg-red-100 text-red-700'];
                            echo $statusClass[$o['status']] ?? 'bg-gray-100 text-gray-700';
                        ?>"><?= ucfirst($o['status']) ?></span>
                    </td>
                    <td class="py-3 px-4 text-sm text-gray-500"><?= date('d M Y, h:i A', strtotime($o['id'])) ?></td>
                </tr>
                <?php endwhile; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
    <a href="products.php" class="bg-white rounded-xl shadow-sm p-5 hover:shadow-md transition flex items-center space-x-4"><div class="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center"><i class="fas fa-box text-primary-600 text-xl"></i></div><div><p class="font-semibold text-gray-800">Manage Products</p><p class="text-sm text-gray-500">Add, edit & organize products</p></div></a>
    <a href="orders.php" class="bg-white rounded-xl shadow-sm p-5 hover:shadow-md transition flex items-center space-x-4"><div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center"><i class="fas fa-truck text-green-600 text-xl"></i></div><div><p class="font-semibold text-gray-800">Manage Orders</p><p class="text-sm text-gray-500">View & update order status</p></div></a>
    <a href="categories.php" class="bg-white rounded-xl shadow-sm p-5 hover:shadow-md transition flex items-center space-x-4"><div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center"><i class="fas fa-tags text-yellow-600 text-xl"></i></div><div><p class="font-semibold text-gray-800">Categories</p><p class="text-sm text-gray-500">Manage product categories</p></div></a>
</div>

<?php include __DIR__ . '/../includes/footer-admin.php'; ?>
