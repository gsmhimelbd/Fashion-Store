<?php
require_once __DIR__ . '/../config/database.php';
requireLogin();
include __DIR__ . '/../includes/admin-header.php';

$db = getDB();
$error = '';
$success = '';

const UPLOAD_DIR = __DIR__ . '/../uploads/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $id = intval($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $category_id = intval($_POST['category_id'] ?? 0);
        $description = trim($_POST['description'] ?? '');
        $price = floatval($_POST['price'] ?? 0);
        $stock = intval($_POST['stock'] ?? 0);
        $is_featured = isset($_POST['is_featured']) ? 1 : 0;
        $slug = slugify($name);

        if (!$name || !$category_id || $price <= 0) {
            $error = 'Name, category, and valid price are required.';
        } else {
            if ($action === 'add') {
                $stmt = $db->prepare("INSERT INTO products (category_id, name, slug, description, price, stock, is_featured) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param('isssdii', $category_id, $name, $slug, $description, $price, $stock, $is_featured);
                if ($stmt->execute()) {
                    $productId = $stmt->insert_id;
                    $success = 'Product added successfully.';
                } else {
                    $error = 'Failed to add product.';
                }
            } else {
                $stmt = $db->prepare("UPDATE products SET category_id = ?, name = ?, slug = ?, description = ?, price = ?, stock = ?, is_featured = ? WHERE id = ?");
                $stmt->bind_param('isssdiii', $category_id, $name, $slug, $description, $price, $stock, $is_featured, $id);
                if ($stmt->execute()) {
                    $productId = $id;
                    $success = 'Product updated successfully.';
                } else {
                    $error = 'Failed to update product.';
                }
            }

            if (empty($error) && !empty($_FILES['images']['name'][0])) {
                $files = $_FILES['images'];
                $fileCount = count($files['name']);
                $isFirst = true;
                for ($i = 0; $i < $fileCount; $i++) {
                    $file = ['name' => $files['name'][$i], 'tmp_name' => $files['tmp_name'][$i], 'error' => $files['error'][$i]];
                    $path = uploadImage($file, UPLOAD_DIR);
                    if ($path) {
                        $isPrimary = $isFirst ? 1 : 0;
                        $stmt = $db->prepare("INSERT INTO product_images (product_id, image_path, is_primary) VALUES (?, ?, ?)");
                        $stmt->bind_param('isi', $productId, $path, $isPrimary);
                        $stmt->execute();
                        $isFirst = false;
                    }
                }
            }
        }
    } elseif ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        $stmt = $db->prepare("DELETE FROM product_images WHERE product_id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param('i', $id);
        if ($stmt->execute()) $success = 'Product deleted successfully.';
        else $error = 'Failed to delete product.';
    } elseif ($action === 'set_primary') {
        $imgId = intval($_POST['image_id'] ?? 0);
        $prodId = intval($_POST['product_id'] ?? 0);
        $db->query("UPDATE product_images SET is_primary = 0 WHERE product_id = $prodId");
        $stmt = $db->prepare("UPDATE product_images SET is_primary = 1 WHERE id = ?");
        $stmt->bind_param('i', $imgId);
        $stmt->execute();
        $success = 'Primary image updated.';
    } elseif ($action === 'delete_image') {
        $imgId = intval($_POST['image_id'] ?? 0);
        $stmt = $db->prepare("DELETE FROM product_images WHERE id = ?");
        $stmt->bind_param('i', $imgId);
        $stmt->execute();
        $success = 'Image deleted.';
    }
}

$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;
$totalResult = $db->query("SELECT COUNT(*) as c FROM products");
$totalProducts = $totalResult->fetch_assoc()['c'];
$totalPages = ceil($totalProducts / $perPage);

$products = $db->query("SELECT p.*, c.name as category_name, (SELECT image_path FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC LIMIT $perPage OFFSET $offset");

$categories = $db->query("SELECT * FROM categories ORDER BY name");

$editProduct = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param('i', $_GET['edit']);
    $stmt->execute();
    $editProduct = $stmt->get_result()->fetch_assoc();
}
?>
<?php if ($error): ?><div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg mb-4"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-lg mb-4"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<button onclick="openProductModal(<?= $editProduct ? htmlspecialchars(json_encode($editProduct)) : 'null' ?>)" class="bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-lg transition mb-6 inline-flex items-center">
    <i class="fas fa-plus mr-2"></i> Add Product
</button>

<div class="bg-white rounded-xl shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead><tr class="border-b bg-gray-50">
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Image</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Name</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Category</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Price</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Stock</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Featured</th>
                <th class="py-3 px-4 text-sm font-semibold text-gray-600">Actions</th>
            </tr></thead>
            <tbody>
                <?php if ($products->num_rows === 0): ?>
                <tr><td colspan="7" class="py-8 text-center text-gray-500">No products yet</td></tr>
                <?php else: ?>
                <?php while ($p = $products->fetch_assoc()): ?>
                <tr class="border-b hover:bg-gray-50">
                    <td class="py-3 px-4">
                        <?php if ($p['primary_image']): ?>
                        <img src="../<?= htmlspecialchars($p['primary_image']) ?>" class="w-12 h-12 object-cover rounded-lg">
                        <?php else: ?>
                        <div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center text-gray-400"><i class="fas fa-image"></i></div>
                        <?php endif; ?>
                    </td>
                    <td class="py-3 px-4 font-medium"><?= htmlspecialchars($p['name']) ?></td>
                    <td class="py-3 px-4 text-sm text-gray-500"><?= htmlspecialchars($p['category_name'] ?? 'Uncategorized') ?></td>
                    <td class="py-3 px-4"><?= getCurrency() ?><?= number_format($p['price'], 2) ?></td>
                    <td class="py-3 px-4"><?= $p['stock'] ?></td>
                    <td class="py-3 px-4"><?= $p['is_featured'] ? '<span class="text-green-600"><i class="fas fa-check-circle"></i></span>' : '<span class="text-gray-300"><i class="fas fa-times-circle"></i></span>' ?></td>
                    <td class="py-3 px-4">
                        <button onclick='openProductModal(<?= htmlspecialchars(json_encode($p)) ?>)' class="text-blue-600 hover:text-blue-800 mr-3"><i class="fas fa-edit"></i></button>
                        <button onclick='openImagesModal(<?= $p['id'] ?>, "<?= htmlspecialchars($p['name']) ?>")' class="text-green-600 hover:text-green-800 mr-3"><i class="fas fa-images"></i></button>
                        <form method="POST" class="inline-block" onsubmit="return confirm('Delete this product?')">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= $p['id'] ?>">
                            <button type="submit" class="text-red-600 hover:text-red-800"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; endif; ?>
            </tbody>
        </table>
    </div>
    <?php if ($totalPages > 1): ?>
    <div class="flex items-center justify-between px-4 py-3 border-t">
        <p class="text-sm text-gray-500">Page <?= $page ?> of <?= $totalPages ?></p>
        <div class="flex space-x-2">
            <?php if ($page > 1): ?><a href="?page=<?= $page - 1 ?>" class="px-3 py-1 border rounded-lg text-sm hover:bg-gray-50">Previous</a><?php endif; ?>
            <?php if ($page < $totalPages): ?><a href="?page=<?= $page + 1 ?>" class="px-3 py-1 border rounded-lg text-sm hover:bg-gray-50">Next</a><?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<div id="productModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div class="flex items-center justify-between p-6 border-b">
            <h3 class="text-lg font-semibold" id="modalTitle">Add Product</h3>
            <button onclick="closeProductModal()" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times text-xl"></i></button>
        </div>
        <form method="POST" enctype="multipart/form-data" class="p-6 space-y-4">
            <input type="hidden" name="action" id="formAction" value="add">
            <input type="hidden" name="id" id="productId" value="0">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Product Name</label>
                    <input type="text" name="name" id="productName" required class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select name="category_id" id="productCategory" required class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none">
                        <option value="">Select Category</option>
                        <?php $categories->data_seek(0); while ($c = $categories->fetch_assoc()): ?>
                        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Price (<?= getCurrency() ?>)</label>
                    <input type="number" step="0.01" name="price" id="productPrice" required class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Stock</label>
                    <input type="number" name="stock" id="productStock" value="0" class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea name="description" id="productDescription" rows="4" class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none"></textarea>
            </div>
            <div>
                <label class="flex items-center space-x-2 cursor-pointer">
                    <input type="checkbox" name="is_featured" id="productFeatured" class="rounded border-gray-300 text-primary-600 focus:ring-primary-500">
                    <span class="text-sm text-gray-700">Featured Product</span>
                </label>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Product Images</label>
                <input type="file" name="images[]" multiple accept="image/*" class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-primary-500 outline-none file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary-50 file:text-primary-600 hover:file:bg-primary-100">
                <p class="text-xs text-gray-400 mt-1">First image will be set as primary. Upload new images to add.</p>
            </div>
            <div class="flex justify-end space-x-3 pt-2">
                <button type="button" onclick="closeProductModal()" class="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition">Cancel</button>
                <button type="submit" class="px-6 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-lg transition"><i class="fas fa-save mr-2"></i> Save Product</button>
            </div>
        </form>
    </div>
</div>

<div id="imagesModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div class="flex items-center justify-between p-6 border-b">
            <h3 class="text-lg font-semibold" id="imagesModalTitle">Manage Images</h3>
            <button onclick="closeImagesModal()" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times text-xl"></i></button>
        </div>
        <div class="p-6">
            <div id="imagesList" class="grid grid-cols-2 md:grid-cols-3 gap-4"></div>
            <form method="POST" enctype="multipart/form-data" class="mt-6 pt-4 border-t">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="id" id="imagesProductId" value="0">
                <label class="block text-sm font-medium text-gray-700 mb-1">Add More Images</label>
                <div class="flex space-x-2">
                    <input type="file" name="images[]" multiple accept="image/*" class="flex-1 border border-gray-300 rounded-lg px-4 py-2.5 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary-50 file:text-primary-600">
                    <button type="submit" class="px-4 py-2.5 bg-primary-600 text-white rounded-lg hover:bg-primary-700"><i class="fas fa-upload"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openProductModal(product) {
    const modal = document.getElementById('productModal');
    const title = document.getElementById('modalTitle');
    const action = document.getElementById('formAction');
    const pid = document.getElementById('productId');

    if (product && product.id) {
        title.textContent = 'Edit Product';
        action.value = 'edit';
        pid.value = product.id;
        document.getElementById('productName').value = product.name || '';
        document.getElementById('productCategory').value = product.category_id || '';
        document.getElementById('productPrice').value = product.price || '';
        document.getElementById('productStock').value = product.stock || 0;
        document.getElementById('productDescription').value = product.description || '';
        document.getElementById('productFeatured').checked = product.is_featured == 1;
    } else {
        title.textContent = 'Add Product';
        action.value = 'add';
        pid.value = 0;
        document.getElementById('productName').value = '';
        document.getElementById('productCategory').value = '';
        document.getElementById('productPrice').value = '';
        document.getElementById('productStock').value = 0;
        document.getElementById('productDescription').value = '';
        document.getElementById('productFeatured').checked = false;
    }
    modal.classList.remove('hidden');
}

function closeProductModal() {
    document.getElementById('productModal').classList.add('hidden');
}

function openImagesModal(productId, productName) {
    document.getElementById('imagesModalTitle').textContent = 'Images - ' + productName;
    document.getElementById('imagesProductId').value = productId;
    document.getElementById('imagesModal').classList.remove('hidden');

    fetch('products.php?ajax_images=' + productId)
        .then(r => r.text())
        .then(html => document.getElementById('imagesList').innerHTML = html);
}

function closeImagesModal() {
    document.getElementById('imagesModal').classList.add('hidden');
}

document.getElementById('productModal').addEventListener('click', function(e) {
    if (e.target === this) closeProductModal();
});
document.getElementById('imagesModal').addEventListener('click', function(e) {
    if (e.target === this) closeImagesModal();
});
</script>

<?php
if (isset($_GET['ajax_images'])) {
    $pid = intval($_GET['ajax_images']);
    $stmt = $db->prepare("SELECT * FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, id ASC");
    $stmt->bind_param('i', $pid);
    $stmt->execute();
    $images = $stmt->get_result();
    while ($img = $images->fetch_assoc()):
?>
<div class="relative group">
    <img src="../<?= htmlspecialchars($img['image_path']) ?>" class="w-full h-32 object-cover rounded-lg">
    <?php if ($img['is_primary']): ?>
    <span class="absolute top-1 left-1 bg-green-500 text-white text-xs px-2 py-0.5 rounded-full">Primary</span>
    <?php else: ?>
    <form method="POST" class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 group-hover:bg-opacity-40 transition rounded-lg">
        <input type="hidden" name="action" value="set_primary">
        <input type="hidden" name="image_id" value="<?= $img['id'] ?>">
        <input type="hidden" name="product_id" value="<?= $pid ?>">
        <button type="submit" class="text-white bg-blue-600 px-3 py-1 rounded text-sm opacity-0 group-hover:opacity-100 transition mr-2"><i class="fas fa-star"></i></button>
    </form>
    <?php endif; ?>
    <form method="POST" class="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition">
        <input type="hidden" name="action" value="delete_image">
        <input type="hidden" name="image_id" value="<?= $img['id'] ?>">
        <button type="submit" class="bg-red-500 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs hover:bg-red-600" onclick="return confirm('Delete this image?')"><i class="fas fa-times"></i></button>
    </form>
</div>
<?php endwhile; exit; } ?>

<?php include __DIR__ . '/../includes/footer-admin.php'; ?>
