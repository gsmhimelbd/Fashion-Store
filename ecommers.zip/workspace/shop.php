<?php require_once 'includes/header.php'; ?>

<?php
$db = getDB();
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 12;
$offset = ($page - 1) * $perPage;

$categorySlug = isset($_GET['category']) ? $_GET['category'] : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$priceMin = isset($_GET['price_min']) ? floatval($_GET['price_min']) : 0;
$priceMax = isset($_GET['price_max']) ? floatval($_GET['price_max']) : 0;

$where = [];
$params = [];
$types = '';

if ($categorySlug) {
    $catStmt = $db->prepare("SELECT id FROM categories WHERE slug = ?");
    $catStmt->bind_param('s', $categorySlug);
    $catStmt->execute();
    $catRow = $catStmt->get_result()->fetch_assoc();
    if ($catRow) {
        $where[] = 'p.category_id = ?';
        $params[] = $catRow['id'];
        $types .= 'i';
    }
}

if ($search) {
    $where[] = 'p.name LIKE ?';
    $params[] = '%' . $search . '%';
    $types .= 's';
}

if ($priceMin > 0) {
    $where[] = 'p.price >= ?';
    $params[] = $priceMin;
    $types .= 'd';
}

if ($priceMax > 0) {
    $where[] = 'p.price <= ?';
    $params[] = $priceMax;
    $types .= 'd';
}

$whereClause = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';

$countSql = "SELECT COUNT(*) as total FROM products p $whereClause";
$countStmt = $db->prepare($countSql);
if (!empty($params)) {
    $countStmt->bind_param($types, ...$params);
}
$countStmt->execute();
$totalProducts = $countStmt->get_result()->fetch_assoc()['total'];
$totalPages = ceil($totalProducts / $perPage);

$sql = "SELECT p.*, (SELECT image_path FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as image FROM products p $whereClause ORDER BY p.created_at DESC LIMIT ? OFFSET ?";
$stmt = $db->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types . 'ii', ...$params, $perPage, $offset);
} else {
    $stmt->bind_param('ii', $perPage, $offset);
}
$stmt->execute();
$products = $stmt->get_result();

$categories = $db->query("SELECT * FROM categories ORDER BY name");
?>

<div class="max-w-7xl mx-auto px-4 py-8">
    <div class="flex flex-col md:flex-row gap-8">
        <!-- Sidebar -->
        <aside class="w-full md:w-64 shrink-0">
            <div class="bg-white rounded-xl shadow p-6 sticky top-24">
                <h3 class="font-semibold text-lg text-gray-800 mb-4">Categories</h3>
                <ul class="space-y-2">
                    <li>
                        <a href="shop.php<?= $search ? '?search=' . urlencode($search) : '' ?>" class="text-gray-600 hover:text-blue-600 transition <?= !$categorySlug ? 'text-blue-600 font-medium' : '' ?>">All Categories</a>
                    </li>
                    <?php while ($cat = $categories->fetch_assoc()): ?>
                    <li>
                        <a href="shop.php?category=<?= htmlspecialchars($cat['slug']) ?><?= $search ? '&search=' . urlencode($search) : '' ?>" class="text-gray-600 hover:text-blue-600 transition <?= $categorySlug === $cat['slug'] ? 'text-blue-600 font-medium' : '' ?>"><?= htmlspecialchars($cat['name']) ?></a>
                    </li>
                    <?php endwhile; ?>
                </ul>

                <h3 class="font-semibold text-lg text-gray-800 mt-6 mb-4">Price Range</h3>
                <ul class="space-y-2">
                    <?php
                    $ranges = [
                        ['min' => 0, 'max' => 500, 'label' => 'Under ৳500'],
                        ['min' => 500, 'max' => 1000, 'label' => '৳500 - ৳1,000'],
                        ['min' => 1000, 'max' => 2000, 'label' => '৳1,000 - ৳2,000'],
                        ['min' => 2000, 'max' => 0, 'label' => '৳2,000+'],
                    ];
                    foreach ($ranges as $range):
                        $active = $priceMin == $range['min'] && $priceMax == $range['max'];
                        $params = [];
                        if ($categorySlug) $params['category'] = $categorySlug;
                        if ($search) $params['search'] = $search;
                        if ($range['min'] > 0) $params['price_min'] = $range['min'];
                        if ($range['max'] > 0) $params['price_max'] = $range['max'];
                        $url = 'shop.php?' . http_build_query($params);
                    ?>
                    <li>
                        <a href="<?= $url ?>" class="text-gray-600 hover:text-blue-600 transition <?= $active ? 'text-blue-600 font-medium' : '' ?>"><?= $range['label'] ?></a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </aside>

        <!-- Product Grid -->
        <div class="flex-1">
            <!-- Search and Results info -->
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
                <p class="text-gray-500"><?= $totalProducts ?> product<?= $totalProducts != 1 ? 's' : '' ?> found</p>
                <form method="GET" action="shop.php" class="flex w-full sm:w-auto">
                    <?php if ($categorySlug): ?>
                    <input type="hidden" name="category" value="<?= htmlspecialchars($categorySlug) ?>">
                    <?php endif; ?>
                    <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search products..." class="border rounded-l-lg px-4 py-2 w-full sm:w-64 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-r-lg hover:bg-blue-700 transition"><i class="fas fa-search"></i></button>
                </form>
            </div>

            <?php if ($products->num_rows > 0): ?>
            <div class="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
                <?php while ($row = $products->fetch_assoc()): ?>
                <div class="bg-white rounded-xl overflow-hidden shadow hover:shadow-lg transition group">
                    <a href="product.php?id=<?= $row['id'] ?>">
                        <div class="h-48 bg-gray-100 flex items-center justify-center overflow-hidden">
                            <?php if ($row['image']): ?>
                            <img src="<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['name']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform">
                            <?php else: ?>
                            <div class="text-gray-400 text-5xl"><i class="fas fa-tshirt"></i></div>
                            <?php endif; ?>
                        </div>
                    </a>
                    <div class="p-4">
                        <a href="product.php?id=<?= $row['id'] ?>" class="text-gray-800 font-semibold hover:text-blue-600 transition line-clamp-2"><?= htmlspecialchars($row['name']) ?></a>
                        <p class="text-blue-600 font-bold text-lg mt-1"><?= getCurrency() ?><?= number_format($row['price'], 2) ?></p>
                        <p class="text-sm mt-1 <?= $row['stock'] > 0 ? 'text-green-600' : 'text-red-500' ?>">
                            <?= $row['stock'] > 0 ? 'In Stock (' . $row['stock'] . ')' : 'Out of Stock' ?>
                        </p>
                        <?php if ($row['stock'] > 0): ?>
                        <button onclick="addToCart(<?= $row['id'] ?>)" class="mt-3 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium">Add to Cart</button>
                        <?php else: ?>
                        <button disabled class="mt-3 w-full bg-gray-400 text-white py-2 rounded-lg cursor-not-allowed text-sm font-medium">Out of Stock</button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
            <div class="flex justify-center mt-8 gap-2">
                <?php if ($page > 1): ?>
                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>" class="px-4 py-2 bg-white border rounded-lg hover:bg-gray-50 transition">&laquo; Prev</a>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>" class="px-4 py-2 <?= $i == $page ? 'bg-blue-600 text-white' : 'bg-white text-gray-600' ?> border rounded-lg hover:bg-blue-50 transition"><?= $i ?></a>
                <?php endfor; ?>
                <?php if ($page < $totalPages): ?>
                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>" class="px-4 py-2 bg-white border rounded-lg hover:bg-gray-50 transition">Next &raquo;</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php else: ?>
            <div class="text-center py-16">
                <div class="text-6xl text-gray-300 mb-4"><i class="fas fa-box-open"></i></div>
                <h3 class="text-xl font-semibold text-gray-600">No products found</h3>
                <p class="text-gray-400 mt-2">Try adjusting your filters or search terms</p>
                <a href="shop.php" class="inline-block mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition">Clear Filters</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function addToCart(productId) {
    fetch('cart.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=add&product_id=' + productId + '&quantity=1'
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            const badge = document.getElementById('cart-badge');
            badge.textContent = data.count;
            badge.classList.remove('hidden');
            alert('Product added to cart!');
        }
    });
}
</script>

<?php require_once 'includes/footer.php'; ?>
