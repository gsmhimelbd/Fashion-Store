<?php require_once 'includes/header.php'; ?>

<?php
$productId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db = getDB();

$stmt = $db->prepare("SELECT p.*, c.name as category_name, c.slug as category_slug FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = ?");
$stmt->bind_param('i', $productId);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product):
?>

<div class="max-w-7xl mx-auto px-4 py-20 text-center">
    <div class="text-8xl text-gray-300 mb-6"><i class="fas fa-exclamation-circle"></i></div>
    <h1 class="text-4xl font-bold text-gray-800 mb-4">Product Not Found</h1>
    <p class="text-gray-500 mb-8">The product you're looking for doesn't exist or has been removed.</p>
    <a href="shop.php" class="inline-block bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition font-medium">Continue Shopping</a>
</div>

<?php else:

$imgStmt = $db->prepare("SELECT * FROM product_images WHERE product_id = ? ORDER BY is_primary DESC");
$imgStmt->bind_param('i', $productId);
$imgStmt->execute();
$images = $imgStmt->get_result();

$relatedStmt = $db->prepare("SELECT p.*, (SELECT image_path FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as image FROM products p WHERE p.category_id = ? AND p.id != ? ORDER BY RAND() LIMIT 4");
$relatedStmt->bind_param('ii', $product['category_id'], $productId);
$relatedStmt->execute();
$related = $relatedStmt->get_result();

$currency = getCurrency();
$storeUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/product.php?id=' . $product['id'];
$whatsappNumber = getSetting('whatsapp_number') ?: '01775153740';
$whatsappText = 'I want to order: ' . $product['name'] . ' - ' . $storeUrl;
?>

<div class="max-w-7xl mx-auto px-4 py-8">
    <nav class="text-sm text-gray-500 mb-6">
        <a href="index.php" class="hover:text-blue-600">Home</a> &raquo;
        <a href="shop.php" class="hover:text-blue-600">Shop</a> &raquo;
        <?php if ($product['category_name']): ?>
        <a href="shop.php?category=<?= htmlspecialchars($product['category_slug']) ?>" class="hover:text-blue-600"><?= htmlspecialchars($product['category_name']) ?></a> &raquo;
        <?php endif; ?>
        <span class="text-gray-800"><?= htmlspecialchars($product['name']) ?></span>
    </nav>

    <div class="grid md:grid-cols-2 gap-8">
        <!-- Image Gallery -->
        <div>
            <?php
            $allImages = [];
            while ($img = $images->fetch_assoc()) {
                $allImages[] = $img;
            }
            $primaryImg = array_filter($allImages, fn($i) => $i['is_primary']);
            $primaryImg = reset($primaryImg);
            ?>
            <div class="bg-gray-100 rounded-xl overflow-hidden h-80 md:h-96 flex items-center justify-center mb-4">
                <?php if ($primaryImg): ?>
                <img id="main-image" src="<?= htmlspecialchars($primaryImg['image_path']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-full object-cover">
                <?php elseif (!empty($allImages)): ?>
                <img id="main-image" src="<?= htmlspecialchars($allImages[0]['image_path']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-full object-cover">
                <?php else: ?>
                <div class="text-gray-400 text-6xl"><i class="fas fa-tshirt"></i></div>
                <?php endif; ?>
            </div>
            <?php if (count($allImages) > 1): ?>
            <div class="flex gap-2 overflow-x-auto">
                <?php foreach ($allImages as $img): ?>
                <button onclick="document.getElementById('main-image').src='<?= htmlspecialchars($img['image_path']) ?>'" class="w-20 h-20 rounded-lg overflow-hidden border-2 hover:border-blue-500 transition flex-shrink-0 <?= $img['is_primary'] ? 'border-blue-500' : 'border-transparent' ?>">
                    <img src="<?= htmlspecialchars($img['image_path']) ?>" alt="" class="w-full h-full object-cover">
                </button>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Product Info -->
        <div>
            <h1 class="text-2xl md:text-3xl font-bold text-gray-800"><?= htmlspecialchars($product['name']) ?></h1>
            <p class="text-3xl font-bold text-blue-600 mt-4"><?= $currency ?><?= number_format($product['price'], 2) ?></p>
            <p class="mt-2 text-sm <?= $product['stock'] > 0 ? 'text-green-600' : 'text-red-500' ?>">
                <i class="fas <?= $product['stock'] > 0 ? 'fa-check-circle' : 'fa-times-circle' ?> mr-1"></i>
                <?= $product['stock'] > 0 ? 'In Stock' : 'Out of Stock' ?>
            </p>
            <hr class="my-6">
            <div class="prose max-w-none text-gray-600">
                <?= nl2br(htmlspecialchars($product['description'] ?? '')) ?>
            </div>

            <!-- Add to Cart -->
            <?php if ($product['stock'] > 0): ?>
            <div class="flex items-center gap-4 mt-6">
                <div class="flex items-center border rounded-lg">
                    <button onclick="updateQty(-1)" class="px-3 py-2 text-gray-600 hover:bg-gray-100 transition">-</button>
                    <input type="number" id="qty" value="1" min="1" max="<?= $product['stock'] ?>" class="w-16 text-center border-x py-2 focus:outline-none" readonly>
                    <button onclick="updateQty(1)" class="px-3 py-2 text-gray-600 hover:bg-gray-100 transition">+</button>
                </div>
                <button onclick="addToCart(<?= $product['id'] ?>)" class="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition font-medium">Add to Cart</button>
            </div>
            <?php endif; ?>

            <!-- WhatsApp Order -->
            <a href="https://wa.me/88<?= htmlspecialchars($whatsappNumber) ?>?text=<?= urlencode($whatsappText) ?>" target="_blank" class="mt-4 flex items-center justify-center gap-2 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition font-medium">
                <i class="fab fa-whatsapp text-xl"></i> Order via WhatsApp
            </a>
        </div>
    </div>

    <!-- Related Products -->
    <?php if ($related->num_rows > 0): ?>
    <section class="mt-16">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">Related Products</h2>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
            <?php while ($row = $related->fetch_assoc()): ?>
            <div class="bg-white rounded-xl overflow-hidden shadow hover:shadow-lg transition group">
                <a href="product.php?id=<?= $row['id'] ?>">
                    <div class="h-48 bg-gray-100 flex items-center justify-center overflow-hidden">
                        <?php if ($row['image']): ?>
                        <img src="<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['name']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform">
                        <?php else: ?>
                        <div class="text-gray-400 text-5xl"><i class="fas fa-tshirt"></i></div>
                        <?php endif; ?>
                    </div>
                </a>
                <div class="p-4">
                    <a href="product.php?id=<?= $row['id'] ?>" class="text-gray-800 font-semibold hover:text-blue-600 transition line-clamp-2"><?= htmlspecialchars($row['name']) ?></a>
                    <p class="text-blue-600 font-bold mt-1"><?= $currency ?><?= number_format($row['price'], 2) ?></p>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </section>
    <?php endif; ?>
</div>

<script>
let qty = 1;
function updateQty(delta) {
    const input = document.getElementById('qty');
    let val = parseInt(input.value) + delta;
    if (val < 1) val = 1;
    if (val > <?= $product['stock'] ?>) val = <?= $product['stock'] ?>;
    input.value = val;
    qty = val;
}

function addToCart(productId) {
    fetch('cart.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=add&product_id=' + productId + '&quantity=' + qty
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            const badge = document.getElementById('cart-badge');
            badge.textContent = data.count;
            badge.classList.remove('hidden');
            alert('Product added to cart!');
        }
    });
}
</script>

<?php endif; ?>
<?php require_once 'includes/footer.php'; ?>
