<?php require_once 'includes/header.php'; ?>

<?php
$contactPhone = getSetting('contact_phone') ?: '01775153740';
$whatsapp = getSetting('whatsapp_number') ?: '01775153740';
$facebook = getSetting('facebook_page') ?: '';
$storeName = getSetting('store_name') ?: 'Fashion Store';
?>

<div class="max-w-7xl mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-8 text-center">Contact Us</h1>

    <!-- Contact Info Cards -->
    <div class="grid md:grid-cols-3 gap-6 mb-12">
        <div class="bg-white rounded-xl shadow p-6 text-center hover:shadow-lg transition">
            <div class="text-4xl text-blue-600 mb-4"><i class="fas fa-phone"></i></div>
            <h3 class="text-lg font-semibold text-gray-800">Call Us</h3>
            <p class="text-gray-500 mt-2"><?= htmlspecialchars($contactPhone) ?></p>
            <p class="text-sm text-gray-400">Mon-Sat, 9AM-8PM</p>
        </div>
        <div class="bg-white rounded-xl shadow p-6 text-center hover:shadow-lg transition">
            <div class="text-4xl text-green-500 mb-4"><i class="fab fa-whatsapp"></i></div>
            <h3 class="text-lg font-semibold text-gray-800">WhatsApp</h3>
            <p class="text-gray-500 mt-2"><?= htmlspecialchars($whatsapp) ?></p>
            <a href="https://wa.me/88<?= htmlspecialchars($whatsapp) ?>" target="_blank" class="inline-block mt-3 bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 transition text-sm">Chat Now</a>
        </div>
        <div class="bg-white rounded-xl shadow p-6 text-center hover:shadow-lg transition">
            <div class="text-4xl text-blue-700 mb-4"><i class="fab fa-facebook"></i></div>
            <h3 class="text-lg font-semibold text-gray-800">Facebook</h3>
            <?php if ($facebook): ?>
            <p class="text-gray-500 mt-2">Follow us on Facebook</p>
            <a href="<?= htmlspecialchars($facebook) ?>" target="_blank" class="inline-block mt-3 bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition text-sm">Visit Page</a>
            <?php else: ?>
            <p class="text-gray-500 mt-2">Coming soon</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="grid md:grid-cols-2 gap-8">
        <!-- Contact Form -->
        <div class="bg-white rounded-xl shadow p-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Send Us a Message</h2>
            <form action="contact.php" method="POST" class="space-y-4">
                <div class="grid md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Your Name</label>
                        <input type="text" name="name" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Your Email</label>
                        <input type="email" name="email" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                    <input type="text" name="phone" class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Message</label>
                    <textarea name="message" required rows="4" class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                </div>
                <button type="submit" name="send_message" class="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition font-medium">Send Message</button>
            </form>
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
                $name = htmlspecialchars($_POST['name']);
                $email = htmlspecialchars($_POST['email']);
                $phone = htmlspecialchars($_POST['phone'] ?? '');
                $message = htmlspecialchars($_POST['message']);
                echo '<div class="mt-4 p-3 bg-green-50 text-green-700 rounded-lg text-sm">Thank you, ' . $name . '! We will get back to you soon.</div>';
            }
            ?>
        </div>

        <!-- Store Info -->
        <div class="bg-white rounded-xl shadow p-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Store Information</h2>
            <div class="space-y-6">
                <div class="flex items-start gap-4">
                    <div class="text-2xl text-blue-600 mt-1"><i class="fas fa-store"></i></div>
                    <div>
                        <h4 class="font-semibold text-gray-800"><?= htmlspecialchars($storeName) ?></h4>
                        <p class="text-gray-500 text-sm">Your trusted fashion accessories store</p>
                    </div>
                </div>
                <div class="flex items-start gap-4">
                    <div class="text-2xl text-blue-600 mt-1"><i class="fas fa-phone"></i></div>
                    <div>
                        <h4 class="font-semibold text-gray-800">Phone</h4>
                        <p class="text-gray-500 text-sm"><?= htmlspecialchars($contactPhone) ?></p>
                    </div>
                </div>
                <div class="flex items-start gap-4">
                    <div class="text-2xl text-green-500 mt-1"><i class="fab fa-whatsapp"></i></div>
                    <div>
                        <h4 class="font-semibold text-gray-800">WhatsApp</h4>
                        <a href="https://wa.me/88<?= htmlspecialchars($whatsapp) ?>" target="_blank" class="text-blue-600 hover:underline text-sm"><?= htmlspecialchars($whatsapp) ?></a>
                    </div>
                </div>
                <div class="flex items-start gap-4">
                    <div class="text-2xl text-blue-700 mt-1"><i class="fab fa-facebook"></i></div>
                    <div>
                        <h4 class="font-semibold text-gray-800">Facebook</h4>
                        <?php if ($facebook): ?>
                        <a href="<?= htmlspecialchars($facebook) ?>" target="_blank" class="text-blue-600 hover:underline text-sm">Visit our Facebook page</a>
                        <?php else: ?>
                        <p class="text-gray-500 text-sm">Coming soon</p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="flex items-start gap-4">
                    <div class="text-2xl text-blue-600 mt-1"><i class="fas fa-clock"></i></div>
                    <div>
                        <h4 class="font-semibold text-gray-800">Business Hours</h4>
                        <p class="text-gray-500 text-sm">Saturday - Thursday: 9:00 AM - 8:00 PM</p>
                        <p class="text-gray-500 text-sm">Friday: Closed</p>
                    </div>
                </div>
            </div>

            <!-- WhatsApp Chat Widget -->
            <div class="mt-8 p-4 bg-green-50 rounded-lg">
                <div class="flex items-center gap-3">
                    <div class="text-3xl text-green-500"><i class="fab fa-whatsapp"></i></div>
                    <div>
                        <p class="font-semibold text-gray-800">Chat with us on WhatsApp!</p>
                        <p class="text-sm text-gray-500">We usually reply within minutes</p>
                    </div>
                </div>
                <a href="https://wa.me/88<?= htmlspecialchars($whatsapp) ?>" target="_blank" class="mt-4 inline-flex items-center gap-2 bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 transition text-sm font-medium">
                    <i class="fab fa-whatsapp text-lg"></i> Start Chat
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
