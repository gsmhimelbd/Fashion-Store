/* ===================================================================
   Fashion Accessories eCommerce — Main Script
   =================================================================== */

/* ------------------------------------------------------------------
   Cart Operations (fetch API)
   ------------------------------------------------------------------ */

/**
 * Add a product to the cart
 */
function addToCart(productId, quantity = 1) {
    const btn = event && event.target ? event.target.closest('.btn') : null;
    if (btn) {
        btn.disabled = true;
        const orig = btn.innerHTML;
        btn.innerHTML = '<span class="spinner"></span>';
    }

    fetch('cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=add&product_id=' + productId + '&quantity=' + quantity
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                showToast(data.message || 'Product added to cart!', 'success');
                updateCartBadge(data.count);
            } else {
                showToast(data.message || 'Could not add to cart.', 'error');
            }
        })
        .catch(() => showToast('Network error. Please try again.', 'error'))
        .finally(() => {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-shopping-cart mr-1"></i> Add to Cart';
            }
        });
}

/**
 * Update quantity of a cart item
 */
function updateCart(productId, quantity) {
    if (quantity < 1) return;

    fetch('cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=update&product_id=' + productId + '&quantity=' + quantity
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                showToast(data.message || 'Could not update cart.', 'error');
            }
        })
        .catch(() => showToast('Network error. Please try again.', 'error'));
}

/**
 * Remove an item from the cart with confirmation
 */
function removeFromCart(productId) {
    if (!confirm('Remove this item from cart?')) return;

    const row = document.querySelector('.cart-item[data-product-id="' + productId + '"]');
    if (row) row.classList.add('removing');

    fetch('cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=remove&product_id=' + productId
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                showToast('Item removed.', 'info');
                setTimeout(() => location.reload(), 350);
            } else {
                showToast(data.message || 'Could not remove item.', 'error');
                if (row) row.classList.remove('removing');
            }
        })
        .catch(() => {
            showToast('Network error. Please try again.', 'error');
            if (row) row.classList.remove('removing');
        });
}

/**
 * Update the cart badge count in the header
 */
function updateCartBadge(count) {
    const badge = document.getElementById('cart-badge');
    if (badge) {
        badge.textContent = count;
        badge.classList.toggle('hidden', count === 0);
        badge.classList.add('animate-fade-in');
    }
}

/* ------------------------------------------------------------------
   Toast Notification System
   ------------------------------------------------------------------ */

/**
 * Show a dismissable toast notification
 */
function showToast(message, type) {
    type = type || 'success';

    var toast = document.createElement('div');
    toast.className = 'toast toast-' + type + ' animate-fade-in';
    toast.textContent = message;

    var close = document.createElement('button');
    close.className = 'ml-3 text-white opacity-70 hover:opacity-100';
    close.innerHTML = '&times;';
    close.style.cssText = 'background:none;border:none;font-size:1.25rem;line-height:1;cursor:pointer;vertical-align:middle';
    close.onclick = function () { toast.remove(); };
    toast.appendChild(close);

    document.body.appendChild(toast);

    setTimeout(function () {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s ease';
        setTimeout(function () { toast.remove(); }, 300);
    }, 3500);
}

/* ------------------------------------------------------------------
   Checkout Page — Payment Method Toggle
   ------------------------------------------------------------------ */

function setupPaymentToggle() {
    var paymentRadios = document.querySelectorAll('input[name="payment_method"]');
    var paymentFields = document.getElementById('payment-fields');

    if (!paymentRadios.length || !paymentFields) return;

    function togglePaymentFields() {
        var selected = document.querySelector('input[name="payment_method"]:checked');
        if (!selected) return;

        if (selected.value === 'cod') {
            paymentFields.classList.add('hidden');
        } else {
            paymentFields.classList.remove('hidden');
            var label = document.querySelector('label[for="payment_number"]');
            if (label) {
                label.textContent = selected.value.charAt(0).toUpperCase() + selected.value.slice(1) + ' Number';
            }
        }
    }

    paymentRadios.forEach(function (radio) {
        radio.addEventListener('change', togglePaymentFields);
    });

    // Run once on load
    togglePaymentFields();
}

/* ------------------------------------------------------------------
   Checkout Page — Delivery Charge
   ------------------------------------------------------------------ */

function setupDeliveryCharge() {
    var districtSelect = document.getElementById('district');
    var chargeDisplay = document.getElementById('delivery-charge-display');
    if (!districtSelect || !chargeDisplay) return;

    districtSelect.addEventListener('change', function () {
        var charge = this.value === 'Tangail' ? 50 : 150;
        chargeDisplay.textContent = charge + ' ' + (document.getElementById('currency-symbol') ? document.getElementById('currency-symbol').textContent : 'BDT');
        updateGrandTotal();
    });
}

/**
 * Recalculate grand total on the checkout page
 */
function updateGrandTotal() {
    var subtotalEl = document.getElementById('subtotal-display');
    var deliveryEl = document.getElementById('delivery-charge-display');
    var totalEl = document.getElementById('grand-total-display');
    if (!subtotalEl || !deliveryEl || !totalEl) return;

    var subtotal = parseFloat(subtotalEl.getAttribute('data-value') || subtotalEl.textContent.replace(/[^\d.]/g, '')) || 0;
    var delivery = parseFloat(deliveryEl.textContent.replace(/[^\d.]/g, '')) || 0;

    var total = subtotal + delivery;
    totalEl.textContent = total.toFixed(2);

    var symbol = document.getElementById('currency-symbol');
    if (symbol) totalEl.textContent = symbol.textContent + ' ' + total.toFixed(2);
}

/* ------------------------------------------------------------------
   Product Gallery — Thumbnail Click
   ------------------------------------------------------------------ */

function setupGallery() {
    var thumbnails = document.querySelectorAll('.product-thumbnail');
    var mainImage = document.getElementById('main-image');
    if (!thumbnails.length || !mainImage) return;

    thumbnails.forEach(function (thumb) {
        thumb.addEventListener('click', function () {
            thumbnails.forEach(function (t) { t.classList.remove('active', 'border-blue-500'); });
            this.classList.add('active', 'border-blue-500');
            mainImage.src = this.src;
            mainImage.classList.remove('animate-fade-in');
            // Force reflow then re-add for smooth transition
            void mainImage.offsetWidth;
            mainImage.classList.add('animate-fade-in');
        });
    });
}

/* ------------------------------------------------------------------
   Quantity Input — Increment / Decrement
   ------------------------------------------------------------------ */

function setupQuantityControls() {
    document.querySelectorAll('.qty-minus').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = this.parentElement.querySelector('.qty-input');
            if (!input) return;
            var val = parseInt(input.value, 10) || 1;
            if (val > 1) input.value = val - 1;
            input.dispatchEvent(new Event('change'));
        });
    });

    document.querySelectorAll('.qty-plus').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = this.parentElement.querySelector('.qty-input');
            if (!input) return;
            var val = parseInt(input.value, 10) || 1;
            input.value = val + 1;
            input.dispatchEvent(new Event('change'));
        });
    });
}

/* ------------------------------------------------------------------
   DOM Ready
   ------------------------------------------------------------------ */

document.addEventListener('DOMContentLoaded', function () {
    setupPaymentToggle();
    setupDeliveryCharge();
    setupGallery();
    setupQuantityControls();
    updateGrandTotal();
});
