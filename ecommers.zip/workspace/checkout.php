<?php
require_once 'config/database.php';

$items = getCartItems();
$currency = getCurrency();
$errors = [];

if (empty($items)) {
    header('Location: cart.php');
    exit;
}

$subtotal = 0;
foreach ($items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

$district = $_POST['district'] ?? ($_SESSION['delivery_district'] ?? 'Other');
$deliveryCharge = ($district === 'Tangail') ? (float)(getSetting('delivery_charge_tangail') ?: 50) : (float)(getSetting('delivery_charge_other') ?: 150);

$bkashNumber = getSetting('bkash_number') ?: '01775153740';
$nagadNumber = getSetting('nagad_number') ?: '01775153740';
$rocketNumber = getSetting('rocket_number') ?: '01775153740';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $fullName = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $whatsapp = trim($_POST['whatsapp'] ?? '');
    $district = trim($_POST['district'] ?? 'Other');
    $upazila = trim($_POST['upazila'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    $paymentMethod = $_POST['payment_method'] ?? 'cod';
    $paymentNumber = trim($_POST['payment_number'] ?? '');
    $transactionId = trim($_POST['transaction_id'] ?? '');

    // Validation
    if (!$fullName) $errors[] = 'Full name is required';
    if (!$phone) $errors[] = 'Phone number is required';
    if (!$upazila) $errors[] = 'Upazila is required';
    if (!$address) $errors[] = 'Address is required';

    if (in_array($paymentMethod, ['bkash', 'nagad', 'rocket'])) {
        if (!$paymentNumber) $errors[] = 'Payment number is required';
        if (!$transactionId) $errors[] = 'Transaction ID is required';
    }

    $deliveryCharge = ($district === 'Tangail') ? (float)(getSetting('delivery_charge_tangail') ?: 50) : (float)(getSetting('delivery_charge_other') ?: 150);
    $grandTotal = $subtotal + $deliveryCharge;

    if (empty($errors)) {
        $db = getDB();
        $db->begin_transaction();
        try {
            $stmt = $db->prepare("INSERT INTO orders (customer_name, phone, whatsapp, district, upazila, address, notes, payment_method, payment_number, transaction_id, subtotal, delivery_charge, grand_total, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
            $stmt->bind_param('ssssssssssdd', $fullName, $phone, $whatsapp, $district, $upazila, $address, $notes, $paymentMethod, $paymentNumber, $transactionId, $subtotal, $deliveryCharge, $grandTotal);
            $stmt->execute();
            $orderId = $db->insert_id;

            $itemStmt = $db->prepare("INSERT INTO order_items (order_id, product_id, product_name, price, quantity) VALUES (?, ?, ?, ?, ?)");
            foreach ($items as $item) {
                $itemStmt->bind_param('iisdi', $orderId, $item['id'], $item['name'], $item['price'], $item['quantity']);
                $itemStmt->execute();
            }

            $db->commit();
            $_SESSION['cart'] = [];
            $_SESSION['delivery_district'] = $district;
            header('Location: order-success.php?id=' . $orderId);
            exit;
        } catch (Exception $e) {
            $db->rollback();
            $errors[] = 'Something went wrong. Please try again.';
        }
    }
}

$grandTotal = $subtotal + $deliveryCharge;
require_once 'includes/header.php';
?>

<div class="max-w-7xl mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-8">Checkout</h1>

    <?php if (!empty($errors)): ?>
    <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
        <ul class="list-disc list-inside">
            <?php foreach ($errors as $err): ?>
            <li><?= htmlspecialchars($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="checkout.php" class="grid lg:grid-cols-3 gap-8">
        <!-- Customer Information -->
        <div class="lg:col-span-2 space-y-6">
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Customer Information</h2>
                <div class="grid md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                        <input type="text" name="full_name" value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Phone *</label>
                        <input type="text" name="phone" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">WhatsApp (optional)</label>
                        <input type="text" name="whatsapp" value="<?= htmlspecialchars($_POST['whatsapp'] ?? '') ?>" class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">District *</label>
                        <select name="district" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="Tangail" <?= ($district ?? 'Other') === 'Tangail' ? 'selected' : '' ?>>Tangail</option>
                            <option value="Other" <?= ($district ?? 'Other') === 'Other' ? 'selected' : '' ?>>Other District</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Upazila *</label>
                        <input type="text" name="upazila" value="<?= htmlspecialchars($_POST['upazila'] ?? '') ?>" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Address *</label>
                        <textarea name="address" required rows="2" class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>
                    </div>
                </div>
                <div class="mt-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Notes (optional)</label>
                    <textarea name="notes" rows="2" class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
                </div>
            </div>

            <!-- Payment Method -->
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Payment Method</h2>
                <div class="space-y-3">
                    <label class="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition">
                        <input type="radio" name="payment_method" value="cod" checked onchange="togglePaymentFields()" class="text-blue-600">
                        <div>
                            <span class="font-medium text-gray-800">Cash on Delivery</span>
                            <p class="text-sm text-gray-500">Pay when you receive</p>
                        </div>
                    </label>
                    <label class="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition">
                        <input type="radio" name="payment_method" value="bkash" onchange="togglePaymentFields()" class="text-blue-600">
                        <div>
                            <span class="font-medium text-pink-600">bKash</span>
                            <p class="text-sm text-gray-500">Send money to: <?= htmlspecialchars($bkashNumber) ?></p>
                        </div>
                    </label>
                    <label class="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition">
                        <input type="radio" name="payment_method" value="nagad" onchange="togglePaymentFields()" class="text-blue-600">
                        <div>
                            <span class="font-medium text-orange-600">Nagad</span>
                            <p class="text-sm text-gray-500">Send money to: <?= htmlspecialchars($nagadNumber) ?></p>
                        </div>
                    </label>
                    <label class="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition">
                        <input type="radio" name="payment_method" value="rocket" onchange="togglePaymentFields()" class="text-blue-600">
                        <div>
                            <span class="font-medium text-red-600">Rocket</span>
                            <p class="text-sm text-gray-500">Send money to: <?= htmlspecialchars($rocketNumber) ?></p>
                        </div>
                    </label>
                </div>

                <div id="payment-fields" class="hidden mt-4 space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Send Money To</label>
                        <input type="text" id="payment-number-display" readonly class="w-full border rounded-lg px-3 py-2 bg-gray-50">
                        <input type="hidden" name="payment_number" id="payment-number" value="">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Transaction ID *</label>
                        <input type="text" name="transaction_id" class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>
            </div>
        </div>

        <!-- Order Summary -->
        <div>
            <div class="bg-white rounded-xl shadow p-6 sticky top-24">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Order Summary</h2>
                <div class="space-y-3">
                    <?php foreach ($items as $item): ?>
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600"><?= htmlspecialchars($item['name']) ?> x <?= $item['quantity'] ?></span>
                        <span class="font-semibold"><?= $currency ?><?= number_format($item['price'] * $item['quantity'], 2) ?></span>
                    </div>
                    <?php endforeach; ?>
                    <hr>
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-500">Subtotal</span>
                        <span class="font-semibold"><?= $currency ?><?= number_format($subtotal, 2) ?></span>
                    </div>
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-500">Delivery Charge</span>
                        <span class="font-semibold"><?= $currency ?><?= number_format($deliveryCharge, 2) ?></span>
                    </div>
                    <hr>
                    <div class="flex justify-between text-lg">
                        <span class="font-bold text-gray-800">Total</span>
                        <span class="font-bold text-blue-600"><?= $currency ?><?= number_format($grandTotal, 2) ?></span>
                    </div>
                </div>
                <button type="submit" name="place_order" class="mt-6 w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition font-medium">Place Order</button>
                <a href="cart.php" class="mt-3 block w-full text-center text-gray-500 hover:text-gray-700 transition text-sm"><i class="fas fa-arrow-left mr-1"></i> Back to Cart</a>
            </div>
        </div>
    </form>
</div>

<script>
const bkashNumber = '<?= htmlspecialchars($bkashNumber) ?>';
const nagadNumber = '<?= htmlspecialchars($nagadNumber) ?>';
const rocketNumber = '<?= htmlspecialchars($rocketNumber) ?>';

function togglePaymentFields() {
    const method = document.querySelector('input[name="payment_method"]:checked').value;
    const fields = document.getElementById('payment-fields');
    const display = document.getElementById('payment-number-display');
    const hidden = document.getElementById('payment-number');

    if (method === 'cod') {
        fields.classList.add('hidden');
    } else {
        fields.classList.remove('hidden');
        let num = '';
        if (method === 'bkash') num = bkashNumber;
        else if (method === 'nagad') num = nagadNumber;
        else if (method === 'rocket') num = rocketNumber;
        display.value = num;
        hidden.value = num;
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>
