========================================================================
OnlineBdMart - Bangladesh Courier API & Webhook Integration Package
========================================================================

Supported Couriers:
1. Steadfast Courier (portal.steadfast.com.bd)
2. Pathao Courier (merchant.pathao.com)
3. RedX Courier (redx.com.bd)
4. Paperfly Courier (paperfly.com.bd)

DIRECTORY STRUCTURE:
--------------------
- courier-webhook.php       -> Upload to your public_html/ root folder
- includes/courier_service.php -> Upload to public_html/includes/ folder
- api/orders.php            -> Upload to public_html/api/ folder
- api/webhook.php           -> Upload to public_html/api/ folder
- admin-panel/courier-api.php -> Upload to public_html/admin-panel/ folder
- admin-panel/order-detail.php -> Upload to public_html/admin-panel/ folder
- admin-panel/header.php    -> Upload to public_html/admin-panel/ folder

HOW TO CONFIGURE:
-----------------
1. Log in to your Admin Panel -> Go to "Courier & API Hub" (admin-panel/courier-api.php).
2. Click "Generate Live Key" to create your store's secure API Key.
3. Enter your API credentials for Steadfast, Pathao, RedX, or Paperfly.
4. Copy your live Webhook URL (https://yourdomain.com/courier-webhook.php) and paste it into your Courier Merchant Portal.
5. In Admin Panel -> Orders -> Order Detail, you can now click "Send to Courier" to book parcels in 1-Click!

========================================================================
