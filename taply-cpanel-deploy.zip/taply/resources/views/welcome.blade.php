<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Taply turns your identity into a polished digital business card — shareable by link, QR, or NFC." />
  <title>Taply — Your story, one tap away</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">
  @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="landing-page">
  <div class="announcement">
    <span>New</span> Custom domains are now live for Pro members
    <a href="#pricing">Explore Pro <i data-lucide="arrow-up-right"></i></a>
  </div>

  <header class="site-header" id="top">
    <nav class="nav-shell" aria-label="Main navigation">
      <a class="brand" href="/" aria-label="Taply home"><span class="brand-mark">t</span>taply<span class="brand-dot">.</span></a>
      <div class="nav-links" id="main-nav">
        <a href="#features">Features</a>
        <a href="#how-it-works">How it works</a>
        <a href="#themes">Themes</a>
        <a href="#pricing">Pricing</a>
      </div>
      <div class="nav-actions">
        <a class="text-link" href="/login">Log in</a>
        <a class="button button-dark button-sm" href="/register">Create my card <i data-lucide="arrow-up-right"></i></a>
      </div>
      <button class="menu-button" type="button" aria-label="Toggle navigation" aria-expanded="false" aria-controls="main-nav">
        <i data-lucide="menu"></i>
      </button>
    </nav>
  </header>

  <main>
    <section class="hero section-shell">
      <div class="hero-copy">
        <div class="eyebrow hero-eyebrow"><span class="eyebrow-dot"></span> THE SMARTER BUSINESS CARD</div>
        <h1>Leave an impression<br><em>worth remembering.</em></h1>
        <p class="hero-lead">Everything about you, beautifully organized in one link. Share your work, collect leads, book meetings, and grow your network.</p>
        <div class="hero-actions">
          <a class="button button-accent" href="/register">Build your free card <i data-lucide="arrow-right"></i></a>
          <a class="button button-ghost" href="/himel"><span class="play-icon"><i data-lucide="play"></i></span> View live example</a>
        </div>
        <div class="trust-row">
          <div class="avatar-stack" aria-hidden="true">
            <span class="mini-avatar avatar-a">MK</span><span class="mini-avatar avatar-b">SN</span><span class="mini-avatar avatar-c">RA</span><span class="mini-avatar avatar-d">+2k</span>
          </div>
          <div class="trust-copy"><strong>2,000+ professionals</strong><span>sharing smarter every day</span></div>
        </div>
      </div>

      <div class="hero-visual" aria-label="Taply digital card preview">
        <div class="hero-orbit orbit-one"></div>
        <div class="hero-orbit orbit-two"></div>
        <div class="floating-note note-views"><i data-lucide="trending-up"></i><div><b>+38%</b><span>Profile views</span></div></div>
        <div class="floating-note note-share"><span class="live-dot"></span><div><b>Card is live</b><span>taply.me/himel</span></div></div>
        <div class="phone-frame hero-phone">
          <div class="phone-speaker"></div>
          <div class="phone-screen">
            <div class="profile-cover mini-cover">
              <div class="cover-grid"></div>
              <div class="cover-actions"><span><i data-lucide="share-2"></i></span><span><i data-lucide="qr-code"></i></span></div>
            </div>
            <div class="mini-profile-body">
              <img src="/images/himel.jpg" alt="Himel Ahmed" class="mini-profile-photo">
              <span class="mini-available"><i></i> Available</span>
              <h3>Himel Ahmed <i data-lucide="badge-check"></i></h3>
              <p class="mini-title">Brand Designer & Creative Director</p>
              <p class="mini-location"><i data-lucide="map-pin"></i> Dhaka, Bangladesh</p>
              <div class="mini-contact-grid"><span><i data-lucide="phone"></i></span><span class="active"><i data-lucide="message-circle"></i></span><span><i data-lucide="mail"></i></span><span><i data-lucide="globe-2"></i></span></div>
              <button class="mini-save"><i data-lucide="user-plus"></i> Save contact</button>
              <div class="mini-about"><span>ABOUT ME</span><p>I build thoughtful brands and digital experiences for ambitious people.</p></div>
            </div>
          </div>
        </div>
        <div class="scan-card"><span class="scan-icon"><i data-lucide="scan-line"></i></span><span>Tap or scan<br><b>to connect</b></span></div>
      </div>
    </section>

    <section class="logo-strip" aria-label="Trusted companies">
      <div class="section-shell logo-row">
        <p>Trusted by people at</p>
        <div class="logos"><span><b>n</b> notion</span><span class="logo-vercel">▲ Vercel</span><span class="logo-linear">◫ Linear</span><span>webflow</span><span><b>●</b> hubspot</span></div>
      </div>
    </section>

    <section class="feature-section section-shell" id="features">
      <div class="section-heading centered" data-aos="fade-up">
        <div class="eyebrow"><span class="eyebrow-dot"></span> BUILT FOR CONNECTION</div>
        <h2>More than a card.<br><em>It's your digital handshake.</em></h2>
        <p>One polished home for everything people need to know, remember, and do next.</p>
      </div>

      <div class="bento-grid">
        <article class="bento-card bento-large bento-profile" data-aos="fade-up">
          <div class="bento-copy"><span class="feature-icon coral"><i data-lucide="layout-template"></i></span><h3>Make it unmistakably yours</h3><p>Choose a theme, then shape every detail to match your personal brand — no design skills required.</p><a href="/dashboard">Explore themes <i data-lucide="arrow-right"></i></a></div>
          <div class="theme-fan" aria-hidden="true"><div class="fan-card fan-back"><span>FOLIO</span></div><div class="fan-card fan-mid"><span>STUDIO</span></div><div class="fan-card fan-front"><div class="fan-photo"><img src="/images/himel.jpg" alt=""></div><b>Himel Ahmed</b><small>Creative Director</small><div class="fan-lines"></div></div></div>
        </article>
        <article class="bento-card bento-analytics" data-aos="fade-up" data-aos-delay="80">
          <span class="feature-icon mint"><i data-lucide="bar-chart-3"></i></span><h3>Know what clicks</h3><p>See visits, link taps, saves, and where your audience comes from.</p>
          <div class="mini-chart"><div class="chart-head"><span>Profile views</span><b>1,284 <small>+18.4%</small></b></div><svg viewBox="0 0 320 100" preserveAspectRatio="none" aria-hidden="true"><path class="chart-area" d="M0 84 C38 72,52 82,88 60 S134 48,163 64 S208 36,236 42 S278 15,320 24 L320 100 L0 100 Z"></path><path class="chart-line" d="M0 84 C38 72,52 82,88 60 S134 48,163 64 S208 36,236 42 S278 15,320 24"></path></svg></div>
        </article>
        <article class="bento-card bento-share" data-aos="fade-up">
          <span class="feature-icon yellow"><i data-lucide="share-2"></i></span><h3>Share anywhere</h3><p>Link, QR, NFC, email signature — your card goes wherever you do.</p>
          <div class="share-modes"><span><i data-lucide="link-2"></i> Link</span><span class="qr-tile"><i data-lucide="qr-code"></i></span><span><i data-lucide="wifi"></i> NFC</span></div>
        </article>
        <article class="bento-card bento-leads" data-aos="fade-up" data-aos-delay="80">
          <div class="lead-visual"><div class="lead-row"><span class="lead-avatar la-one">AR</span><div><b>Ashik Rahman</b><small>Lead captured · now</small></div><span class="lead-check"><i data-lucide="check"></i></span></div><div class="lead-row"><span class="lead-avatar la-two">NT</span><div><b>Nusrat Tasnim</b><small>Booked a meeting · 2m</small></div><span class="lead-check"><i data-lucide="check"></i></span></div></div>
          <div class="bento-copy"><span class="feature-icon purple"><i data-lucide="users"></i></span><h3>Turn views into opportunities</h3><p>Collect leads, schedule appointments, and get notified the moment someone reaches out.</p><a href="#pricing">See premium features <i data-lucide="arrow-right"></i></a></div>
        </article>
      </div>
    </section>

    <section class="steps-section" id="how-it-works">
      <div class="section-shell">
        <div class="section-heading split-heading" data-aos="fade-up">
          <div><div class="eyebrow light"><span class="eyebrow-dot"></span> SIMPLE BY DESIGN</div><h2>From zero to shareable<br><em>in three minutes.</em></h2></div>
          <p>No code, no complicated setup. Just add your details, choose your look, and put yourself out there.</p>
        </div>
        <div class="steps-grid">
          <article class="step-card" data-aos="fade-up"><span class="step-number">01</span><div class="step-icon"><i data-lucide="user-round"></i></div><h3>Add what matters</h3><p>Your story, links, services, portfolio, payment methods, and everything in between.</p></article>
          <article class="step-card featured-step" data-aos="fade-up" data-aos-delay="100"><span class="step-number">02</span><div class="step-icon"><i data-lucide="swatch-book"></i></div><h3>Make it feel like you</h3><p>Pick a crafted theme and personalize the colors, type, and layout in a few clicks.</p></article>
          <article class="step-card" data-aos="fade-up" data-aos-delay="200"><span class="step-number">03</span><div class="step-icon"><i data-lucide="send"></i></div><h3>Share and grow</h3><p>Publish instantly, then share by URL, custom domain, QR code, or a Taply NFC card.</p></article>
        </div>
      </div>
    </section>

    <section class="themes-section section-shell" id="themes">
      <div class="section-heading themes-heading" data-aos="fade-up">
        <div><div class="eyebrow"><span class="eyebrow-dot"></span> CURATED THEMES</div><h2>A look for every<br><em>kind of professional.</em></h2></div>
        <a class="button button-outline" href="/dashboard">Browse all themes <i data-lucide="arrow-up-right"></i></a>
      </div>
      <div class="theme-gallery">
        <a class="theme-preview theme-editorial" href="/himel" data-aos="fade-up"><div class="theme-preview-inner"><small>CREATIVE DIRECTOR</small><h3>Ideas should<br><em>feel inevitable.</em></h3><span class="theme-circle-photo"><img src="/images/himel.jpg" alt="Himel Ahmed"></span><p>Selected work ↓</p><div class="theme-blocks"><i></i><i></i><i></i></div></div><span class="theme-label"><b>Editorial</b><small>Bold & expressive</small></span></a>
        <a class="theme-preview theme-minimal" href="/himel" data-aos="fade-up" data-aos-delay="80"><div class="theme-preview-inner"><img src="/images/himel.jpg" alt="Himel Ahmed"><span class="available-pill"><i></i> Available for work</span><h3>Himel Ahmed</h3><p>Independent designer helping thoughtful teams build brands that matter.</p><div class="theme-link-line">Selected work <i data-lucide="arrow-up-right"></i></div></div><span class="theme-label"><b>Minimal</b><small>Clean & confident</small></span></a>
        <a class="theme-preview theme-night" href="/himel" data-aos="fade-up" data-aos-delay="160"><div class="theme-preview-inner"><div class="night-top"><span>HA®</span><small>DHAKA / 23:14</small></div><h3>DESIGNING<br>WITH <em>INTENT</em></h3><div class="night-photo"><img src="/images/himel.jpg" alt="Himel Ahmed"></div><div class="night-footer">BRAND · DIGITAL · DIRECTION <i data-lucide="asterisk"></i></div></div><span class="theme-label"><b>Obsidian</b><small>Dark & cinematic</small></span></a>
      </div>
    </section>

    <section class="pricing-section" id="pricing">
      <div class="section-shell pricing-shell">
        <div class="section-heading centered" data-aos="fade-up">
          <div class="eyebrow"><span class="eyebrow-dot"></span> SIMPLE PRICING</div>
          <h2>Start free. Go further<br><em>when you're ready.</em></h2>
          <div class="billing-switch"><button class="active" data-billing="monthly">Monthly</button><button data-billing="yearly">Yearly <span>Save 20%</span></button></div>
        </div>
        <div class="pricing-grid">
          <article class="price-card" data-aos="fade-up"><div class="plan-name">Starter</div><p>For a polished online presence.</p><div class="price"><sup>$</sup><strong data-monthly="0" data-yearly="0">0</strong><span>/ forever</span></div><a class="button button-outline full" href="/register">Get started free</a><ul><li><i data-lucide="check"></i> One digital vCard</li><li><i data-lucide="check"></i> Core content blocks</li><li><i data-lucide="check"></i> QR code sharing</li><li><i data-lucide="check"></i> Basic analytics</li></ul></article>
          <article class="price-card pro-card" data-aos="fade-up" data-aos-delay="100"><div class="popular-label">MOST POPULAR</div><div class="plan-name">Professional</div><p>For people serious about growth.</p><div class="price"><sup>$</sup><strong data-monthly="9" data-yearly="7">9</strong><span>/ month</span></div><a class="button button-accent full" href="/register">Start 14-day trial <i data-lucide="arrow-right"></i></a><ul><li><i data-lucide="check"></i> Everything in Starter</li><li><i data-lucide="check"></i> Custom domain & no branding</li><li><i data-lucide="check"></i> Leads & appointment booking</li><li><i data-lucide="check"></i> Advanced analytics</li><li><i data-lucide="check"></i> Payment methods & portfolio</li></ul></article>
          <article class="price-card" data-aos="fade-up" data-aos-delay="200"><div class="plan-name">Business</div><p>For teams and organizations.</p><div class="price"><sup>$</sup><strong data-monthly="29" data-yearly="23">29</strong><span>/ month</span></div><a class="button button-outline full" href="mailto:hello@taply.me">Talk to sales</a><ul><li><i data-lucide="check"></i> Five team members</li><li><i data-lucide="check"></i> Central admin dashboard</li><li><i data-lucide="check"></i> Roles & permissions</li><li><i data-lucide="check"></i> Priority support</li></ul></article>
        </div>
      </div>
    </section>

    <section class="testimonial section-shell" data-aos="fade-up">
      <div class="quote-mark">“</div>
      <blockquote>Taply made my online presence feel as considered as the work I put into my clients. I share it after every meeting — and people actually remember it.</blockquote>
      <div class="quote-person"><span class="quote-avatar">SA</span><div><b>Sadia Alam</b><span>Architect & Founder, Form Studio</span></div></div>
    </section>

    <section class="final-cta section-shell" data-aos="fade-up">
      <div class="cta-scribble"><svg viewBox="0 0 190 130" aria-hidden="true"><path d="M178 8C115 10 31 24 21 79c-6 32 25 43 54 35 23-7 40-25 46-47"></path><path d="M112 76l11-12 9 15"></path></svg></div>
      <div class="eyebrow light"><span class="eyebrow-dot"></span> YOUR NEXT HELLO STARTS HERE</div>
      <h2>One link. Every side of you.<br><em>Ready when you are.</em></h2>
      <a class="button button-accent" href="/register">Create your free card <i data-lucide="arrow-right"></i></a>
      <p>No credit card. Live in minutes.</p>
    </section>
  </main>

  <footer class="site-footer">
    <div class="section-shell footer-grid">
      <div class="footer-brand"><a class="brand light-brand" href="/"><span class="brand-mark">t</span>taply<span class="brand-dot">.</span></a><p>A better way to introduce yourself, share your work, and stay connected.</p><div class="footer-socials"><a href="#" aria-label="Instagram"><i data-lucide="instagram"></i></a><a href="#" aria-label="LinkedIn"><i data-lucide="linkedin"></i></a><a href="#" aria-label="Facebook"><i data-lucide="facebook"></i></a><a href="#" aria-label="YouTube"><i data-lucide="youtube"></i></a></div></div>
      <div class="footer-links"><div><b>Product</b><a href="#features">Features</a><a href="#themes">Themes</a><a href="#pricing">Pricing</a><a href="/himel">Example card</a></div><div><b>Company</b><a href="#">About</a><a href="#">Journal</a><a href="#">Careers</a><a href="#">Contact</a></div><div><b>Resources</b><a href="#">Help center</a><a href="#">NFC cards</a><a href="#">Community</a><a href="#">Status</a></div></div>
    </div>
    <div class="section-shell footer-bottom"><span>© 2026 Taply, Inc.</span><div><a href="#">Privacy</a><a href="#">Terms</a><a href="#">Cookies</a></div><span>Made with care in Dhaka <span class="heart">♥</span></span></div>
  </footer>
</body>
</html>
