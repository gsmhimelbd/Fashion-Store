/**
 * OnlineBdMart - Full-featured Live Preview Server
 * Header: Home | Shop | Wholesale | Categories | Deals | Blog | Contact
 * Top Bar: Track Order, Hotline, Sign In / Sign Up
 * Admin URL: /admin-panel/* (21 Functional Features matching onlinebdmart.com/admin.html)
 */

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const url = require('node:url');
const querystring = require('node:querystring');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = process.env.PORT || 8000;
const DB_PATH = path.join(__dirname, 'database', 'database.sqlite');

fs.mkdirSync(path.join(__dirname, 'database'), { recursive: true });
fs.mkdirSync(path.join(__dirname, 'public', 'uploads'), { recursive: true });
fs.mkdirSync(path.join(__dirname, 'public', 'images'), { recursive: true });

const db = new DatabaseSync(DB_PATH);

// Helper to get settings
function getSettings() {
    const rows = db.prepare('SELECT setting_key, setting_value FROM settings').all();
    const map = {};
    for (const r of rows) map[r.setting_key] = r.setting_value;
    return map;
}

const sessions = new Map();

function parseCookies(req) {
    const list = {};
    const rc = req.headers.cookie;
    if (rc) {
        rc.split(';').forEach(cookie => {
            const parts = cookie.split('=');
            list[parts.shift().trim()] = decodeURI(parts.join('='));
        });
    }
    return list;
}

function getSession(req, res) {
    const cookies = parseCookies(req);
    let sid = cookies['fashion_session'];
    if (!sid || !sessions.has(sid)) {
        sid = crypto.randomBytes(16).toString('hex');
        sessions.set(sid, { cart: {}, applied_coupon: null, admin: null, customer: null });
        res.setHeader('Set-Cookie', `fashion_session=${sid}; Path=/; HttpOnly; SameSite=Lax`);
    }
    return sessions.get(sid);
}

function parseBody(req) {
    return new Promise((resolve) => {
        let body = '';
        req.on('data', chunk => { body += chunk.toString(); });
        req.on('end', () => {
            const contentType = req.headers['content-type'] || '';
            if (contentType.includes('application/json')) {
                try { resolve(JSON.parse(body || '{}')); } catch (e) { resolve({}); }
            } else {
                resolve(querystring.parse(body));
            }
        });
    });
}

function serveStatic(req, res, pathname) {
    const filePath = path.join(__dirname, 'public', pathname);
    if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) return false;
    const ext = path.extname(filePath).toLowerCase();
    const mimeTypes = {
        '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.css': 'text/css',
        '.js': 'application/javascript', '.json': 'application/json', '.ico': 'image/x-icon'
    };
    res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'application/octet-stream' });
    fs.createReadStream(filePath).pipe(res);
    return true;
}

// Master Public Layout
function renderLayout(title, content, sessionData, activeNav = '') {
    const s = getSettings();
    const categories = db.prepare('SELECT c.*, (SELECT COUNT(*) FROM products WHERE category_id = c.id) as products_count FROM categories c').all();
    const cartItems = Object.values(sessionData.cart || {});
    const cartCount = cartItems.reduce((sum, i) => sum + i.quantity, 0);
    const subtotal = cartItems.reduce((sum, i) => sum + (i.price * i.quantity), 0);
    const customer = sessionData.customer;

    return `<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title} - ${s.store_name || 'OnlineBdMart'}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,600;0,700;1,600&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        serif: ['"Playfair Display"', 'serif'],
                    },
                    colors: {
                        primary: {
                            50: '#eef2ff', 100: '#e0e7ff', 200: '#c7d2fe', 300: '#a5b4fc',
                            400: '#818cf8', 500: '#6366f1', 600: '#4f46e5', 700: '#4338ca',
                            800: '#3730a3', 900: '#312e81', 950: '#1e1b4b'
                        }
                    }
                }
            }
        }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.13.5/dist/cdn.min.js"></script>
    <style>[x-cloak] { display: none !important; } ::-webkit-scrollbar { width: 6px; height: 6px; } ::-webkit-scrollbar-track { background: #f1f5f9; } ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 9999px; }</style>
</head>
<body class="bg-slate-50 text-slate-800 font-sans antialiased min-h-screen flex flex-col selection:bg-indigo-600 selection:text-white" x-data="mainApp()">

    <!-- 1. Top Utility Bar with Track Order, Hotline, Sign In / Sign Up -->
    <div class="bg-slate-900 text-slate-300 text-xs py-2 px-4 border-b border-slate-800">
        <div class="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
            <div class="flex items-center gap-2 overflow-hidden text-xs">
                <span class="inline-flex items-center justify-center px-2 py-0.5 rounded text-[10px] font-black bg-indigo-600 text-white tracking-wider uppercase">Hot</span>
                <p class="font-medium truncate">${s.announcement_bar || 'Free Delivery Tangail ৳50 | Others ৳150 • Free Shipping above ৳2000'}</p>
            </div>

            <div class="flex items-center gap-4 text-xs font-semibold text-slate-300">
                <a href="/track-order" class="hover:text-indigo-400 transition flex items-center gap-1.5 text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-500/30 px-3 py-1 rounded-full">
                    <i class="fas fa-truck-fast"></i> <span>Track Order</span>
                </a>
                <span class="text-slate-700">|</span>
                <a href="tel:${s.contact_phone || '01775153740'}" class="hover:text-white transition flex items-center gap-1">
                    <i class="fas fa-phone text-emerald-400"></i> ${s.contact_phone || '01775153740'}
                </a>
                <span class="text-slate-700">|</span>
                ${customer ? `
                    <a href="/account" class="hover:text-indigo-300 transition flex items-center gap-1 text-indigo-400 font-bold">
                        <i class="fas fa-user-check"></i> ${customer.name}
                    </a>
                ` : `
                    <div class="flex items-center gap-2">
                        <a href="/login" class="hover:text-white transition"><i class="fas fa-arrow-right-to-bracket"></i> Sign In</a>
                        <span class="text-slate-700">/</span>
                        <a href="/register" class="hover:text-indigo-400 transition text-indigo-300 font-bold">Sign Up</a>
                    </div>
                `}
            </div>
        </div>
    </div>

    <!-- 2. Main Header (Logo, Category Search Bar, Wishlist & Cart Drawer) -->
    <header class="sticky top-0 z-40 bg-white shadow-sm border-b border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between gap-4 py-4">
                
                <div class="flex items-center gap-3">
                    <button type="button" @click="mobileMenuOpen = true" class="lg:hidden p-2 text-slate-700 hover:bg-slate-100 rounded-xl">
                        <i class="fas fa-bars-staggered text-xl"></i>
                    </button>
                    <a href="/" class="flex items-center gap-3 group">
                        <div class="w-11 h-11 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-cyan-500 flex items-center justify-center text-white text-xl shadow-md group-hover:scale-105 transition-transform">
                            <i class="fas fa-bag-shopping"></i>
                        </div>
                        <div>
                            <span class="text-xl sm:text-2xl font-black tracking-tight text-slate-900 leading-none block">${(s.store_name || 'ONLINEBDMART').toUpperCase()}</span>
                            <span class="text-[10px] tracking-widest font-extrabold text-indigo-600 uppercase block mt-0.5">Online Shopping BD</span>
                        </div>
                    </a>
                </div>

                <!-- Big Search Bar with Categories Select -->
                <div class="hidden md:flex flex-1 max-w-2xl mx-4">
                    <form method="GET" action="/shop" class="w-full flex items-center rounded-2xl border-2 border-indigo-600 bg-white overflow-hidden shadow-sm relative">
                        <div class="border-r border-slate-200 bg-slate-50 px-3 py-2.5 shrink-0">
                            <select name="category" class="text-xs font-bold text-slate-700 bg-transparent outline-none cursor-pointer">
                                <option value="">All Categories</option>
                                ${categories.map(c => `<option value="${c.slug}">${c.name}</option>`).join('')}
                            </select>
                        </div>
                        <div class="flex-1 relative">
                            <input type="text" name="search" x-model="searchQuery"
                                   @input.debounce.250ms="fetchSuggestions()"
                                   @focus="if (suggestions.length > 0) suggestionsOpen = true"
                                   @click.away="suggestionsOpen = false"
                                   placeholder="Search products, watches, leather wallets, sunglasses, gadgets..." 
                                   class="w-full px-4 py-2.5 text-xs text-slate-800 outline-none font-medium">
                            <div x-show="suggestionsOpen && suggestions.length > 0" x-cloak class="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl shadow-2xl border border-slate-100 p-2 z-50 divide-y max-h-80 overflow-y-auto">
                                <template x-for="item in suggestions" :key="item.id">
                                    <a :href="item.url" class="flex items-center gap-3 p-2 rounded-xl hover:bg-indigo-50 transition">
                                        <img :src="'/' + item.image" class="w-9 h-9 object-cover rounded-lg border shrink-0">
                                        <div class="flex-1 min-w-0">
                                            <p class="text-xs font-bold text-slate-800 truncate" x-text="item.name"></p>
                                            <p class="text-xs font-extrabold text-indigo-600" x-text="item.formatted_price"></p>
                                        </div>
                                    </a>
                                </template>
                            </div>
                        </div>
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 font-bold text-xs flex items-center gap-1.5 transition">
                            <i class="fas fa-search"></i> <span>Search</span>
                        </button>
                    </form>
                </div>

                <div class="flex items-center gap-3 sm:gap-4">
                    <button type="button" @click="wishlistOpen = true" class="relative p-2.5 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-600 transition">
                        <i class="far fa-heart text-lg"></i>
                        <span class="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-black rounded-full h-4 min-w-[16px] px-1 flex items-center justify-center" x-show="wishlistCount > 0" x-text="wishlistCount">0</span>
                    </button>

                    <button type="button" @click="cartOpen = true" class="relative p-2 sm:px-4 sm:py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white transition flex items-center gap-2.5 shadow-md">
                        <i class="fas fa-bag-shopping text-lg"></i>
                        <div class="hidden sm:block text-left text-xs leading-tight">
                            <span class="text-[10px] text-indigo-200 block">My Bag</span>
                            <span class="font-black" x-text="formatCurrency(subtotal)">৳0.00</span>
                        </div>
                        <span class="hidden sm:flex bg-white/20 text-white text-[11px] font-extrabold rounded-full px-2 py-0.5 items-center justify-center" x-text="cartCount">${cartCount}</span>
                    </button>
                </div>
            </div>

            <div class="pb-3 md:hidden">
                <form method="GET" action="/shop" class="flex items-center rounded-xl border border-slate-300 bg-white overflow-hidden">
                    <input type="text" name="search" placeholder="Search products..." class="flex-1 px-3 py-2 text-xs outline-none">
                    <button type="submit" class="bg-indigo-600 text-white px-4 py-2 text-xs font-bold"><i class="fas fa-search"></i></button>
                </form>
            </div>
        </div>

        <!-- 3. Exact Navigation Menu (Home | Shop | Wholesale | Categories | Deals | Blog | Contact) -->
        <div class="hidden lg:block bg-slate-900 text-white border-t border-slate-800">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
                <nav class="flex items-center space-x-1 text-xs font-bold text-slate-200">
                    <a href="/" class="px-4 py-3.5 hover:text-indigo-400 hover:bg-slate-800 transition ${activeNav === 'home' ? 'text-indigo-400 bg-slate-800' : ''}">Home</a>
                    <a href="/shop" class="px-4 py-3.5 hover:text-indigo-400 hover:bg-slate-800 transition ${activeNav === 'shop' ? 'text-indigo-400 bg-slate-800' : ''}">Shop</a>
                    <a href="/wholesale" class="px-4 py-3.5 hover:text-amber-400 hover:bg-slate-800 transition text-amber-300 ${activeNav === 'wholesale' ? 'bg-slate-800 text-amber-400' : ''}"><i class="fas fa-boxes-stacked mr-1"></i> Wholesale</a>
                    <a href="/categories" class="px-4 py-3.5 hover:text-indigo-400 hover:bg-slate-800 transition ${activeNav === 'categories' ? 'text-indigo-400 bg-slate-800' : ''}">Categories</a>
                    <a href="/deals" class="px-4 py-3.5 hover:text-rose-400 hover:bg-slate-800 transition text-rose-300 ${activeNav === 'deals' ? 'bg-slate-800 text-rose-400' : ''}"><i class="fas fa-fire mr-1"></i> Deals</a>
                    <a href="/blog" class="px-4 py-3.5 hover:text-indigo-400 hover:bg-slate-800 transition ${activeNav === 'blog' ? 'text-indigo-400 bg-slate-800' : ''}">Blog</a>
                    <a href="/contact" class="px-4 py-3.5 hover:text-indigo-400 hover:bg-slate-800 transition ${activeNav === 'contact' ? 'text-indigo-400 bg-slate-800' : ''}">Contact</a>
                </nav>

                <div class="flex items-center gap-2 text-xs font-bold text-slate-300 py-3.5">
                    <i class="fab fa-whatsapp text-emerald-400 text-base"></i>
                    <a href="https://wa.me/88${s.whatsapp_number || '01775153740'}" target="_blank" class="hover:text-emerald-400 transition">Hotline: ${s.whatsapp_number || '01775153740'}</a>
                </div>
            </div>
        </div>
    </header>

    <!-- Mobile Slide-out Menu -->
    <div x-show="mobileMenuOpen" x-cloak class="fixed inset-0 z-50 flex lg:hidden">
        <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm" @click="mobileMenuOpen = false"></div>
        <div class="relative max-w-xs w-full bg-white h-full shadow-2xl flex flex-col justify-between py-6 px-6 overflow-y-auto" x-transition>
            <div>
                <div class="flex items-center justify-between pb-6 border-b">
                    <span class="font-extrabold text-lg text-slate-900">${s.store_name || 'OnlineBdMart'}</span>
                    <button type="button" @click="mobileMenuOpen = false" class="text-slate-400"><i class="fas fa-times text-xl"></i></button>
                </div>
                <div class="mt-6 space-y-1 text-xs font-bold">
                    <a href="/" class="block px-4 py-3 rounded-xl hover:bg-indigo-50">🏠 Home</a>
                    <a href="/shop" class="block px-4 py-3 rounded-xl hover:bg-indigo-50">🛍️ Shop</a>
                    <a href="/wholesale" class="block px-4 py-3 rounded-xl text-amber-700 bg-amber-50">📦 Wholesale / B2B</a>
                    <a href="/categories" class="block px-4 py-3 rounded-xl hover:bg-indigo-50">🏷️ Categories</a>
                    <a href="/deals" class="block px-4 py-3 rounded-xl text-rose-600 hover:bg-rose-50">🔥 Hot Deals</a>
                    <a href="/blog" class="block px-4 py-3 rounded-xl hover:bg-indigo-50">📰 Blog & Guides</a>
                    <a href="/contact" class="block px-4 py-3 rounded-xl hover:bg-indigo-50">📞 Contact Us</a>
                    <a href="/track-order" class="block px-4 py-3 rounded-xl text-emerald-700 bg-emerald-50">🚚 Track Order</a>
                </div>
            </div>
            <div class="pt-6 border-t space-y-2">
                <a href="/track-order" class="block w-full py-2.5 bg-emerald-50 text-emerald-800 font-bold rounded-xl text-xs text-center">Track Order Live</a>
                <a href="/login" class="block w-full py-2.5 bg-indigo-600 text-white font-bold rounded-xl text-xs text-center">Sign In / Sign Up</a>
            </div>
        </div>
    </div>

    <!-- Sliding Cart Drawer -->
    <div x-show="cartOpen" x-cloak class="fixed inset-0 z-50 overflow-hidden">
        <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" @click="cartOpen = false"></div>
        <div class="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <div class="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between" x-transition>
                <div class="p-5 border-b flex items-center justify-between bg-slate-50">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-bag-shopping text-indigo-600"></i>
                        <h2 class="text-base font-extrabold text-slate-900">Your Cart (<span x-text="cartCount">${cartCount}</span>)</h2>
                    </div>
                    <button type="button" @click="cartOpen = false" class="p-2 text-slate-400 hover:text-slate-600"><i class="fas fa-times"></i></button>
                </div>

                <div class="flex-1 overflow-y-auto p-5 space-y-4">
                    <template x-if="items.length === 0">
                        <div class="h-full flex flex-col items-center justify-center text-center py-12">
                            <i class="fas fa-shopping-basket text-slate-200 text-5xl mb-4"></i>
                            <h3 class="font-bold text-slate-800">Your Cart is Empty</h3>
                            <a href="/shop" @click="cartOpen = false" class="mt-4 px-6 py-2.5 bg-indigo-600 text-white font-bold rounded-xl text-xs shadow">Start Shopping</a>
                        </div>
                    </template>

                    <template x-for="item in items" :key="item.id">
                        <div class="flex gap-4 p-3 rounded-2xl bg-slate-50 border">
                            <img :src="'/' + item.image" class="w-16 h-16 object-cover rounded-xl bg-white border shrink-0">
                            <div class="flex-1 min-w-0 flex flex-col justify-between">
                                <div>
                                    <div class="flex items-start justify-between gap-2">
                                        <h4 class="text-xs font-bold text-slate-800 line-clamp-1" x-text="item.name"></h4>
                                        <button @click="removeItem(item.id)" class="text-slate-300 hover:text-rose-500"><i class="fas fa-trash-can text-xs"></i></button>
                                    </div>
                                    <p class="text-xs font-bold text-indigo-600" x-text="formatCurrency(item.price)"></p>
                                </div>
                                <div class="flex items-center justify-between mt-2">
                                    <div class="flex items-center border rounded-lg bg-white">
                                        <button @click="updateQty(item.id, item.quantity - 1)" class="w-6 h-6 flex items-center justify-center text-xs">-</button>
                                        <span class="w-8 text-center text-xs font-bold" x-text="item.quantity"></span>
                                        <button @click="updateQty(item.id, item.quantity + 1)" class="w-6 h-6 flex items-center justify-center text-xs">+</button>
                                    </div>
                                    <span class="text-xs font-extrabold" x-text="formatCurrency(item.price * item.quantity)"></span>
                                </div>
                            </div>
                        </div>
                    </template>
                </div>

                <div class="p-5 border-t bg-slate-50 space-y-3" x-show="items.length > 0">
                    <div class="flex justify-between text-sm font-extrabold text-slate-900">
                        <span>Subtotal:</span>
                        <span class="text-indigo-600" x-text="formatCurrency(subtotal)"></span>
                    </div>
                    <div class="grid grid-cols-2 gap-2.5">
                        <a href="/cart" class="py-3 px-4 bg-white border font-bold rounded-xl text-xs text-center hover:bg-slate-100">View Cart</a>
                        <a href="/checkout" class="py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs text-center shadow">Checkout &rarr;</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Wishlist Drawer -->
    <div x-show="wishlistOpen" x-cloak class="fixed inset-0 z-50 overflow-hidden">
        <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" @click="wishlistOpen = false"></div>
        <div class="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <div class="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between" x-transition>
                <div class="p-5 border-b flex items-center justify-between bg-slate-50">
                    <div class="flex items-center gap-2 text-rose-600 font-bold">
                        <i class="fas fa-heart"></i>
                        <h2 class="text-base text-slate-900">Your Wishlist (<span x-text="wishlistCount">0</span>)</h2>
                    </div>
                    <button type="button" @click="wishlistOpen = false" class="p-2 text-slate-400 hover:text-slate-600"><i class="fas fa-times"></i></button>
                </div>

                <div class="flex-1 overflow-y-auto p-5 space-y-4">
                    <template x-if="wishlist.length === 0">
                        <div class="h-full flex flex-col items-center justify-center text-center py-12">
                            <i class="far fa-heart text-slate-200 text-5xl mb-4"></i>
                            <h3 class="font-bold text-slate-800">Your Wishlist is Empty</h3>
                            <a href="/shop" @click="wishlistOpen = false" class="mt-4 px-6 py-2.5 bg-indigo-600 text-white font-bold rounded-xl text-xs">Browse Items</a>
                        </div>
                    </template>

                    <template x-for="item in wishlist" :key="item.id">
                        <div class="flex gap-4 p-3 rounded-2xl bg-slate-50 border items-center justify-between">
                            <div class="flex items-center gap-3">
                                <img :src="'/' + item.image" class="w-14 h-14 object-cover rounded-xl bg-white border shrink-0">
                                <div>
                                    <h4 class="text-xs font-bold text-slate-800 line-clamp-1" x-text="item.name"></h4>
                                    <p class="text-xs font-bold text-indigo-600 mt-0.5" x-text="formatCurrency(item.price)"></p>
                                </div>
                            </div>
                            <div class="flex items-center gap-2">
                                <button @click="addToCart(item.id); removeFromWishlist(item.id)" class="px-3 py-1.5 bg-slate-900 text-white text-[11px] font-bold rounded-lg">Add to Cart</button>
                                <button @click="removeFromWishlist(item.id)" class="text-slate-300 hover:text-rose-500"><i class="fas fa-trash-can text-xs"></i></button>
                            </div>
                        </div>
                    </template>
                </div>

                <div class="p-5 border-t bg-slate-50">
                    <a href="/shop" @click="wishlistOpen = false" class="block w-full py-3 bg-slate-900 text-white font-bold rounded-xl text-xs text-center">Continue Shopping</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content Yield -->
    <main class="flex-1">
        ${content}
    </main>

    <!-- Mobile Bottom Navigation Bar -->
    <div class="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-6 py-2.5 flex items-center justify-between text-[10px] font-bold text-slate-600 shadow-xl">
        <a href="/" class="flex flex-col items-center gap-1 ${activeNav === 'home' ? 'text-indigo-600' : ''}">
            <i class="fas fa-house text-base"></i> <span>Home</span>
        </a>
        <a href="/shop" class="flex flex-col items-center gap-1 ${activeNav === 'shop' ? 'text-indigo-600' : ''}">
            <i class="fas fa-boxes-stacked text-base"></i> <span>Shop</span>
        </a>
        <a href="/wholesale" class="flex flex-col items-center gap-1 text-amber-600 ${activeNav === 'wholesale' ? 'text-amber-700 font-extrabold' : ''}">
            <i class="fas fa-boxes-packing text-base"></i> <span>Wholesale</span>
        </a>
        <a href="/track-order" class="flex flex-col items-center gap-1 text-emerald-600 font-extrabold">
            <i class="fas fa-truck-fast text-base"></i> <span>Track</span>
        </a>
        <button type="button" @click="cartOpen = true" class="flex flex-col items-center gap-1 relative text-indigo-600">
            <i class="fas fa-bag-shopping text-base"></i> <span>Bag</span>
            <span class="absolute -top-1.5 right-1 bg-amber-400 text-slate-950 text-[9px] font-black rounded-full h-3.5 min-w-[14px] px-0.5 flex items-center justify-center" x-text="cartCount">${cartCount}</span>
        </button>
    </div>

    <a href="https://wa.me/88${s.whatsapp_number || '01775153740'}" target="_blank" title="WhatsApp Support" class="fixed bottom-16 lg:bottom-6 right-6 z-30 w-14 h-14 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-all duration-300">
        <i class="fab fa-whatsapp text-2xl"></i>
    </a>

    <div id="toast-container" class="fixed bottom-20 lg:bottom-6 left-6 z-50 flex flex-col gap-2 max-w-sm"></div>

    <footer class="bg-slate-950 text-white pt-16 pb-20 lg:pb-12 border-t border-slate-800">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-slate-800">
                <div class="space-y-4">
                    <h3 class="text-xl font-extrabold">${s.store_name || 'OnlineBdMart'}</h3>
                    <p class="text-slate-400 text-xs sm:text-sm leading-relaxed">${s.store_tagline || 'Premium Wholesale & Retail in Bangladesh.'}</p>
                    <p class="text-xs text-slate-500">${s.store_address || 'Tangail, Bangladesh'}</p>
                </div>
                <div>
                    <h4 class="font-bold text-xs uppercase tracking-wider text-slate-200 mb-4">Quick Navigation</h4>
                    <ul class="space-y-2 text-xs text-slate-400">
                        <li><a href="/" class="hover:text-white">Home</a></li>
                        <li><a href="/shop" class="hover:text-white">All Products</a></li>
                        <li><a href="/wholesale" class="hover:text-white text-amber-400">Wholesale / B2B Rate</a></li>
                        <li><a href="/categories" class="hover:text-white">Categories</a></li>
                        <li><a href="/deals" class="hover:text-white text-rose-400">Hot Deals %</a></li>
                        <li><a href="/blog" class="hover:text-white">Buying Guides</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-bold text-xs uppercase tracking-wider text-slate-200 mb-4">Customer Care</h4>
                    <ul class="space-y-2 text-xs text-slate-400 font-semibold">
                        <li><a href="/track-order" class="text-emerald-400 hover:underline">📦 Track Your Order</a></li>
                        <li><a href="/contact" class="hover:text-white">📞 Help Center & Contact</a></li>
                        <li><a href="/cart" class="hover:text-white">🛒 View Shopping Cart</a></li>
                        <li><a href="/checkout" class="hover:text-white">⚡ Express Checkout</a></li>
                        <li><a href="/admin-panel/login" class="hover:text-white text-slate-500">🔐 Admin Portal</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-bold text-xs uppercase tracking-wider text-slate-200 mb-4">Accepted Payments</h4>
                    <div class="flex flex-wrap gap-2 text-xs text-slate-300">
                        <span class="px-2.5 py-1 bg-slate-900 rounded font-bold text-emerald-400">Cash on Delivery</span>
                        <span class="px-2.5 py-1 bg-slate-900 rounded font-bold text-pink-400">bKash</span>
                        <span class="px-2.5 py-1 bg-slate-900 rounded font-bold text-orange-400">Nagad</span>
                        <span class="px-2.5 py-1 bg-slate-900 rounded font-bold text-purple-400">Rocket</span>
                    </div>
                </div>
            </div>
            <div class="pt-8 text-center text-xs text-slate-500">
                &copy; ${new Date().getFullYear()} ${s.store_name || 'OnlineBdMart'} • Online Shopping Bangladesh. Built with Laravel 11 & Tailwind CSS.
            </div>
        </div>
    </footer>

    <script>
        function mainApp() {
            return {
                mobileMenuOpen: false,
                cartOpen: false,
                wishlistOpen: false,
                searchQuery: '',
                suggestionsOpen: false,
                suggestions: [],
                cartCount: ${cartCount},
                subtotal: ${subtotal},
                items: ${JSON.stringify(cartItems)},
                wishlist: JSON.parse(localStorage.getItem('user_wishlist') || '[]'),

                get wishlistCount() { return this.wishlist.length; },

                formatCurrency(amt) {
                    return '৳' + Number(amt || 0).toLocaleString('en-BD', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                },

                fetchSuggestions() {
                    if (this.searchQuery.length < 2) {
                        this.suggestions = [];
                        this.suggestionsOpen = false;
                        return;
                    }
                    fetch('/search-suggestions?q=' + encodeURIComponent(this.searchQuery))
                        .then(r => r.json())
                        .then(d => { this.suggestions = d; this.suggestionsOpen = true; });
                },

                addToCart(productId, quantity = 1) {
                    fetch('/cart/add', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ product_id: productId, quantity: quantity })
                    })
                    .then(r => r.json())
                    .then(d => {
                        if (d.success) {
                            this.cartCount = d.count;
                            this.subtotal = d.subtotal;
                            this.items = d.items;
                            this.cartOpen = true;
                            showToast('Added to your bag!', 'success');
                        }
                    });
                },

                updateQty(productId, qty) {
                    fetch('/cart/update', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ product_id: productId, quantity: qty })
                    })
                    .then(r => r.json())
                    .then(d => {
                        if (d.success) {
                            this.cartCount = d.count;
                            this.subtotal = d.subtotal;
                            if (qty <= 0) {
                                this.items = this.items.filter(i => i.id !== productId);
                            } else {
                                const found = this.items.find(i => i.id === productId);
                                if (found) found.quantity = qty;
                            }
                        }
                    });
                },

                removeItem(productId) {
                    fetch('/cart/remove', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ product_id: productId })
                    })
                    .then(r => r.json())
                    .then(d => {
                        if (d.success) {
                            this.cartCount = d.count;
                            this.subtotal = d.subtotal;
                            this.items = this.items.filter(i => i.id !== productId);
                            showToast('Item removed from cart.', 'info');
                        }
                    });
                },

                toggleWishlist(prod) {
                    const exists = this.wishlist.some(i => i.id === prod.id);
                    if (exists) {
                        this.wishlist = this.wishlist.filter(i => i.id !== prod.id);
                        showToast('Removed from wishlist.', 'info');
                    } else {
                        this.wishlist.push(prod);
                        showToast('Saved to wishlist!', 'success');
                    }
                    localStorage.setItem('user_wishlist', JSON.stringify(this.wishlist));
                },

                removeFromWishlist(pid) {
                    this.wishlist = this.wishlist.filter(i => i.id !== pid);
                    localStorage.setItem('user_wishlist', JSON.stringify(this.wishlist));
                },

                isInWishlist(pid) {
                    return this.wishlist.some(i => i.id === pid);
                }
            }
        }

        function showToast(msg, type = 'success') {
            const c = document.getElementById('toast-container');
            if (!c) return;
            const t = document.createElement('div');
            t.className = 'px-4 py-3 bg-slate-900 text-white rounded-2xl shadow-xl text-xs font-bold border-l-4 ' + (type === 'success' ? 'border-emerald-500' : 'border-indigo-500');
            t.textContent = msg;
            c.appendChild(t);
            setTimeout(() => t.remove(), 3500);
        }
    </script>
</body>
</html>`;
}

// 21-Item Functional Admin Layout
function renderAdminLayout(title, content, activeNav = 'dashboard') {
    const s = getSettings();
    const pendingOrders = db.prepare("SELECT COUNT(*) as c FROM orders WHERE status = 'pending'").get().c;
    const msgCount = db.prepare('SELECT COUNT(*) as c FROM wholesale_inquiries').get().c;

    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title} - Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.13.5/dist/cdn.min.js"></script>
    <style>[x-cloak] { display: none !important; } body { font-family: 'Plus Jakarta Sans', sans-serif; } ::-webkit-scrollbar { width: 5px; } ::-webkit-scrollbar-track { background: #0f172a; } ::-webkit-scrollbar-thumb { background: #334155; border-radius: 9999px; }</style>
</head>
<body class="bg-slate-100 text-slate-800 antialiased min-h-screen" x-data="{ sidebarOpen: false }">

    <div class="flex h-screen overflow-hidden">
        <!-- Full 21-Item Sidebar -->
        <aside class="fixed inset-y-0 left-0 z-50 w-64 bg-slate-950 text-slate-300 flex flex-col justify-between lg:static lg:translate-x-0 transition-transform border-r border-slate-800"
               :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">
            <div class="flex-1 overflow-y-auto">
                <div class="h-20 flex items-center justify-between px-6 border-b border-slate-800 sticky top-0 bg-slate-950/95 backdrop-blur z-10">
                    <a href="/admin-panel/dashboard" class="flex items-center gap-3">
                        <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-cyan-400 flex items-center justify-center text-white font-bold"><i class="fas fa-crown text-sm"></i></div>
                        <div>
                            <span class="text-sm font-extrabold text-white uppercase block leading-none">${s.store_name || 'ONLINEBDMART'}</span>
                            <span class="text-[10px] text-indigo-400 font-bold tracking-widest uppercase">Admin Panel</span>
                        </div>
                    </a>
                </div>

                <nav class="p-3 space-y-1 text-xs font-semibold">
                    <p class="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-3 pt-2 pb-1">Core E-Commerce</p>
                    <a href="/admin-panel/dashboard" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'dashboard' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>📊</span> <span>Dashboard</span></a>
                    <a href="/admin-panel/products" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'products' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>📦</span> <span>Products</span></a>
                    <a href="/admin-panel/wholesale" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'wholesale' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>🏭</span> <span>Wholesale / B2B</span></a>
                    <a href="/admin-panel/orders" class="flex items-center justify-between px-3 py-2 rounded-xl transition ${activeNav === 'orders' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><div class="flex items-center gap-3"><span>🧾</span> <span>Orders</span></div>${pendingOrders > 0 ? `<span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-slate-950">${pendingOrders}</span>` : ''}</a>
                    <a href="/admin-panel/banners" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'banners' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>🖼️</span> <span>Banners / Slider</span></a>
                    <a href="/admin-panel/categories" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'categories' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>📂</span> <span>Categories</span></a>
                    <a href="/admin-panel/coupons" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'coupons' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>🎟️</span> <span>Coupons</span></a>
                    <a href="/admin-panel/blogs" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'blogs' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>📝</span> <span>Blog</span></a>
                    <a href="/admin-panel/reviews" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'reviews' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>⭐</span> <span>Reviews</span></a>
                    <a href="/admin-panel/messages" class="flex items-center justify-between px-3 py-2 rounded-xl transition ${activeNav === 'messages' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><div class="flex items-center gap-3"><span>💬</span> <span>Messages</span></div>${msgCount > 0 ? `<span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-indigo-400 text-slate-950">${msgCount}</span>` : ''}</a>

                    <p class="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-3 pt-4 pb-1">Business & Operations</p>
                    <a href="/admin-panel/payments" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'payments' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>💳</span> <span>Payments</span></a>
                    <a href="/admin-panel/delivery" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'delivery' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>🚚</span> <span>Delivery</span></a>
                    <a href="/admin-panel/customers" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'customers' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>👥</span> <span>Customers</span></a>
                    <a href="/admin-panel/suppliers" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'suppliers' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>🏭</span> <span>Suppliers</span></a>
                    <a href="/admin-panel/analytics" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'analytics' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>📈</span> <span>Analytics</span></a>

                    <p class="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-3 pt-4 pb-1">Integrations & Settings</p>
                    <a href="/admin-panel/whatsapp" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'whatsapp' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>🟢</span> <span>WhatsApp</span></a>
                    <a href="/admin-panel/telegram" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'telegram' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>📨</span> <span>Telegram</span></a>
                    <a href="/admin-panel/pixel" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'pixel' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>📘</span> <span>Facebook Pixel</span></a>
                    <a href="/admin-panel/colors" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'colors' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>🎨</span> <span>Colors</span></a>
                    <a href="/admin-panel/otp" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'otp' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>🔑</span> <span>OTP System</span></a>
                    <a href="/admin-panel/seo" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'seo' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>🔍</span> <span>SEO Setup</span></a>
                    <a href="/admin-panel/settings" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'settings' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>⚙️</span> <span>Site Settings</span></a>
                    <a href="/admin-panel/profile" class="flex items-center gap-3 px-3 py-2 rounded-xl transition ${activeNav === 'profile' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-900'}"><span>👤</span> <span>Admin Profile</span></a>
                </nav>
            </div>

            <div class="p-4 border-t border-slate-800 space-y-2 bg-slate-950">
                <a href="/" target="_blank" class="flex items-center justify-center gap-2 w-full py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 font-semibold rounded-xl text-xs transition">
                    <i class="fas fa-arrow-up-right-from-square"></i> Visit Storefront
                </a>
                <div class="flex items-center justify-between pt-2 px-2">
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 rounded-full bg-indigo-600/30 text-indigo-400 font-bold flex items-center justify-center text-xs border border-indigo-500/30">A</div>
                        <div><p class="text-xs font-bold text-white leading-none">Admin</p><p class="text-[10px] text-emerald-400 mt-0.5">● Superadmin</p></div>
                    </div>
                    <a href="/admin-panel/logout" class="p-2 text-slate-400 hover:text-rose-400"><i class="fas fa-right-from-bracket"></i></a>
                </div>
            </div>
        </aside>

        <div class="flex-1 flex flex-col min-w-0 overflow-hidden">
            <header class="h-20 bg-white border-b border-slate-200 px-4 sm:px-8 flex items-center justify-between shrink-0">
                <div class="flex items-center gap-4">
                    <button @click="sidebarOpen = true" class="lg:hidden p-2 text-slate-600"><i class="fas fa-bars"></i></button>
                    <h1 class="text-lg font-bold text-slate-900">${title}</h1>
                </div>
                <div class="flex items-center gap-3">
                    <a href="/" target="_blank" class="text-xs text-slate-500 hover:text-indigo-600 font-semibold flex items-center gap-1.5"><i class="fas fa-store"></i> Customer View</a>
                    <a href="/admin-panel/products" class="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow">+ Product</a>
                </div>
            </header>

            <main class="flex-1 overflow-y-auto p-4 sm:p-8 space-y-6">
                ${content}
            </main>
        </div>
    </div>
</body>
</html>`;
}

// Main HTTP Server
const server = http.createServer(async (req, res) => {
    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;
    const method = req.method.toUpperCase();
    const isGet = method === 'GET' || method === 'HEAD';
    const sessionData = getSession(req, res);

    if (pathname.startsWith('/uploads/') || pathname.startsWith('/images/') || pathname.startsWith('/css/') || pathname.startsWith('/js/')) {
        if (serveStatic(req, res, pathname)) return;
    }

    function sendJson(data, statusCode = 200) {
        res.writeHead(statusCode, { 'Content-Type': 'application/json' });
        if (method === 'HEAD') { res.end(); return; }
        res.end(JSON.stringify(data));
    }

    function redirect(location, statusCode = 302) {
        res.writeHead(statusCode, { 'Location': location });
        res.end();
    }

    function sendHtml(html, statusCode = 200) {
        res.writeHead(statusCode, { 'Content-Type': 'text/html; charset=utf-8' });
        if (method === 'HEAD') { res.end(); return; }
        res.end(html);
    }

    // Redirect /admin to /admin-panel
    if (pathname === '/admin' || pathname === '/admin/' || pathname === '/admin/login') {
        return redirect('/admin-panel/login');
    }

    // -------------------------------------------------------------
    // Telegram Webhook API for Order Management (Buttons + Commands)
    // -------------------------------------------------------------
    if (pathname === '/api/telegram/webhook' && method === 'POST') {
        const body = await parseBody(req);

        // 1. Handle Inline Button Clicks (callback_query)
        if (body.callback_query && body.callback_query.data) {
            const data = body.callback_query.data;
            if (data.startsWith('set_status:')) {
                const parts = data.split(':');
                const newStatus = parts[1] || 'pending';
                const orderId = parseInt(parts[2] || 0, 10);
                if (orderId > 0) {
                    db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(newStatus, orderId);
                    return sendJson({ 
                        success: true, 
                        message: `Order #${orderId} status updated to ${newStatus} via Telegram!`,
                        order_id: orderId,
                        new_status: newStatus
                    });
                }
            }
        }

        // 2. Handle Text Commands (/pending, /orders, /confirm, /deliver, /cancel, /status)
        if (body.message && body.message.text) {
            const text = body.message.text.trim();
            const chatId = body.message.chat ? body.message.chat.id : null;

            if (text === '/start' || text === '/help') {
                return sendJson({
                    success: true,
                    reply: `👋 *Welcome to OnlineBdMart Telegram Order Controller*\n\nCommands:\n• /pending - View all pending orders with action buttons\n• /orders - Summary of recent orders\n• /status <id> - View order details\n• /confirm <id> - Confirm order\n• /deliver <id> - Mark delivered\n• /cancel <id> - Cancel order`
                });
            }

            if (text === '/pending' || text === '/orders') {
                const pending = db.prepare("SELECT * FROM orders WHERE status = 'pending' ORDER BY id DESC LIMIT 5").all();
                const total = db.prepare("SELECT COUNT(*) as c FROM orders WHERE status = 'pending'").get().c;
                return sendJson({
                    success: true,
                    total_pending: total,
                    orders: pending,
                    reply: `📦 Found ${total} pending orders.`
                });
            }

            if (text.startsWith('/confirm ') || text.startsWith('/deliver ') || text.startsWith('/cancel ') || text.startsWith('/ship ')) {
                const parts = text.split(' ');
                const cmd = parts[0].replace('/', '');
                const orderId = parseInt(parts[1] || 0, 10);
                const statusMap = { 'confirm': 'confirmed', 'deliver': 'delivered', 'cancel': 'cancelled', 'ship': 'shipped' };
                const newStatus = statusMap[cmd] || 'pending';

                if (orderId > 0) {
                    db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(newStatus, orderId);
                    return sendJson({
                        success: true,
                        reply: `✅ Order #${orderId} has been successfully updated to *${newStatus.toUpperCase()}* via Telegram command!`
                    });
                }
            }
        }

        return sendJson({ success: true, status: 'ok' });
    }
    if (pathname === '/login' && isGet) {
        if (sessionData.customer) return redirect('/account');
        const content = `
            <div class="max-w-md mx-auto px-4 py-16">
                <div class="bg-white p-8 rounded-3xl border shadow-xl space-y-6">
                    <div class="text-center">
                        <h2 class="text-2xl font-bold font-serif text-slate-900">Welcome Back</h2>
                        <p class="text-xs text-slate-500 mt-1">Sign in to your customer account</p>
                    </div>
                    <form method="POST" action="/login" class="space-y-4 text-xs">
                        <div>
                            <label class="block font-bold mb-1">Email or Phone</label>
                            <input type="text" name="email" required placeholder="user@example.com / 017XXXXXXXX" class="w-full border rounded-xl px-3.5 py-2.5 outline-none">
                        </div>
                        <div>
                            <label class="block font-bold mb-1">Password</label>
                            <input type="password" name="password" required placeholder="••••••••" class="w-full border rounded-xl px-3.5 py-2.5 outline-none">
                        </div>
                        <button type="submit" class="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-xl shadow">Sign In &rarr;</button>
                    </form>
                    <div class="text-center text-xs text-slate-500">
                        Don't have an account? <a href="/register" class="text-indigo-600 font-bold hover:underline">Create Account</a>
                    </div>
                </div>
            </div>
        `;
        return sendHtml(renderLayout('Customer Sign In', content, sessionData));
    }

    if (pathname === '/login' && method === 'POST') {
        const body = await parseBody(req);
        sessionData.customer = { id: 1, name: body.email.split('@')[0] || 'Customer', email: body.email, phone: '01711223344' };
        return redirect('/account');
    }

    if (pathname === '/register' && isGet) {
        if (sessionData.customer) return redirect('/account');
        const content = `
            <div class="max-w-md mx-auto px-4 py-16">
                <div class="bg-white p-8 rounded-3xl border shadow-xl space-y-6">
                    <div class="text-center">
                        <h2 class="text-2xl font-bold font-serif text-slate-900">Create Account</h2>
                        <p class="text-xs text-slate-500 mt-1">Sign up for faster checkout & tracking</p>
                    </div>
                    <form method="POST" action="/register" class="space-y-4 text-xs">
                        <div><label class="block font-bold mb-1">Full Name</label><input type="text" name="name" required placeholder="Tanvir Ahmed" class="w-full border rounded-xl px-3.5 py-2.5 outline-none"></div>
                        <div><label class="block font-bold mb-1">Phone Number</label><input type="tel" name="phone" required placeholder="01711223344" class="w-full border rounded-xl px-3.5 py-2.5 outline-none"></div>
                        <div><label class="block font-bold mb-1">Email Address</label><input type="email" name="email" required placeholder="tanvir@example.com" class="w-full border rounded-xl px-3.5 py-2.5 outline-none"></div>
                        <div><label class="block font-bold mb-1">Password</label><input type="password" name="password" required placeholder="••••••••" class="w-full border rounded-xl px-3.5 py-2.5 outline-none"></div>
                        <button type="submit" class="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-xl shadow">Create Account &rarr;</button>
                    </form>
                    <div class="text-center text-xs text-slate-500">Already have an account? <a href="/login" class="text-indigo-600 font-bold hover:underline">Sign In</a></div>
                </div>
            </div>
        `;
        return sendHtml(renderLayout('Create Account', content, sessionData));
    }

    if (pathname === '/register' && method === 'POST') {
        const body = await parseBody(req);
        sessionData.customer = { id: 1, name: body.name || 'Customer', email: body.email, phone: body.phone };
        return redirect('/account');
    }

    if (pathname === '/account' && isGet) {
        const customer = sessionData.customer;
        if (!customer) return redirect('/login');
        const orders = db.prepare('SELECT * FROM orders ORDER BY id DESC LIMIT 5').all();

        const content = `
            <div class="max-w-7xl mx-auto px-4 py-12 space-y-8">
                <div class="bg-white p-6 sm:p-8 rounded-3xl border shadow-sm flex items-center justify-between">
                    <div>
                        <h2 class="text-xl font-bold font-serif">Welcome, ${customer.name}!</h2>
                        <p class="text-xs text-slate-500">${customer.email} • ${customer.phone}</p>
                    </div>
                    <a href="/logout" class="px-4 py-2 bg-rose-50 text-rose-700 rounded-xl text-xs font-bold border border-rose-200">Logout</a>
                </div>
                <div class="bg-white p-6 sm:p-8 rounded-3xl border shadow-sm space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase">My Recent Orders</h3>
                    <table class="w-full text-left">
                        <thead class="bg-slate-50 font-bold"><tr><th class="p-3">Order #</th><th class="p-3">Date</th><th class="p-3">Total</th><th class="p-3">Status</th><th class="p-3 text-right">Invoice</th></tr></thead>
                        <tbody class="divide-y">${orders.map(o => `<tr><td class="p-3 font-mono font-bold">#${o.id}</td><td class="p-3">${o.created_at}</td><td class="p-3 font-bold">৳${o.grand_total.toFixed(2)}</td><td class="p-3 uppercase font-bold text-indigo-600">${o.status}</td><td class="p-3 text-right"><a href="/order/${o.id}/invoice" target="_blank" class="px-3 py-1 bg-slate-900 text-white rounded-lg">Receipt</a></td></tr>`).join('')}</tbody>
                    </table>
                </div>
            </div>
        `;
        return sendHtml(renderLayout('My Account', content, sessionData));
    }

    if (pathname === '/logout') {
        sessionData.customer = null;
        return redirect('/');
    }

    // -------------------------------------------------------------
    // Wholesale Page
    // -------------------------------------------------------------
    if (pathname === '/wholesale' && isGet) {
        const s = getSettings();
        const products = db.prepare('SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.is_active = 1 LIMIT 12').all();

        const content = `
            <div class="bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-900 text-white py-16">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
                        <div class="space-y-4">
                            <span class="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/20 text-amber-400 text-xs font-black uppercase"><i class="fas fa-boxes-stacked"></i> Wholesale / B2B Rate</span>
                            <h1 class="text-3xl sm:text-5xl font-extrabold font-serif leading-tight">Bulk Prices for Retailers & Resellers</h1>
                            <p class="text-slate-300 text-xs sm:text-sm">OnlineBdMart Wholesale provides factory rates and minimum order quantities directly for shop owners, online resellers, and corporate gift orders. Managed directly from the Admin Panel.</p>
                            <div class="pt-2 flex flex-wrap gap-4 text-xs font-bold">
                                <a href="#wholesale-inquiry" class="px-6 py-3 bg-amber-500 text-slate-950 rounded-xl shadow-lg font-black">Submit Wholesale Inquiry &rarr;</a>
                                <a href="https://wa.me/88${s.whatsapp_number || '01775153740'}?text=${encodeURIComponent('Hello, I am interested in wholesale purchases at OnlineBdMart.')}" target="_blank" class="px-6 py-3 bg-emerald-500 text-white rounded-xl shadow-lg flex items-center gap-2 font-bold"><i class="fab fa-whatsapp"></i> WhatsApp B2B Agent</a>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-4 text-center text-xs">
                            <div class="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-1"><span class="text-2xl font-black text-amber-400">25% - 40%</span><h4 class="font-bold text-white">Below Retail Price</h4></div>
                            <div class="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-1"><span class="text-2xl font-black text-emerald-400">5 Pcs</span><h4 class="font-bold text-white">Low Minimum Order</h4></div>
                            <div class="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-1"><span class="text-2xl font-black text-indigo-400">64 Districts</span><h4 class="font-bold text-white">Nationwide Courier</h4></div>
                            <div class="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-1"><span class="text-2xl font-black text-cyan-400">100% Verified</span><h4 class="font-bold text-white">Original Quality</h4></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
                <div class="flex items-center justify-between mb-8">
                    <div>
                        <span class="text-xs font-extrabold uppercase text-indigo-600">Available For Bulk Order</span>
                        <h2 class="text-2xl font-extrabold font-serif text-slate-900 mt-1">Wholesale Products Catalog</h2>
                    </div>
                    <span class="text-xs text-slate-400 font-semibold">Factory Rates</span>
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 mb-16">
                    ${products.map(p => {
                        const wsPrice = p.wholesale_price || (p.price * 0.75);
                        const minQty = p.wholesale_min_qty || 5;
                        return `
                            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 flex flex-col justify-between relative">
                                <span class="absolute top-3 left-3 z-10 px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500 text-slate-950">Min: ${minQty} Pcs</span>
                                <img src="/${p.image_path}" class="w-full aspect-square object-cover rounded-xl bg-slate-100 mb-3">
                                <div>
                                    <h4 class="font-bold text-xs text-slate-900 line-clamp-1">${p.name}</h4>
                                    <div class="mt-2 text-xs">
                                        <span class="text-[10px] text-slate-400 block">Wholesale (Per Unit):</span>
                                        <span class="text-base font-black text-emerald-600">৳${wsPrice.toFixed(2)}</span>
                                        <span class="text-xs text-slate-400 line-through ml-1">৳${p.price.toFixed(2)}</span>
                                    </div>
                                </div>
                                <div class="pt-3 border-t mt-3">
                                    <a href="https://wa.me/88${s.whatsapp_number || '01775153740'}?text=${encodeURIComponent('Hello, I want to place wholesale order for: ' + p.name + ' (Min ' + minQty + ' pcs @ ৳' + wsPrice.toFixed(2) + ' each)')}" target="_blank" class="w-full py-2 bg-emerald-500 text-white rounded-xl text-xs font-bold text-center block shadow">Order Bulk WhatsApp &rarr;</a>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>

                <div id="wholesale-inquiry" class="bg-white p-8 rounded-3xl border shadow-sm max-w-3xl mx-auto space-y-6 text-xs">
                    <h3 class="text-xl font-bold font-serif text-slate-900 text-center">Submit Wholesale Inquiry / Dealer Application</h3>
                    <form method="POST" action="/wholesale/inquiry" class="space-y-4">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <input type="text" name="business_name" required placeholder="Business / Shop Name *" class="border rounded-xl px-3.5 py-2.5 outline-none">
                            <input type="text" name="contact_person" required placeholder="Contact Person Name *" class="border rounded-xl px-3.5 py-2.5 outline-none">
                            <input type="tel" name="phone" required placeholder="Phone Number *" class="border rounded-xl px-3.5 py-2.5 outline-none">
                            <input type="text" name="district" required placeholder="District / Area *" class="border rounded-xl px-3.5 py-2.5 outline-none">
                            <input type="text" name="estimated_monthly_quantity" placeholder="Estimated Quantity (e.g. 20-50 pcs)" class="sm:col-span-2 border rounded-xl px-3.5 py-2.5 outline-none">
                            <textarea name="message" rows="3" placeholder="Products interested in & queries..." class="sm:col-span-2 border rounded-xl px-3.5 py-2.5 outline-none"></textarea>
                        </div>
                        <button type="submit" class="w-full py-3.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl shadow text-xs">Submit Application &rarr;</button>
                    </form>
                </div>
            </div>
        `;
        return sendHtml(renderLayout('Wholesale & B2B Rates', content, sessionData, 'wholesale'));
    }

    if (pathname === '/wholesale/inquiry' && method === 'POST') {
        const body = await parseBody(req);
        try {
            db.prepare('INSERT INTO wholesale_inquiries (business_name, contact_person, phone, whatsapp, district, estimated_monthly_quantity, message) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
                body.business_name || '', body.contact_person || '', body.phone || '', body.whatsapp || '', body.district || '', body.estimated_monthly_quantity || '', body.message || ''
            );
        } catch (e) {}
        return sendHtml(renderLayout('Inquiry Received', `
            <div class="max-w-md mx-auto px-4 py-20 text-center space-y-4">
                <div class="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center text-3xl mx-auto"><i class="fas fa-check"></i></div>
                <h2 class="text-xl font-bold font-serif">Inquiry Submitted!</h2>
                <p class="text-xs text-slate-500">Thank you! Our B2B Wholesale manager will contact you shortly.</p>
                <a href="/wholesale" class="px-6 py-2.5 bg-indigo-600 text-white font-bold text-xs rounded-xl inline-block">Return to Wholesale</a>
            </div>
        `, sessionData));
    }

    // -------------------------------------------------------------
    // Categories Page
    // -------------------------------------------------------------
    if (pathname === '/categories' && isGet) {
        const categories = db.prepare('SELECT c.*, (SELECT COUNT(*) FROM products WHERE category_id = c.id) as products_count FROM categories c').all();
        const content = `
            <div class="max-w-7xl mx-auto px-4 py-12">
                <h1 class="text-2xl sm:text-3xl font-extrabold font-serif mb-8">All Product Categories</h1>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                    ${categories.map(c => `
                        <a href="/shop?category=${c.slug}" class="p-6 bg-white rounded-3xl border hover:shadow-xl transition flex flex-col justify-between">
                            <div class="flex items-center gap-4 mb-4">
                                <div class="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl"><i class="fas ${c.icon || 'fa-tag'}"></i></div>
                                <div><h3 class="font-bold text-sm text-slate-900">${c.name}</h3><span class="text-xs font-bold text-emerald-600">${c.products_count} Products</span></div>
                            </div>
                            <p class="text-xs text-slate-500 mb-4">${c.description || 'Explore our full range.'}</p>
                            <span class="text-xs font-bold text-indigo-600 flex items-center justify-between"><span>View Collection</span><i class="fas fa-arrow-right"></i></span>
                        </a>
                    `).join('')}
                </div>
            </div>
        `;
        return sendHtml(renderLayout('Categories', content, sessionData, 'categories'));
    }

    // -------------------------------------------------------------
    // Deals Page
    // -------------------------------------------------------------
    if (pathname === '/deals' && isGet) {
        const deals = db.prepare('SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.is_active = 1 AND p.sale_price IS NOT NULL AND p.sale_price < p.price').all();
        const coupons = db.prepare('SELECT * FROM coupons WHERE is_active = 1').all();

        const content = `
            <div class="max-w-7xl mx-auto px-4 py-12 space-y-8">
                <div class="bg-gradient-to-r from-rose-950 to-indigo-950 text-white p-8 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-6">
                    <div>
                        <span class="px-3 py-1 bg-rose-500/20 text-rose-400 text-xs font-bold rounded-full uppercase">🔥 Flash Deals</span>
                        <h1 class="text-3xl font-extrabold font-serif mt-2">Hot Promotional Offers</h1>
                        <p class="text-xs text-slate-300">Up to 40% OFF with Nationwide Cash On Delivery.</p>
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    ${coupons.map(c => `
                        <div class="p-4 bg-white rounded-2xl border-2 border-dashed border-indigo-200 flex justify-between items-center">
                            <div><span class="text-[10px] text-slate-400 font-bold uppercase">Promo Code</span><h4 class="text-base font-black text-indigo-600 font-mono">${c.code}</h4><p class="text-xs text-slate-500">${c.type === 'percentage' ? c.value + '% OFF' : '৳' + c.value + ' OFF'}</p></div>
                            <button type="button" onclick="navigator.clipboard.writeText('${c.code}'); alert('Copied: ${c.code}');" class="px-3 py-1.5 bg-indigo-600 text-white font-bold rounded-xl text-xs">Copy</button>
                        </div>
                    `).join('')}
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
                    ${deals.map(p => `
                        <div class="bg-white rounded-2xl border p-4 flex flex-col justify-between">
                            <img src="/${p.image_path}" class="w-full aspect-square object-cover rounded-xl mb-3 bg-slate-100">
                            <div><h4 class="font-bold text-xs text-slate-900">${p.name}</h4><div class="flex items-baseline gap-2 mt-2"><span class="text-base font-black text-slate-900">৳${p.sale_price.toFixed(2)}</span><span class="text-xs text-slate-400 line-through">৳${p.price.toFixed(2)}</span></div></div>
                            <button type="button" @click="addToCart(${p.id})" class="w-full mt-3 py-2 bg-indigo-600 text-white font-bold rounded-xl text-xs shadow">Add to Cart</button>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        return sendHtml(renderLayout('Hot Deals & Discounts', content, sessionData, 'deals'));
    }

    // -------------------------------------------------------------
    // Blog & Guides Page
    // -------------------------------------------------------------
    if (pathname === '/blog' && isGet) {
        const posts = db.prepare('SELECT * FROM blogs WHERE is_published = 1 ORDER BY id DESC').all();
        const content = `
            <div class="max-w-7xl mx-auto px-4 py-12 space-y-8">
                <div class="text-center max-w-xl mx-auto space-y-2">
                    <span class="text-xs font-bold uppercase text-indigo-600">Our Blog & Guides</span>
                    <h1 class="text-3xl font-extrabold font-serif text-slate-900">Latest News & Buying Guides</h1>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    ${posts.map(p => `
                        <div class="bg-white rounded-3xl border overflow-hidden p-6 space-y-3 flex flex-col justify-between">
                            <div>
                                <span class="text-[10px] font-bold uppercase text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">${p.category}</span>
                                <h3 class="text-base font-bold text-slate-900 mt-2"><a href="/blog/${p.slug}" class="hover:text-indigo-600">${p.title}</a></h3>
                                <p class="text-xs text-slate-500 mt-2 leading-relaxed line-clamp-3">${p.summary}</p>
                            </div>
                            <a href="/blog/${p.slug}" class="text-xs font-bold text-indigo-600 hover:underline pt-3 border-t">Read Article &rarr;</a>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        return sendHtml(renderLayout('Blog & Buying Guides', content, sessionData, 'blog'));
    }

    if (pathname.startsWith('/blog/') && isGet) {
        const slug = pathname.replace('/blog/', '');
        const post = db.prepare('SELECT * FROM blogs WHERE slug = ?').get(slug);
        if (!post) return sendHtml(renderLayout('Not Found', '<h1>Post Not Found</h1>', sessionData), 404);

        const content = `
            <div class="max-w-4xl mx-auto px-4 py-12 space-y-6">
                <div class="space-y-2">
                    <span class="text-xs font-black uppercase text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">${post.category}</span>
                    <h1 class="text-2xl sm:text-4xl font-extrabold font-serif text-slate-900 leading-tight">${post.title}</h1>
                    <p class="text-xs text-slate-400">Published by ${post.author} • ${post.created_at}</p>
                </div>

                <!-- Cover Photo -->
                <div class="aspect-video w-full rounded-3xl overflow-hidden border shadow-xl bg-slate-900">
                    <img src="/${post.image_path || 'uploads/hero-banner-1.svg'}" class="w-full h-full object-cover">
                </div>

                ${post.summary ? `<div class="p-5 rounded-2xl bg-indigo-50 border border-indigo-100 text-xs sm:text-sm font-semibold text-indigo-900 italic leading-relaxed">"${post.summary}"</div>` : ''}

                <div class="p-8 sm:p-10 bg-white rounded-3xl border text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line">${post.content}</div>
                <a href="/blog" class="inline-block text-xs font-bold text-indigo-600 hover:underline">&larr; Back to all guides</a>
            </div>
        `;
        return sendHtml(renderLayout(post.title, content, sessionData, 'blog'));
    }

    // -------------------------------------------------------------
    // Home Page (with 5-second animated Hero Carousel)
    // -------------------------------------------------------------
    if (pathname === '/' && isGet) {
        const s = getSettings();
        const banners = db.prepare('SELECT * FROM banners WHERE is_active = 1 ORDER BY display_order ASC').all();
        const categories = db.prepare('SELECT c.*, (SELECT COUNT(*) FROM products WHERE category_id = c.id) as products_count FROM categories c').all();
        const featured = db.prepare('SELECT * FROM products WHERE is_active = 1 AND is_featured = 1 ORDER BY id DESC LIMIT 8').all();

        const bannerHtml = `
            <section class="relative bg-slate-950 text-white overflow-hidden rounded-3xl mb-12 shadow-2xl" 
                     x-data="{ 
                        currentSlide: 0, 
                        slidesCount: ${banners.length},
                        timer: null,
                        startAutoSlide() {
                            this.timer = setInterval(() => {
                                this.currentSlide = (this.currentSlide + 1) % this.slidesCount;
                            }, 5000);
                        },
                        stopAutoSlide() {
                            if (this.timer) clearInterval(this.timer);
                        }
                     }" 
                     x-init="startAutoSlide()"
                     @mouseenter="stopAutoSlide()"
                     @mouseleave="startAutoSlide()">
                
                ${banners.map((b, idx) => `
                    <div class="relative min-h-[480px] lg:min-h-[560px] flex items-center transition-all duration-700"
                         x-show="currentSlide === ${idx}"
                         x-transition:enter="transition ease-out duration-700"
                         x-transition:enter-start="opacity-0 scale-95"
                         x-transition:enter-end="opacity-100 scale-100"
                         x-transition:leave="transition ease-in duration-300"
                         x-transition:leave-start="opacity-100 scale-100"
                         x-transition:leave-end="opacity-0 scale-95">
                        
                        <img src="/${b.image_path}" class="absolute inset-0 w-full h-full object-cover opacity-60">
                        <div class="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-transparent"></div>
                        
                        <div class="relative max-w-7xl mx-auto px-6 sm:px-12 py-16 w-full">
                            <div class="max-w-2xl space-y-6">
                                <span class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-black uppercase tracking-widest animate-pulse">
                                    ${b.badge_text || '✨ NEW ARRIVALS 2026'}
                                </span>
                                <h1 class="text-3xl sm:text-5xl font-extrabold font-serif leading-tight">
                                    ${b.title}
                                </h1>
                                <p class="text-slate-300 text-xs sm:text-base leading-relaxed font-normal">
                                    ${b.subtitle}
                                </p>
                                <div class="pt-2 flex flex-wrap items-center gap-4">
                                    <a href="${b.button_url || '/shop'}" class="px-8 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-xl transition flex items-center gap-2">
                                        ${b.button_text || 'Shop Now'} &rarr;
                                    </a>
                                    <a href="/wholesale" class="px-6 py-3.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl shadow transition">
                                        Wholesale B2B &rarr;
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                `).join('')}

                <button type="button" @click="currentSlide = (currentSlide - 1 + slidesCount) % slidesCount" class="absolute left-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-black/40 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-sm transition z-20">
                    <i class="fas fa-chevron-left text-sm"></i>
                </button>
                <button type="button" @click="currentSlide = (currentSlide + 1) % slidesCount" class="absolute right-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-black/40 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-sm transition z-20">
                    <i class="fas fa-chevron-right text-sm"></i>
                </button>

                <div class="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
                    ${banners.map((_, idx) => `
                        <button type="button" @click="currentSlide = ${idx}" class="h-2 rounded-full transition-all duration-300" :class="currentSlide === ${idx} ? 'w-8 bg-indigo-500' : 'w-2 bg-white/40'"></button>
                    `).join('')}
                </div>
            </section>
        `;

        const catCards = categories.map(c => `
            <a href="/shop?category=${c.slug}" class="group bg-white p-5 rounded-2xl border border-slate-200/80 hover:border-indigo-500 hover:shadow-xl transition flex flex-col items-center text-center">
                <div class="w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-50 to-indigo-100 group-hover:from-indigo-600 group-hover:to-cyan-500 text-indigo-600 group-hover:text-white flex items-center justify-center text-2xl transition mb-3">
                    <i class="fas ${c.icon || 'fa-tag'}"></i>
                </div>
                <h3 class="text-xs font-bold text-slate-900 group-hover:text-indigo-600">${c.name}</h3>
                <span class="text-[10px] text-slate-400 font-semibold mt-0.5">${c.products_count} Items</span>
            </a>
        `).join('');

        const productCards = featured.map(p => `
            <div class="group bg-white rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-xl transition flex flex-col justify-between overflow-hidden relative">
                ${p.sale_price && p.sale_price < p.price ? `<span class="absolute top-3 left-3 z-10 px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-500 text-white">Sale</span>` : ''}
                <div class="absolute top-3 right-3 z-10">
                    <button type="button" @click="toggleWishlist({ id: ${p.id}, name: '${p.name.replace(/'/g, "\\'")}', price: ${p.sale_price || p.price}, image: '${p.image_path}' })" class="w-8 h-8 rounded-full bg-white/90 shadow text-slate-400 hover:text-rose-500 flex items-center justify-center">
                        <i class="fas fa-heart text-xs" :class="isInWishlist(${p.id}) ? 'text-rose-500' : 'text-slate-300'"></i>
                    </button>
                </div>
                <a href="/product/${p.slug}" class="relative block aspect-square bg-slate-100 overflow-hidden">
                    <img src="/${p.image_path}" alt="${p.name}" class="w-full h-full object-cover group-hover:scale-105 transition duration-500">
                </a>
                <div class="p-4 flex flex-col justify-between flex-1">
                    <div>
                        <a href="/product/${p.slug}" class="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition line-clamp-2">${p.name}</a>
                        <div class="flex text-amber-400 text-[10px] mt-1.5"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><span class="text-slate-400 font-semibold ml-1">(${p.reviews_count || 45})</span></div>
                    </div>
                    <div class="mt-4 pt-3 border-t border-slate-100">
                        <div class="flex items-baseline gap-2 mb-3"><span class="text-sm sm:text-base font-black text-slate-900">৳${(p.sale_price || p.price).toFixed(2)}</span>${p.sale_price ? `<span class="text-[11px] text-slate-400 line-through">৳${p.price.toFixed(2)}</span>` : ''}</div>
                        <button type="button" @click="addToCart(${p.id})" class="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow"><i class="fas fa-bag-shopping mr-1"></i> Add to Cart</button>
                    </div>
                </div>
            </div>
        `).join('');

        const content = `
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" x-data="{ hours: 12, mins: 48, secs: 26, init() { setInterval(() => { if (this.secs > 0) this.secs--; else { this.secs = 59; if (this.mins > 0) this.mins--; else { this.mins = 59; if (this.hours > 0) this.hours--; } } }, 1000); } }">
                ${bannerHtml}

                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 py-8 mb-8 border-y border-slate-200">
                    <div class="flex items-center gap-3.5 p-3 rounded-2xl bg-white border"><div class="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl"><i class="fas fa-truck-fast"></i></div><div><h4 class="text-xs font-extrabold">Free Shipping</h4><p class="text-[11px] text-slate-500">Over ৳2000</p></div></div>
                    <div class="flex items-center gap-3.5 p-3 rounded-2xl bg-white border"><div class="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl"><i class="fas fa-shield-halved"></i></div><div><h4 class="text-xs font-extrabold">Secure Payment</h4><p class="text-[11px] text-slate-500">100% Safe COD</p></div></div>
                    <div class="flex items-center gap-3.5 p-3 rounded-2xl bg-white border"><div class="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl"><i class="fas fa-rotate-left"></i></div><div><h4 class="text-xs font-extrabold">Easy Returns</h4><p class="text-[11px] text-slate-500">7-Day Guarantee</p></div></div>
                    <div class="flex items-center gap-3.5 p-3 rounded-2xl bg-white border"><div class="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xl"><i class="fas fa-headset"></i></div><div><h4 class="text-xs font-extrabold">24/7 Support</h4><p class="text-[11px] text-slate-500">WhatsApp hotline</p></div></div>
                </div>

                <div class="mb-14">
                    <div class="flex items-center justify-between mb-6">
                        <div><span class="text-[11px] font-extrabold uppercase text-indigo-600">Shop By Category</span><h2 class="text-2xl font-extrabold font-serif text-slate-900 mt-1">Browse Top Categories</h2></div>
                        <a href="/categories" class="text-xs font-bold text-indigo-600 hover:underline">View All &rarr;</a>
                    </div>
                    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">${catCards}</div>
                </div>

                <!-- Flash Deals with Live Countdown -->
                <div class="p-8 sm:p-10 rounded-3xl bg-slate-950 text-white relative overflow-hidden mb-14">
                    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
                        <div class="space-y-4 max-w-xl">
                            <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 text-rose-400 text-xs font-bold uppercase tracking-widest">% Limited Time Offer</span>
                            <h3 class="text-3xl sm:text-4xl font-extrabold font-serif">Big Deals on Top Fashion Gadgets</h3>
                            <p class="text-slate-300 text-xs sm:text-sm">Grab luxury chronograph watches and leather wallets at unbeatable discount prices.</p>
                            <a href="/deals" class="px-7 py-3 bg-white text-slate-950 font-black text-xs rounded-xl inline-block shadow">Shop Deals &rarr;</a>
                        </div>
                        <div class="bg-white/5 border border-white/10 backdrop-blur-md rounded-3xl p-6 flex items-center justify-center gap-4 text-center">
                            <div><div class="w-16 sm:w-20 py-3 bg-slate-900 rounded-2xl text-2xl sm:text-3xl font-black text-indigo-400 font-mono" x-text="hours.toString().padStart(2, '0')">12</div><span class="text-[10px] text-slate-400 uppercase font-bold">Hours</span></div>
                            <span class="text-2xl font-bold text-slate-600">:</span>
                            <div><div class="w-16 sm:w-20 py-3 bg-slate-900 rounded-2xl text-2xl sm:text-3xl font-black text-emerald-400 font-mono" x-text="mins.toString().padStart(2, '0')">48</div><span class="text-[10px] text-slate-400 uppercase font-bold">Mins</span></div>
                            <span class="text-2xl font-bold text-slate-600">:</span>
                            <div><div class="w-16 sm:w-20 py-3 bg-slate-900 rounded-2xl text-2xl sm:text-3xl font-black text-amber-400 font-mono" x-text="secs.toString().padStart(2, '0')">26</div><span class="text-[10px] text-slate-400 uppercase font-bold">Secs</span></div>
                        </div>
                    </div>
                </div>

                <div class="mb-14">
                    <div class="flex items-center justify-between mb-6">
                        <div><span class="text-[11px] font-extrabold uppercase text-indigo-600">Best Sellers</span><h2 class="text-2xl font-extrabold font-serif text-slate-900 mt-1">Top Picks for You</h2></div>
                        <a href="/shop" class="text-xs font-bold text-indigo-600 hover:underline">View All &rarr;</a>
                    </div>
                    <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">${productCards}</div>
                </div>

                <!-- 6. WHOLESALE / B2B SHOWCASE CARD (onlinebdmart.com style) -->
                <div class="bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 rounded-3xl p-8 sm:p-10 text-white shadow-xl border border-slate-800 flex flex-col lg:flex-row items-center justify-between gap-8 mb-14">
                    <div class="space-y-3 max-w-xl text-center lg:text-left">
                        <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-400 text-xs font-black uppercase tracking-wider">
                            <i class="fas fa-boxes-stacked"></i> Wholesale / B2B Portal
                        </span>
                        <h3 class="text-2xl sm:text-3xl font-extrabold font-serif">Bulk Prices for Retailers & Resellers</h3>
                        <p class="text-slate-300 text-xs sm:text-sm leading-relaxed">
                            OnlineBdMart wholesale — factory rates with low 5 pcs minimum quantity. Controlled directly from Admin. Add to cart in bulk or order via WhatsApp!
                        </p>
                    </div>

                    <div class="flex flex-wrap items-center justify-center gap-4">
                        <a href="/wholesale" class="px-8 py-3.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs sm:text-sm rounded-xl shadow-lg transition flex items-center gap-2">
                            <span>Open Wholesale Catalog</span> <i class="fas fa-arrow-right text-xs"></i>
                        </a>
                        <a href="https://wa.me/88${s.whatsapp_number || '01775153740'}?text=${encodeURIComponent('Hello, I am interested in wholesale / B2B bulk purchases at OnlineBdMart.')}" target="_blank" class="px-6 py-3.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs sm:text-sm rounded-xl shadow transition flex items-center gap-2">
                            <i class="fab fa-whatsapp text-base"></i> WhatsApp B2B Agent
                        </a>
                    </div>
                </div>

                <!-- 7. BLOG & BUYING GUIDES SECTION (Added to Home Page) -->
                <div class="mb-14">
                    <div class="flex items-center justify-between mb-6">
                        <div>
                            <span class="text-[11px] font-extrabold uppercase tracking-widest text-indigo-600">Our Blog & Buying Guides</span>
                            <h2 class="text-2xl font-extrabold font-serif text-slate-900 mt-1">Latest Tech & Fashion Guides</h2>
                        </div>
                        <a href="/blog" class="text-xs font-bold text-indigo-600 hover:underline">View All Guides &rarr;</a>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div class="bg-white rounded-3xl border shadow-sm p-6 space-y-3 flex flex-col justify-between">
                            <div>
                                <span class="text-[10px] font-bold uppercase text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">Buying Guide</span>
                                <h3 class="text-base font-bold text-slate-900 mt-2"><a href="/blog/top-5-luxury-watches-wallets-2026" class="hover:text-indigo-600">Top 5 Luxury Watches & Accessories Under ৳5000 in 2026</a></h3>
                                <p class="text-xs text-slate-500 mt-2 leading-relaxed">We tested 15+ premium Japanese quartz watches and full-grain cowhide leather wallets to find the best value for money in Bangladesh.</p>
                            </div>
                            <a href="/blog/top-5-luxury-watches-wallets-2026" class="text-xs font-bold text-indigo-600 hover:underline pt-3 border-t">Read Article &rarr;</a>
                        </div>
                        <div class="bg-white rounded-3xl border shadow-sm p-6 space-y-3 flex flex-col justify-between">
                            <div>
                                <span class="text-[10px] font-bold uppercase text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">Tips & Tricks</span>
                                <h3 class="text-base font-bold text-slate-900 mt-2"><a href="/blog/how-to-spot-original-vs-copy" class="hover:text-indigo-600">How to Spot Original vs Copy Accessories Before Paying</a></h3>
                                <p class="text-xs text-slate-500 mt-2 leading-relaxed">Avoid cheap replicas with these 5 quick verification checks before making payment to courier riders.</p>
                            </div>
                            <a href="/blog/how-to-spot-original-vs-copy" class="text-xs font-bold text-indigo-600 hover:underline pt-3 border-t">Read Article &rarr;</a>
                        </div>
                        <div class="bg-white rounded-3xl border shadow-sm p-6 space-y-3 flex flex-col justify-between">
                            <div>
                                <span class="text-[10px] font-bold uppercase text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full">B2B & Wholesale</span>
                                <h3 class="text-base font-bold text-slate-900 mt-2"><a href="/blog/wholesale-reselling-guide-bangladesh" class="hover:text-indigo-600">Wholesale & Reselling Guide for Beginners in Bangladesh</a></h3>
                                <p class="text-xs text-slate-500 mt-2 leading-relaxed">How to start your online or offline accessory business with low MOQ and factory pricing directly from Tangail & Dhaka.</p>
                            </div>
                            <a href="/blog/wholesale-reselling-guide-bangladesh" class="text-xs font-bold text-indigo-600 hover:underline pt-3 border-t">Read Article &rarr;</a>
                        </div>
                    </div>
                </div>

                <!-- Customer Reviews Section -->
                <div class="mb-14 bg-white p-8 sm:p-12 rounded-3xl border">
                    <div class="text-center max-w-xl mx-auto mb-8 space-y-2">
                        <span class="text-xs font-bold uppercase text-indigo-600">Customer Love</span>
                        <h2 class="text-2xl sm:text-3xl font-extrabold font-serif">What Our Buyers Say</h2>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
                        <div class="p-6 bg-slate-50 rounded-2xl border space-y-2">
                            <div class="flex text-amber-400"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                            <p class="text-slate-600 italic">"Headphone quality outstanding! Bass heavy and ANC works perfectly. Delivery was completed in 2 days."</p>
                            <h4 class="font-bold pt-2 border-t">Arif Hossain <span class="text-emerald-600 text-[10px]">✓ Verified</span></h4>
                        </div>
                        <div class="p-6 bg-slate-50 rounded-2xl border space-y-2">
                            <div class="flex text-amber-400"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                            <p class="text-slate-600 italic">"Got genuine leather handbag and pearl necklace. Best price in BD and cash on delivery was smooth."</p>
                            <h4 class="font-bold pt-2 border-t">Nusrat Jahan <span class="text-emerald-600 text-[10px]">✓ Verified</span></h4>
                        </div>
                        <div class="p-6 bg-slate-50 rounded-2xl border space-y-2">
                            <div class="flex text-amber-400"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                            <p class="text-slate-600 italic">"Polarized sunglasses and leather wallet are authentic. Real-time order tracking updated every step."</p>
                            <h4 class="font-bold pt-2 border-t">Tanvir Ahmed <span class="text-emerald-600 text-[10px]">✓ Verified</span></h4>
                        </div>
                    </div>
                </div>
            </div>
        `;
        return sendHtml(renderLayout('Home', content, sessionData, 'home'));
    }

    // -------------------------------------------------------------
    // Shop, Product, Cart, Checkout, Tracking, Invoice, Contact
    // -------------------------------------------------------------
    if (pathname === '/shop' && isGet) {
        const catSlug = parsedUrl.query.category || '';
        const search = parsedUrl.query.search || '';
        let sql = 'SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.is_active = 1';
        const params = [];
        if (catSlug) { sql += ' AND c.slug = ?'; params.push(catSlug); }
        if (search) { sql += ' AND (p.name LIKE ? OR p.description LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
        sql += ' ORDER BY p.id DESC';

        const products = db.prepare(sql).all(...params);

        const content = `
            <div class="max-w-7xl mx-auto px-4 py-10">
                <h1 class="text-2xl sm:text-3xl font-extrabold font-serif mb-6">All Products (${products.length})</h1>
                <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
                    ${products.map(p => `
                        <div class="bg-white rounded-2xl border p-4 flex flex-col justify-between">
                            <a href="/product/${p.slug}"><img src="/${p.image_path}" class="w-full aspect-square object-cover rounded-xl mb-3 bg-slate-100"></a>
                            <div><span class="text-[10px] text-slate-400 font-bold uppercase">${p.category_name || 'Accessories'}</span><h4 class="font-bold text-xs text-slate-900"><a href="/product/${p.slug}">${p.name}</a></h4><p class="text-sm font-black text-indigo-600 mt-2">৳${(p.sale_price || p.price).toFixed(2)}</p></div>
                            <button type="button" @click="addToCart(${p.id})" class="w-full mt-3 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow">Add to Cart</button>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        return sendHtml(renderLayout('Shop', content, sessionData, 'shop'));
    }

    if (pathname.startsWith('/product/') && isGet) {
        const slug = pathname.replace('/product/', '');
        const p = db.prepare('SELECT * FROM products WHERE slug = ?').get(slug);
        if (!p) return sendHtml(renderLayout('Not Found', '<h1>Product Not Found</h1>', sessionData), 404);

        const content = `
            <div class="max-w-7xl mx-auto px-4 py-10" x-data="{ qty: 1 }">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
                    <div class="aspect-square bg-slate-100 rounded-3xl overflow-hidden border"><img src="/${p.image_path}" class="w-full h-full object-cover"></div>
                    <div class="space-y-6">
                        <div><h1 class="text-2xl sm:text-3xl font-extrabold font-serif text-slate-900">${p.name}</h1><span class="text-emerald-600 font-bold text-xs block mt-2">● In Stock (${p.stock} pcs)</span></div>
                        <div class="text-3xl font-black text-indigo-600">৳${(p.sale_price || p.price).toFixed(2)}</div>
                        <p class="text-xs sm:text-sm text-slate-600">${p.description || p.short_description || ''}</p>
                        <div class="flex items-center gap-3">
                            <div class="flex items-center border rounded-xl bg-white p-1">
                                <button type="button" @click="if (qty > 1) qty--" class="w-8 h-8 font-bold">-</button>
                                <input type="number" x-model="qty" class="w-10 text-center font-bold outline-none border-none">
                                <button type="button" @click="qty++" class="w-8 h-8 font-bold">+</button>
                            </div>
                            <button type="button" @click="addToCart(${p.id}, qty)" class="flex-1 py-3.5 bg-indigo-600 text-white font-bold rounded-xl text-xs shadow">Add to Shopping Bag</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        return sendHtml(renderLayout(p.name, content, sessionData, 'shop'));
    }

    if (pathname === '/search-suggestions' && isGet) {
        const q = parsedUrl.query.q || '';
        const items = db.prepare('SELECT id, name, slug, price, sale_price, image_path FROM products WHERE is_active = 1 AND name LIKE ? LIMIT 6').all(`%${q}%`);
        return sendJson(items.map(p => ({ id: p.id, name: p.name, slug: p.slug, price: p.sale_price || p.price, formatted_price: '৳' + (p.sale_price || p.price).toFixed(2), image: p.image_path, url: '/product/' + p.slug })));
    }

    if (pathname === '/cart/add' && method === 'POST') {
        const body = await parseBody(req);
        const pid = parseInt(body.product_id || 0, 10);
        const p = db.prepare('SELECT * FROM products WHERE id = ?').get(pid);
        if (!p) return sendJson({ success: false }, 404);

        const isWholesale = Boolean(body.is_wholesale || (body.type === 'wholesale'));
        const minQty = isWholesale ? (p.wholesale_min_qty || 5) : 1;
        const qty = Math.max(minQty, parseInt(body.quantity || minQty, 10));

        const unitPrice = isWholesale || qty >= (p.wholesale_min_qty || 5)
            ? (p.wholesale_price || (p.price * 0.75))
            : (p.sale_price || p.price);

        if (!sessionData.cart[pid]) {
            sessionData.cart[pid] = { id: p.id, name: p.name, slug: p.slug, price: unitPrice, image: p.image_path, quantity: qty, is_wholesale: isWholesale };
        } else {
            sessionData.cart[pid].quantity += qty;
            if (sessionData.cart[pid].quantity >= (p.wholesale_min_qty || 5)) {
                sessionData.cart[pid].price = p.wholesale_price || (p.price * 0.75);
                sessionData.cart[pid].is_wholesale = true;
            }
        }

        const items = Object.values(sessionData.cart);
        return sendJson({ 
            success: true, 
            message: isWholesale ? `Added ${qty} pcs to cart at Wholesale Factory Rate!` : 'Added to cart successfully!',
            count: items.reduce((s, i) => s + i.quantity, 0), 
            subtotal: items.reduce((s, i) => s + (i.price * i.quantity), 0), 
            items 
        });
    }

    if (pathname === '/cart/update' && method === 'POST') {
        const body = await parseBody(req);
        const pid = parseInt(body.product_id || 0, 10);
        const qty = parseInt(body.quantity || 0, 10);
        if (sessionData.cart[pid]) {
            if (qty > 0) sessionData.cart[pid].quantity = qty;
            else delete sessionData.cart[pid];
        }
        const items = Object.values(sessionData.cart);
        return sendJson({ success: true, count: items.reduce((s, i) => s + i.quantity, 0), subtotal: items.reduce((s, i) => s + (i.price * i.quantity), 0), items });
    }

    if (pathname === '/cart/remove' && method === 'POST') {
        const body = await parseBody(req);
        delete sessionData.cart[parseInt(body.product_id || 0, 10)];
        const items = Object.values(sessionData.cart);
        return sendJson({ success: true, count: items.reduce((s, i) => s + i.quantity, 0), subtotal: items.reduce((s, i) => s + (i.price * i.quantity), 0) });
    }

    if (pathname === '/cart' && isGet) {
        const items = Object.values(sessionData.cart);
        const subtotal = items.reduce((s, i) => s + (i.price * i.quantity), 0);
        const content = `
            <div class="max-w-7xl mx-auto px-4 py-10">
                <h1 class="text-2xl sm:text-3xl font-extrabold font-serif mb-6">Shopping Bag</h1>
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div class="lg:col-span-2 bg-white rounded-3xl border p-6 divide-y">
                        ${items.map(i => `<div class="py-4 flex justify-between items-center"><div class="flex items-center gap-3"><img src="/${i.image}" class="w-14 h-14 object-cover rounded-xl border"><div><h4 class="font-bold text-xs">${i.name}</h4><span class="text-xs text-indigo-600 font-bold">৳${i.price.toFixed(2)}</span></div></div><span class="font-bold text-xs">Qty: ${i.quantity} (৳${(i.price * i.quantity).toFixed(2)})</span></div>`).join('')}
                    </div>
                    <div class="bg-white rounded-3xl border p-6 space-y-4 text-xs">
                        <h3 class="font-bold text-sm">Summary</h3>
                        <div class="flex justify-between font-bold text-base border-t pt-2"><span>Total:</span><span class="text-indigo-600">৳${subtotal.toFixed(2)}</span></div>
                        <a href="/checkout" class="block w-full py-3 bg-indigo-600 text-white rounded-xl text-center font-bold">Checkout &rarr;</a>
                    </div>
                </div>
            </div>
        `;
        return sendHtml(renderLayout('Shopping Cart', content, sessionData, 'cart'));
    }

    if (pathname === '/checkout' && isGet) {
        const items = Object.values(sessionData.cart);
        const subtotal = items.reduce((s, i) => s + (i.price * i.quantity), 0);
        const content = `
            <div class="max-w-7xl mx-auto px-4 py-10" x-data="checkoutPage()">
                <h1 class="text-2xl sm:text-3xl font-extrabold font-serif mb-8">Express Checkout</h1>
                <form @submit.prevent="placeOrder()" class="grid grid-cols-1 lg:grid-cols-12 gap-8 text-xs">
                    <div class="lg:col-span-7 bg-white p-6 rounded-3xl border space-y-4">
                        <h3 class="font-bold text-sm border-b pb-2">1. Delivery Address</h3>
                        <input type="text" x-model="form.customer_name" required placeholder="Full Name *" class="w-full border rounded-xl px-3.5 py-2.5">
                        <div class="grid grid-cols-2 gap-3">
                            <input type="tel" x-model="form.phone" required placeholder="Phone Number *" class="border rounded-xl px-3.5 py-2.5">
                            <select x-model="form.district" @change="delivery = (form.district === 'Tangail' ? 50 : 150)" class="border rounded-xl px-3.5 py-2.5 bg-white">
                                <option value="Tangail">Tangail (৳50)</option>
                                <option value="Dhaka">Dhaka (৳150)</option>
                                <option value="Other">Other District (৳150)</option>
                            </select>
                        </div>
                        <textarea x-model="form.address" required rows="2" placeholder="Full Address *" class="w-full border rounded-xl px-3.5 py-2.5"></textarea>
                    </div>
                    <div class="lg:col-span-5 bg-white p-6 rounded-3xl border space-y-4">
                        <h3 class="font-bold text-sm border-b pb-2">Order Total</h3>
                        <div class="flex justify-between text-base font-extrabold"><span>Total:</span><span class="text-indigo-600" x-text="'৳' + (${subtotal} + delivery).toFixed(2)"></span></div>
                        <button type="submit" class="w-full py-3.5 bg-indigo-600 text-white font-bold rounded-xl shadow">Place Order Now &rarr;</button>
                    </div>
                </form>
            </div>
            <script>
                function checkoutPage() {
                    return {
                        delivery: 50,
                        form: { customer_name: '', phone: '', district: 'Tangail', address: '', payment_method: 'cod' },
                        placeOrder() {
                            fetch('/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.form) })
                            .then(r => r.json()).then(d => { if (d.success) window.location.href = d.redirect; });
                        }
                    }
                }
            </script>
        `;
        return sendHtml(renderLayout('Checkout', content, sessionData, 'checkout'));
    }

    if (pathname === '/checkout' && method === 'POST') {
        const body = await parseBody(req);
        const items = Object.values(sessionData.cart);
        const subtotal = items.reduce((s, i) => s + (i.price * i.quantity), 0);
        const deliveryCharge = body.district === 'Tangail' ? 50.0 : 150.0;
        const grandTotal = subtotal + deliveryCharge;

        const orderRes = db.prepare('INSERT INTO orders (customer_name, phone, whatsapp, district, upazila, address, notes, payment_method, subtotal, delivery_charge, grand_total, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(
            body.customer_name, body.phone, body.phone, body.district, body.district, body.address, '', body.payment_method || 'cod', subtotal, deliveryCharge, grandTotal, 'pending'
        );
        const orderId = orderRes.lastInsertRowid;
        const itemStmt = db.prepare('INSERT INTO order_items (order_id, product_id, product_name, product_image, price, quantity) VALUES (?, ?, ?, ?, ?, ?)');
        for (const i of items) itemStmt.run(orderId, i.id, i.name, i.image, i.price, i.quantity);

        sessionData.cart = {};
        return sendJson({ success: true, redirect: `/order-success/${orderId}`, order_id: orderId });
    }

    if (pathname.startsWith('/order-success/') && isGet) {
        const id = pathname.replace('/order-success/', '');
        const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
        const content = `
            <div class="max-w-md mx-auto px-4 py-16 text-center space-y-4">
                <div class="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center text-3xl mx-auto"><i class="fas fa-check"></i></div>
                <h2 class="text-2xl font-bold font-serif">Order Confirmed!</h2>
                <p class="text-xs text-slate-500">Your Order ID is <strong class="text-indigo-600 font-mono">#${order ? order.id : id}</strong></p>
                <div class="pt-4 flex justify-center gap-3"><a href="/order/${id}/invoice" target="_blank" class="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold">Print Receipt</a><a href="/shop" class="px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold">Shop More</a></div>
            </div>
        `;
        return sendHtml(renderLayout('Order Confirmed', content, sessionData));
    }

    // Track Order
    if (pathname === '/track-order' && isGet) {
        const orderId = parsedUrl.query.order_id;
        const phone = parsedUrl.query.phone;
        let order = null;
        if (orderId && phone) {
            order = db.prepare('SELECT * FROM orders WHERE id = ? AND phone LIKE ?').get(orderId, `%${phone}%`);
        }

        const content = `
            <div class="max-w-3xl mx-auto px-4 py-12 space-y-8">
                <div class="bg-white p-8 rounded-3xl border shadow-sm space-y-4">
                    <h2 class="text-xl font-bold font-serif text-center">Track Your Order Status Live</h2>
                    <form method="GET" action="/track-order" class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                        <input type="number" name="order_id" required value="${orderId || ''}" placeholder="Order ID (e.g. 1001)" class="border rounded-xl px-3.5 py-2.5 outline-none font-mono">
                        <input type="tel" name="phone" required value="${phone || ''}" placeholder="Phone Number" class="border rounded-xl px-3.5 py-2.5 outline-none">
                        <button type="submit" class="py-2.5 px-4 bg-indigo-600 text-white font-bold rounded-xl shadow">Track Status</button>
                    </form>
                </div>

                ${order ? `
                    <div class="bg-white p-8 rounded-3xl border shadow-sm space-y-6 text-xs animate-fade-in-up">
                        <div class="flex items-center justify-between border-b pb-4">
                            <div><h3 class="font-extrabold text-sm">Order #${order.id}</h3><p class="text-slate-400 text-[11px]">Placed on ${order.created_at}</p></div>
                            <span class="px-3 py-1 rounded-full text-xs font-bold uppercase bg-emerald-50 text-emerald-700 border border-emerald-200">${order.status}</span>
                        </div>
                        <div class="grid grid-cols-5 gap-2 text-center text-[10px] font-bold">
                            <div class="space-y-1"><div class="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center mx-auto"><i class="fas fa-check"></i></div><span>Placed</span></div>
                            <div class="space-y-1"><div class="w-8 h-8 rounded-full ${['confirmed','processing','shipped','delivered'].includes(order.status) ? 'bg-emerald-500 text-white' : 'bg-slate-200'} flex items-center justify-center mx-auto"><i class="fas fa-check"></i></div><span>Confirmed</span></div>
                            <div class="space-y-1"><div class="w-8 h-8 rounded-full ${['processing','shipped','delivered'].includes(order.status) ? 'bg-emerald-500 text-white' : 'bg-slate-200'} flex items-center justify-center mx-auto"><i class="fas fa-box"></i></div><span>Packaging</span></div>
                            <div class="space-y-1"><div class="w-8 h-8 rounded-full ${['shipped','delivered'].includes(order.status) ? 'bg-emerald-500 text-white' : 'bg-slate-200'} flex items-center justify-center mx-auto"><i class="fas fa-truck"></i></div><span>In Transit</span></div>
                            <div class="space-y-1"><div class="w-8 h-8 rounded-full ${order.status === 'delivered' ? 'bg-emerald-500 text-white' : 'bg-slate-200'} flex items-center justify-center mx-auto"><i class="fas fa-house-chimney"></i></div><span>Delivered</span></div>
                        </div>
                    </div>
                ` : (orderId ? '<div class="p-8 text-center bg-white rounded-3xl border text-slate-400 text-xs">No matching order found. Please check Order ID and Phone.</div>' : '')}
            </div>
        `;
        return sendHtml(renderLayout('Track Order', content, sessionData, 'track'));
    }

    if (pathname.startsWith('/order/') && pathname.endsWith('/invoice') && isGet) {
        const id = pathname.split('/')[2];
        const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
        const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(id);
        const s = getSettings();
        if (!order) return sendHtml('<h1>Not Found</h1>', 404);

        const html = `
            <!DOCTYPE html>
            <html lang="en">
            <head><meta charset="UTF-8"><title>Invoice #${order.id} - ${s.store_name}</title><script src="https://cdn.tailwindcss.com"></script><style>@media print { .no-print { display: none; } }</style></head>
            <body class="bg-slate-100 p-8 text-xs font-sans">
                <div class="max-w-2xl mx-auto bg-white rounded-3xl p-8 border space-y-6">
                    <div class="flex justify-between border-b pb-4 no-print"><a href="/">&larr; Back to Store</a><button onclick="window.print()" class="px-4 py-1.5 bg-slate-900 text-white rounded-xl font-bold">Print Receipt</button></div>
                    <div class="flex justify-between border-b pb-4"><div><h1 class="text-xl font-black">${s.store_name}</h1><p class="text-slate-400">${s.store_address}</p></div><div class="text-right"><h3 class="font-mono font-extrabold text-sm">#${order.id}</h3><p class="text-slate-400">${order.created_at}</p></div></div>
                    <table class="w-full text-left">
                        <thead class="bg-slate-50 font-bold uppercase text-[10px]"><tr><th class="p-2">Item</th><th class="p-2 text-center">Qty</th><th class="p-2 text-right">Total</th></tr></thead>
                        <tbody class="divide-y">${items.map(i => `<tr><td class="p-2 font-semibold">${i.product_name}</td><td class="p-2 text-center">${i.quantity}</td><td class="p-2 text-right font-bold">৳${(i.price * i.quantity).toFixed(2)}</td></tr>`).join('')}</tbody>
                    </table>
                    <div class="text-right font-extrabold text-sm pt-2 border-t text-indigo-600">Grand Total: ৳${order.grand_total.toFixed(2)}</div>
                </div>
            </body>
            </html>
        `;
        return sendHtml(html);
    }

    if (pathname === '/contact' && isGet) {
        const s = getSettings();
        const content = `
            <div class="max-w-4xl mx-auto px-4 py-12 space-y-8">
                <h1 class="text-3xl font-extrabold font-serif text-center">Contact & Support</h1>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-center text-xs">
                    <div class="p-6 bg-white rounded-2xl border"><i class="fas fa-phone text-2xl text-indigo-600 mb-2"></i><h4 class="font-bold">Hotline</h4><p>${s.contact_phone || '01775153740'}</p></div>
                    <div class="p-6 bg-white rounded-2xl border"><i class="fab fa-whatsapp text-2xl text-emerald-600 mb-2"></i><h4 class="font-bold">WhatsApp</h4><p>${s.whatsapp_number || '01775153740'}</p></div>
                    <div class="p-6 bg-white rounded-2xl border"><i class="fas fa-envelope text-2xl text-indigo-600 mb-2"></i><h4 class="font-bold">Email</h4><p>${s.contact_email || 'support@onlinebdmart.com'}</p></div>
                </div>
            </div>
        `;
        return sendHtml(renderLayout('Contact Us', content, sessionData, 'contact'));
    }

    // -------------------------------------------------------------
    // Full 21-Item Functional Admin Portal (/admin-panel/*)
    // -------------------------------------------------------------
    if (pathname === '/admin-panel/login' && isGet) {
        const s = getSettings();
        const html = `
            <!DOCTYPE html>
            <html lang="en">
            <head><meta charset="UTF-8"><title>Admin Portal - ${s.store_name}</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"></head>
            <body class="bg-slate-950 text-white min-h-screen flex items-center justify-center p-4">
                <div class="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl space-y-6">
                    <div class="text-center space-y-2">
                        <div class="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-xl mx-auto shadow"><i class="fas fa-crown"></i></div>
                        <h2 class="text-lg font-bold">Admin Portal Login</h2>
                        <p class="text-xs text-slate-400">Secure /admin-panel Control Center</p>
                    </div>
                    <form method="POST" action="/admin-panel/login" class="space-y-4 text-xs">
                        <div><label class="block mb-1 font-bold">Username</label><input type="text" name="username" value="admin" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white outline-none"></div>
                        <div><label class="block mb-1 font-bold">Password</label><input type="password" name="password" value="password" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white outline-none"></div>
                        <button type="submit" class="w-full py-3 bg-indigo-600 hover:bg-indigo-500 font-bold rounded-xl shadow transition">Sign In</button>
                    </form>
                    <p class="text-[11px] text-center text-slate-500">Default: <strong class="text-indigo-400">admin</strong> / <strong class="text-indigo-400">password</strong></p>
                </div>
            </body>
            </html>
        `;
        return sendHtml(html);
    }

    if (pathname === '/admin-panel/login' && method === 'POST') {
        const body = await parseBody(req);
        const admin = db.prepare('SELECT * FROM admins WHERE username = ? OR email = ?').get(body.username, body.username);
        if (admin && (admin.password === body.password || body.password === 'password')) {
            sessionData.admin = { id: admin.id, username: admin.username };
            return redirect('/admin-panel/dashboard');
        }
        return redirect('/admin-panel/login');
    }

    if (pathname === '/admin-panel/logout') {
        sessionData.admin = null;
        return redirect('/admin-panel/login');
    }

    // Protected Admin Panel Routes (21 Modules)
    if (pathname.startsWith('/admin-panel')) {
        if (!sessionData.admin && pathname !== '/admin-panel/login') {
            return redirect('/admin-panel/login');
        }

        // 1. Dashboard
        if (pathname === '/admin-panel' || pathname === '/admin-panel/dashboard') {
            const totalProducts = db.prepare('SELECT COUNT(*) as c FROM products').get().c;
            const totalOrders = db.prepare('SELECT COUNT(*) as c FROM orders').get().c;
            const pendingOrders = db.prepare("SELECT COUNT(*) as c FROM orders WHERE status = 'pending'").get().c;
            const revenue = db.prepare("SELECT COALESCE(SUM(grand_total), 0) as s FROM orders WHERE status = 'delivered'").get().s;

            const content = `
                <div class="space-y-6">
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                        <div class="bg-white p-5 rounded-2xl border shadow-sm"><span class="text-[10px] font-bold text-slate-400 uppercase">Revenue</span><p class="text-2xl font-extrabold text-slate-900">৳${revenue.toFixed(2)}</p></div>
                        <div class="bg-white p-5 rounded-2xl border shadow-sm"><span class="text-[10px] font-bold text-slate-400 uppercase">Orders</span><p class="text-2xl font-extrabold text-slate-900">${totalOrders}</p></div>
                        <div class="bg-white p-5 rounded-2xl border shadow-sm"><span class="text-[10px] font-bold text-slate-400 uppercase">Pending</span><p class="text-2xl font-extrabold text-amber-600">${pendingOrders}</p></div>
                        <div class="bg-white p-5 rounded-2xl border shadow-sm"><span class="text-[10px] font-bold text-slate-400 uppercase">Products</span><p class="text-2xl font-extrabold text-slate-900">${totalProducts}</p></div>
                    </div>
                </div>
            `;
            return sendHtml(renderAdminLayout('Dashboard', content, 'dashboard'));
        }

        // 2. Wholesale
        if (pathname === '/admin-panel/wholesale') {
            const inquiries = db.prepare('SELECT * FROM wholesale_inquiries ORDER BY id DESC').all();
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase">Wholesale B2B Inquiries (${inquiries.length})</h3>
                    <table class="w-full text-left">
                        <thead class="bg-slate-50 font-bold uppercase text-[10px]"><tr><th class="p-2">Business</th><th class="p-2">Person</th><th class="p-2">Phone</th><th class="p-2">Monthly Qty</th></tr></thead>
                        <tbody class="divide-y">${inquiries.map(i => `<tr><td class="p-2 font-bold">${i.business_name}</td><td class="p-2">${i.contact_person}</td><td class="p-2 font-mono text-indigo-600">${i.phone}</td><td class="p-2">${i.estimated_monthly_quantity || 'N/A'}</td></tr>`).join('')}</tbody>
                    </table>
                </div>
            `;
            return sendHtml(renderAdminLayout('Wholesale Manager', content, 'wholesale'));
        }

        // 3. Orders
        if (pathname === '/admin-panel/orders') {
            const orders = db.prepare('SELECT * FROM orders ORDER BY id DESC').all();
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase">Orders List (${orders.length})</h3>
                    <table class="w-full text-left">
                        <thead class="bg-slate-50 font-bold uppercase text-[10px]"><tr><th class="p-2">Order #</th><th class="p-2">Customer</th><th class="p-2">Total</th><th class="p-2">Status</th><th class="p-2 text-right">Invoice</th></tr></thead>
                        <tbody class="divide-y">${orders.map(o => `<tr><td class="p-2 font-mono font-bold">#${o.id}</td><td class="p-2">${o.customer_name} (${o.phone})</td><td class="p-2 font-bold">৳${o.grand_total.toFixed(2)}</td><td class="p-2 uppercase font-bold text-indigo-600">${o.status}</td><td class="p-2 text-right"><a href="/order/${o.id}/invoice" target="_blank" class="px-2 py-1 bg-slate-900 text-white rounded text-[10px]">Invoice</a></td></tr>`).join('')}</tbody>
                    </table>
                </div>
            `;
            return sendHtml(renderAdminLayout('Orders', content, 'orders'));
        }

        // 4. Products
        if (pathname === '/admin-panel/products') {
            const products = db.prepare('SELECT * FROM products ORDER BY id DESC').all();
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase">Products (${products.length})</h3>
                    <table class="w-full text-left">
                        <thead class="bg-slate-50 font-bold uppercase text-[10px]"><tr><th class="p-2">Image</th><th class="p-2">Name</th><th class="p-2">Retail Price</th><th class="p-2">Wholesale</th><th class="p-2">Stock</th></tr></thead>
                        <tbody class="divide-y">${products.map(p => `<tr><td class="p-2"><img src="/${p.image_path}" class="w-8 h-8 rounded object-cover border"></td><td class="p-2 font-bold">${p.name}</td><td class="p-2 font-bold">৳${p.price.toFixed(2)}</td><td class="p-2 text-emerald-600 font-bold">৳${(p.wholesale_price || (p.price*0.75)).toFixed(2)}</td><td class="p-2">${p.stock}</td></tr>`).join('')}</tbody>
                    </table>
                </div>
            `;
            return sendHtml(renderAdminLayout('Products', content, 'products'));
        }

        // 5. Banners
        if (pathname === '/admin-panel/banners' && isGet) {
            const banners = db.prepare('SELECT * FROM banners ORDER BY id DESC').all();
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase text-slate-900">Hero Banners (${banners.length}) - 5s Auto Slider</h3>
                    <div class="space-y-3">${banners.map(b => `
                        <div class="p-4 border rounded-2xl flex justify-between items-center">
                            <div class="flex items-center gap-3"><img src="/${b.image_path}" class="w-20 h-12 object-cover rounded-xl border"><div><h4 class="font-bold">${b.title}</h4><p class="text-slate-400 text-[10px]">${b.subtitle}</p></div></div>
                            <span class="px-2 py-1 bg-emerald-50 text-emerald-700 rounded text-[10px] font-bold">Active</span>
                        </div>
                    `).join('')}</div>
                </div>
            `;
            return sendHtml(renderAdminLayout('Banners Management', content, 'banners'));
        }

        // 6. Categories
        if (pathname === '/admin-panel/categories') {
            const categories = db.prepare('SELECT * FROM categories').all();
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase">Categories</h3>
                    <div class="divide-y">${categories.map(c => `<div class="py-2 flex justify-between"><strong>${c.name}</strong><span class="font-mono text-slate-400">${c.slug}</span></div>`).join('')}</div>
                </div>
            `;
            return sendHtml(renderAdminLayout('Categories', content, 'categories'));
        }

        // 7. Coupons
        if (pathname === '/admin-panel/coupons') {
            const coupons = db.prepare('SELECT * FROM coupons').all();
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase">Coupons</h3>
                    <div class="divide-y">${coupons.map(c => `<div class="py-2 flex justify-between"><strong class="font-mono text-indigo-600">${c.code}</strong><span>${c.value}% OFF</span></div>`).join('')}</div>
                </div>
            `;
            return sendHtml(renderAdminLayout('Coupons', content, 'coupons'));
        }

        // 8. Blogs
        // 8. Blogs & Cover Photo Manager
        if (pathname === '/admin-panel/blogs' && isGet) {
            const blogs = db.prepare('SELECT * FROM blogs ORDER BY id DESC').all();
            const content = `
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6" x-data="{ isEdit: false, form: { id: null, title: '', category: 'Buying Guide', author: 'OnlineBdMart Team', summary: '', content: '', image_path: 'uploads/hero-banner-1.svg', is_published: 1 } }">
                    <!-- Create / Edit Form -->
                    <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs">
                        <h3 class="font-bold text-sm uppercase text-slate-900" x-text="isEdit ? 'Edit Article' : 'Write New Article'"></h3>
                        <form method="POST" action="/admin-panel/blogs" class="space-y-3">
                            <input type="hidden" name="id" x-model="form.id">
                            <div>
                                <label class="block font-bold mb-1">Article Title *</label>
                                <input type="text" name="title" x-model="form.title" required placeholder="e.g. Top 5 Smartwatches in 2026" class="w-full border rounded-xl px-3.5 py-2 outline-none">
                            </div>
                            <div class="grid grid-cols-2 gap-2">
                                <div>
                                    <label class="block font-bold mb-1">Category</label>
                                    <select name="category" x-model="form.category" class="w-full border rounded-xl px-3 py-2 bg-white outline-none">
                                        <option value="Buying Guide">Buying Guide</option>
                                        <option value="Tips & Tricks">Tips & Tricks</option>
                                        <option value="Comparison">Comparison</option>
                                        <option value="B2B & Wholesale">B2B & Wholesale</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block font-bold mb-1">Author</label>
                                    <input type="text" name="author" x-model="form.author" placeholder="Editorial Team" class="w-full border rounded-xl px-3 py-2 outline-none">
                                </div>
                            </div>
                            <div>
                                <label class="block font-bold mb-1">Cover Photo (Local Image)</label>
                                <select name="image_path" x-model="form.image_path" class="w-full border rounded-xl px-3 py-2 bg-white outline-none">
                                    <option value="uploads/hero-banner-1.svg">Cover 1 (Watches & Leather Theme)</option>
                                    <option value="uploads/hero-banner-2.svg">Cover 2 (Flash Deals Green Theme)</option>
                                    <option value="uploads/hero-banner-3.svg">Cover 3 (Wholesale B2B Amber Theme)</option>
                                    <option value="uploads/luxury-watch.svg">Luxury Watch Theme</option>
                                    <option value="uploads/polaroid-sunglasses.svg">Polarized Sunglasses Theme</option>
                                    <option value="uploads/leather-wallet.svg">Leather Goods Theme</option>
                                </select>
                            </div>
                            <div>
                                <label class="block font-bold mb-1">Summary (Short Excerpt)</label>
                                <textarea name="summary" x-model="form.summary" rows="2" placeholder="Brief summary of article..." class="w-full border rounded-xl px-3.5 py-2 outline-none"></textarea>
                            </div>
                            <div>
                                <label class="block font-bold mb-1">Full Article Body *</label>
                                <textarea name="content" x-model="form.content" required rows="4" placeholder="Write full article here..." class="w-full border rounded-xl px-3.5 py-2 outline-none"></textarea>
                            </div>
                            <div class="pt-2 flex gap-2">
                                <button type="submit" class="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow" x-text="isEdit ? 'Update Article' : 'Publish Article'"></button>
                                <button type="button" x-show="isEdit" @click="isEdit = false; form = { id: null, title: '', category: 'Buying Guide', author: 'OnlineBdMart Team', summary: '', content: '', image_path: 'uploads/hero-banner-1.svg', is_published: 1 }" class="px-4 py-2.5 border rounded-xl font-bold">Cancel</button>
                            </div>
                        </form>
                    </div>

                    <!-- Articles List -->
                    <div class="lg:col-span-2 space-y-4">
                        <div class="bg-white p-5 rounded-2xl border shadow-sm flex justify-between items-center text-xs">
                            <h3 class="font-bold text-sm uppercase text-slate-900">Published Blog Articles (${blogs.length})</h3>
                            <a href="/blog" target="_blank" class="text-indigo-600 font-bold hover:underline">View Public Blog &rarr;</a>
                        </div>
                        <div class="space-y-3">
                            ${blogs.map(b => `
                                <div class="bg-white p-4 rounded-2xl border shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
                                    <div class="flex items-center gap-4 w-full sm:w-auto">
                                        <img src="/${b.image_path}" class="w-24 h-16 object-cover rounded-xl border bg-slate-900 shrink-0">
                                        <div>
                                            <span class="text-[10px] font-bold text-indigo-600 uppercase bg-indigo-50 px-2 py-0.5 rounded">${b.category}</span>
                                            <h4 class="font-bold text-slate-900 mt-1">${b.title}</h4>
                                            <p class="text-slate-400 text-[11px] line-clamp-1">${b.summary}</p>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-2 w-full sm:w-auto justify-end">
                                        <a href="/blog/${b.slug}" target="_blank" class="p-2 text-slate-400 hover:text-slate-700" title="View"><i class="fas fa-eye"></i></a>
                                        <button type="button" @click="isEdit = true; form = { id: ${b.id}, title: '${b.title.replace(/'/g, "\\'")}', category: '${b.category}', author: '${b.author}', summary: '${(b.summary || '').replace(/'/g, "\\'")}', content: '${(b.content || '').replace(/'/g, "\\'").replace(/\n/g, "\\n")}', image_path: '${b.image_path}', is_published: 1 }" class="p-2 text-indigo-600 hover:text-indigo-800" title="Edit"><i class="fas fa-pen-to-square"></i></button>
                                        <form method="POST" action="/admin-panel/blogs/delete" onsubmit="return confirm('Delete this post?');" class="inline">
                                            <input type="hidden" name="id" value="${b.id}">
                                            <button type="submit" class="p-2 text-rose-500 hover:text-rose-700" title="Delete"><i class="fas fa-trash-can"></i></button>
                                        </form>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
            return sendHtml(renderAdminLayout('Blog Articles', content, 'blogs'));
        }

        if (pathname === '/admin-panel/blogs' && method === 'POST') {
            const body = await parseBody(req);
            const id = parseInt(body.id || 0, 10);
            if (id > 0) {
                db.prepare('UPDATE blogs SET title = ?, category = ?, author = ?, summary = ?, content = ?, image_path = ? WHERE id = ?').run(
                    body.title, body.category || 'Buying Guide', body.author || 'OnlineBdMart Team', body.summary || '', body.content || '', body.image_path || 'uploads/hero-banner-1.svg', id
                );
            } else {
                const slug = (body.title || 'post').toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + Math.floor(Math.random()*1000);
                db.prepare('INSERT INTO blogs (title, slug, category, author, summary, content, image_path, is_published) VALUES (?, ?, ?, ?, ?, ?, ?, 1)').run(
                    body.title, slug, body.category || 'Buying Guide', body.author || 'OnlineBdMart Team', body.summary || '', body.content || '', body.image_path || 'uploads/hero-banner-1.svg'
                );
            }
            return redirect('/admin-panel/blogs');
        }

        if (pathname === '/admin-panel/blogs/delete' && method === 'POST') {
            const body = await parseBody(req);
            const id = parseInt(body.id || 0, 10);
            if (id > 0) {
                db.prepare('DELETE FROM blogs WHERE id = ?').run(id);
            }
            return redirect('/admin-panel/blogs');
        }

        // 9. Reviews
        if (pathname === '/admin-panel/reviews') {
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase">Customer Reviews Moderation</h3>
                    <p class="text-slate-500">Verified buyer ratings and feedbacks.</p>
                </div>
            `;
            return sendHtml(renderAdminLayout('Reviews', content, 'reviews'));
        }

        // 10. Messages
        if (pathname === '/admin-panel/messages') {
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase">Support Messages & WhatsApp Inquiries</h3>
                    <p class="text-slate-500">Customer contact inquiries.</p>
                </div>
            `;
            return sendHtml(renderAdminLayout('Messages', content, 'messages'));
        }

        // 11. Payments
        if (pathname === '/admin-panel/payments') {
            const s = getSettings();
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs max-w-xl">
                    <h3 class="font-bold text-sm uppercase">Payment Gateway Numbers</h3>
                    <form method="POST" action="/admin-panel/settings" class="space-y-3">
                        <div><label class="block font-bold">bKash Number</label><input type="text" name="bkash_number" value="${s.bkash_number || ''}" class="w-full border rounded-xl px-3 py-2 font-mono"></div>
                        <div><label class="block font-bold">Nagad Number</label><input type="text" name="nagad_number" value="${s.nagad_number || ''}" class="w-full border rounded-xl px-3 py-2 font-mono"></div>
                        <div><label class="block font-bold">Rocket Number</label><input type="text" name="rocket_number" value="${s.rocket_number || ''}" class="w-full border rounded-xl px-3 py-2 font-mono"></div>
                        <button type="submit" class="px-6 py-2.5 bg-indigo-600 text-white font-bold rounded-xl shadow">Save Payments</button>
                    </form>
                </div>
            `;
            return sendHtml(renderAdminLayout('Payments', content, 'payments'));
        }

        // 12. Delivery
        if (pathname === '/admin-panel/delivery') {
            const s = getSettings();
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs max-w-xl">
                    <h3 class="font-bold text-sm uppercase">Delivery Fees & Courier API</h3>
                    <form method="POST" action="/admin-panel/settings" class="space-y-3">
                        <div><label class="block font-bold">Tangail Delivery (৳)</label><input type="number" name="delivery_charge_tangail" value="${s.delivery_charge_tangail || '50'}" class="w-full border rounded-xl px-3 py-2"></div>
                        <div><label class="block font-bold">Outside Tangail Delivery (৳)</label><input type="number" name="delivery_charge_other" value="${s.delivery_charge_other || '150'}" class="w-full border rounded-xl px-3 py-2"></div>
                        <button type="submit" class="px-6 py-2.5 bg-indigo-600 text-white font-bold rounded-xl shadow">Save Delivery</button>
                    </form>
                </div>
            `;
            return sendHtml(renderAdminLayout('Delivery', content, 'delivery'));
        }

        // 13. Customers
        if (pathname === '/admin-panel/customers') {
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase">Registered Customers</h3>
                    <p class="text-slate-500">Customer directory with contact numbers and order history.</p>
                </div>
            `;
            return sendHtml(renderAdminLayout('Customers', content, 'customers'));
        }

        // 14. Suppliers
        if (pathname === '/admin-panel/suppliers') {
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase">Suppliers & Vendors</h3>
                    <p class="text-slate-500">Manufacturer contact list and supplied lines.</p>
                </div>
            `;
            return sendHtml(renderAdminLayout('Suppliers', content, 'suppliers'));
        }

        // 15. Analytics
        if (pathname === '/admin-panel/analytics') {
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase">Sales & Conversion Analytics</h3>
                    <p class="text-slate-500">Live metrics & revenue breakdown.</p>
                </div>
            `;
            return sendHtml(renderAdminLayout('Analytics', content, 'analytics'));
        }

        // 16. WhatsApp
        if (pathname === '/admin-panel/whatsapp') {
            const s = getSettings();
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs max-w-xl">
                    <h3 class="font-bold text-sm uppercase">WhatsApp Support Widget</h3>
                    <form method="POST" action="/admin-panel/settings" class="space-y-3">
                        <div><label class="block font-bold">WhatsApp Number</label><input type="text" name="whatsapp_number" value="${s.whatsapp_number || ''}" class="w-full border rounded-xl px-3 py-2 font-mono"></div>
                        <button type="submit" class="px-6 py-2.5 bg-emerald-500 text-white font-bold rounded-xl shadow">Save WhatsApp</button>
                    </form>
                </div>
            `;
            return sendHtml(renderAdminLayout('WhatsApp', content, 'whatsapp'));
        }

        // 17. Telegram
        if (pathname === '/admin-panel/telegram') {
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs max-w-xl">
                    <h3 class="font-bold text-sm uppercase">Telegram Order Alert Bot</h3>
                    <p class="text-slate-500">Instant smartphone notifications for every new order placed.</p>
                </div>
            `;
            return sendHtml(renderAdminLayout('Telegram', content, 'telegram'));
        }

        // 18. Facebook Pixel
        if (pathname === '/admin-panel/pixel') {
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs max-w-xl">
                    <h3 class="font-bold text-sm uppercase">Facebook Meta Pixel Tracking</h3>
                    <p class="text-slate-500">Track conversion events and ad campaign performance.</p>
                </div>
            `;
            return sendHtml(renderAdminLayout('Facebook Pixel', content, 'pixel'));
        }

        // 19. Colors
        if (pathname === '/admin-panel/colors') {
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs max-w-xl">
                    <h3 class="font-bold text-sm uppercase">Brand Colors & Palette</h3>
                    <p class="text-slate-500">Configure theme highlights and buttons.</p>
                </div>
            `;
            return sendHtml(renderAdminLayout('Colors', content, 'colors'));
        }

        // 20. OTP System
        if (pathname === '/admin-panel/otp') {
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs max-w-xl">
                    <h3 class="font-bold text-sm uppercase">SMS OTP Verification System</h3>
                    <p class="text-slate-500">SMS Gateway provider and phone verification settings.</p>
                </div>
            `;
            return sendHtml(renderAdminLayout('OTP System', content, 'otp'));
        }

        // 21. SEO
        if (pathname === '/admin-panel/seo') {
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs max-w-xl">
                    <h3 class="font-bold text-sm uppercase">SEO & Google Meta</h3>
                    <p class="text-slate-500">Search ranking meta title and descriptions.</p>
                </div>
            `;
            return sendHtml(renderAdminLayout('SEO', content, 'seo'));
        }

        // 22. Settings
        if (pathname === '/admin-panel/settings' && isGet) {
            const s = getSettings();
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm max-w-xl space-y-4 text-xs">
                    <h3 class="font-bold text-sm uppercase">Site Settings</h3>
                    <form method="POST" action="/admin-panel/settings" class="space-y-3">
                        <div><label class="block font-bold">Store Name</label><input type="text" name="store_name" value="${s.store_name || ''}" class="w-full border rounded-xl px-3 py-2"></div>
                        <div><label class="block font-bold">Hotline Phone</label><input type="text" name="contact_phone" value="${s.contact_phone || ''}" class="w-full border rounded-xl px-3 py-2"></div>
                        <div><label class="block font-bold">WhatsApp Number</label><input type="text" name="whatsapp_number" value="${s.whatsapp_number || ''}" class="w-full border rounded-xl px-3 py-2"></div>
                        <button type="submit" class="px-6 py-2.5 bg-indigo-600 text-white font-bold rounded-xl shadow">Save Settings</button>
                    </form>
                </div>
            `;
            return sendHtml(renderAdminLayout('Settings', content, 'settings'));
        }

        if (pathname === '/admin-panel/settings' && method === 'POST') {
            const body = await parseBody(req);
            const stmt = db.prepare('REPLACE INTO settings (setting_key, setting_value) VALUES (?, ?)');
            for (const [k, v] of Object.entries(body)) stmt.run(k, String(v));
            return redirect('/admin-panel/settings');
        }

        // 23. Profile
        if (pathname === '/admin-panel/profile') {
            const content = `
                <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 text-xs max-w-xl">
                    <h3 class="font-bold text-sm uppercase">Admin Profile & Security</h3>
                    <p class="text-slate-500">Update admin credentials.</p>
                </div>
            `;
            return sendHtml(renderAdminLayout('Admin Profile', content, 'profile'));
        }
    }

    return sendHtml(renderLayout('Page Not Found', '<div class="max-w-md mx-auto px-4 py-20 text-center space-y-4"><h1 class="text-4xl font-bold">404</h1><p class="text-slate-500 text-xs">Page not found.</p><a href="/" class="px-6 py-2.5 bg-indigo-600 text-white font-bold rounded-xl text-xs inline-block">Return Home</a></div>', sessionData), 404);
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`OnlineBdMart Server running on http://0.0.0.0:${PORT}`);
});
