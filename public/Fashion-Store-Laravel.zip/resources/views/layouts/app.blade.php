<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', \App\Models\Setting::get('store_name', 'OnlineBdMart') . ' - Online Shopping Bangladesh')</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,600;0,700;1,600&display=swap" rel="stylesheet">

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        serif: ['"Playfair Display"', 'serif'],
                    },
                    colors: {
                        primary: {
                            50: '#eef2ff',
                            100: '#e0e7ff',
                            200: '#c7d2fe',
                            300: '#a5b4fc',
                            400: '#818cf8',
                            500: '#6366f1',
                            600: '#4f46e5',
                            700: '#4338ca',
                            800: '#3730a3',
                            900: '#312e81',
                            950: '#1e1b4b',
                        }
                    }
                }
            }
        }
    </script>

    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Alpine.js -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.13.5/dist/cdn.min.js"></script>

    <style>
        [x-cloak] { display: none !important; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #f1f5f9; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 9999px; }
        ::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 font-sans antialiased min-h-screen flex flex-col selection:bg-primary-600 selection:text-white" 
      x-data="mainApp()">

    @php
        $storeName = \App\Models\Setting::get('store_name', 'OnlineBdMart');
        $whatsapp = \App\Models\Setting::get('whatsapp_number', '01775153740');
        $phone = \App\Models\Setting::get('contact_phone', '01775153740');
        $tangailFee = \App\Models\Setting::get('delivery_charge_tangail', '50');
        $otherFee = \App\Models\Setting::get('delivery_charge_other', '150');
        $announcement = \App\Models\Setting::get('announcement_bar', 'Free Delivery Tangail ৳' . $tangailFee . ' | Others ৳' . $otherFee . ' • Free Shipping above ৳2000');
        $categories = \App\Models\Category::withCount('products')->get();
    @endphp

    <!-- 1. TOP BAR with Track Order, Hotline & Customer Sign In / Sign Up -->
    <div class="bg-slate-900 text-slate-300 text-xs py-2 px-4 border-b border-slate-800">
        <div class="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
            
            <!-- Left Promo Notice -->
            <div class="flex items-center gap-2 overflow-hidden text-xs">
                <span class="inline-flex items-center justify-center px-2 py-0.5 rounded text-[10px] font-black bg-primary-600 text-white tracking-wider uppercase">Hot</span>
                <p class="font-medium truncate">{{ $announcement }}</p>
            </div>

            <!-- Right: Track Order, Hotline, Sign In / Sign Up -->
            <div class="flex items-center gap-4 text-xs font-semibold text-slate-300">
                <!-- Track Order in Top Bar -->
                <a href="{{ route('order.track') }}" class="hover:text-primary-400 transition flex items-center gap-1.5 text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-500/30 px-3 py-1 rounded-full">
                    <i class="fas fa-truck-fast"></i> <span>Track Order</span>
                </a>

                <span class="text-slate-700">|</span>

                <a href="tel:{{ $phone }}" class="hover:text-white transition flex items-center gap-1">
                    <i class="fas fa-phone text-emerald-400"></i> {{ $phone }}
                </a>

                <span class="text-slate-700">|</span>

                @if(session('customer_id'))
                <a href="{{ route('account') }}" class="hover:text-primary-300 transition flex items-center gap-1 text-primary-400 font-bold">
                    <i class="fas fa-user-check"></i> {{ session('customer_name') }}
                </a>
                @else
                <div class="flex items-center gap-2">
                    <a href="{{ route('login') }}" class="hover:text-white transition flex items-center gap-1">
                        <i class="fas fa-arrow-right-to-bracket"></i> Sign In
                    </a>
                    <span class="text-slate-700">/</span>
                    <a href="{{ route('register') }}" class="hover:text-primary-400 transition text-primary-300 font-bold">
                        Sign Up
                    </a>
                </div>
                @endif
            </div>
        </div>
    </div>

    <!-- 2. MAIN HEADER (Brand Logo, Realtime Category Search, Wishlist & Cart Drawers) -->
    <header class="sticky top-0 z-40 bg-white shadow-sm border-b border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between gap-4 py-4">
                
                <!-- Mobile Menu Button & Brand Logo -->
                <div class="flex items-center gap-3">
                    <button type="button" @click="mobileMenuOpen = true" class="lg:hidden p-2 text-slate-700 hover:bg-slate-100 rounded-xl">
                        <i class="fas fa-bars-staggered text-xl"></i>
                    </button>

                    <a href="{{ route('home') }}" class="flex items-center gap-3 group">
                        <div class="w-11 h-11 rounded-xl bg-gradient-to-tr from-primary-600 via-indigo-600 to-cyan-500 flex items-center justify-center text-white text-xl shadow-md group-hover:scale-105 transition-transform">
                            <i class="fas fa-bag-shopping"></i>
                        </div>
                        <div>
                            <span class="text-xl sm:text-2xl font-black tracking-tight text-slate-900 leading-none block">
                                {{ strtoupper($storeName) }}
                            </span>
                            <span class="text-[10px] tracking-widest font-extrabold text-primary-600 uppercase block mt-0.5">Online Shopping BD</span>
                        </div>
                    </a>
                </div>

                <!-- Big Central Search Bar with Categories Select & Instant Realtime Dropdown -->
                <div class="hidden md:flex flex-1 max-w-2xl mx-4">
                    <form method="GET" action="{{ route('shop') }}" class="w-full flex items-center rounded-2xl border-2 border-primary-600 bg-white shadow-sm relative">
                        
                        <!-- Category Select -->
                        <div class="border-r border-slate-200 bg-slate-50 px-3 py-2.5 shrink-0 rounded-l-xl">
                            <select name="category" class="text-xs font-bold text-slate-700 bg-transparent outline-none cursor-pointer">
                                <option value="">All Categories</option>
                                @foreach($categories as $cat)
                                <option value="{{ $cat->slug }}" {{ request('category') === $cat->slug ? 'selected' : '' }}>{{ $cat->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <!-- Realtime AJAX Search Input -->
                        <div class="flex-1 relative">
                            <input type="text" 
                                   name="search"
                                   x-model="searchQuery"
                                   @input.debounce.250ms="fetchSuggestions()"
                                   @focus="if (suggestions.length > 0) suggestionsOpen = true"
                                   @click.away="suggestionsOpen = false"
                                   value="{{ request('search') }}"
                                   autocomplete="off"
                                   placeholder="Search products, watches, leather wallets, sunglasses, gadgets..." 
                                   class="w-full px-4 py-2.5 text-xs text-slate-800 outline-none font-medium">

                            <!-- Realtime Dropdown Results -->
                            <div x-show="suggestionsOpen && suggestions.length > 0" 
                                 x-cloak 
                                 class="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl shadow-2xl border border-slate-200 p-2 z-50 overflow-hidden divide-y divide-slate-100 max-h-96 overflow-y-auto">
                                <div class="px-3 py-1.5 flex items-center justify-between text-[10px] font-extrabold uppercase text-slate-400">
                                    <span>Instant Search Results</span>
                                    <span class="text-primary-600" x-text="suggestions.length + ' found'"></span>
                                </div>
                                <template x-for="item in suggestions" :key="item.id">
                                    <a :href="item.url" class="flex items-center gap-3 p-2.5 rounded-xl hover:bg-primary-50 transition group">
                                        <img :src="item.image" class="w-11 h-11 object-cover rounded-xl bg-slate-100 border shrink-0">
                                        <div class="flex-1 min-w-0">
                                            <p class="text-xs font-bold text-slate-800 truncate group-hover:text-primary-600" x-text="item.name"></p>
                                            <div class="flex items-center gap-2 mt-0.5">
                                                <span class="text-xs font-black text-primary-600" x-text="item.formatted_price"></span>
                                                <span class="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-1.5 py-0.2 rounded">In Stock</span>
                                            </div>
                                        </div>
                                        <i class="fas fa-chevron-right text-xs text-slate-300 group-hover:text-primary-500"></i>
                                    </a>
                                </template>
                            </div>
                        </div>

                        <!-- Search Button -->
                        <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white px-6 py-2.5 font-bold text-xs flex items-center gap-1.5 transition rounded-r-xl">
                            <i class="fas fa-search"></i> <span>Search</span>
                        </button>
                    </form>
                </div>

                <!-- Right Action Icons: Wishlist, Cart Drawer -->
                <div class="flex items-center gap-3 sm:gap-4">
                    <!-- Wishlist Drawer Trigger -->
                    <button type="button" 
                            @click="wishlistOpen = true" 
                            class="relative p-2.5 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-600 transition">
                        <i class="far fa-heart text-lg"></i>
                        <span class="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-black rounded-full h-4 min-w-[16px] px-1 flex items-center justify-center" 
                              x-show="wishlistCount > 0" 
                              x-text="wishlistCount">0</span>
                    </button>

                    <!-- Cart Drawer Trigger Button -->
                    <button type="button" 
                            @click="cartOpen = true" 
                            class="relative p-2 sm:px-4 sm:py-2.5 rounded-xl bg-primary-600 hover:bg-primary-700 text-white transition flex items-center gap-2.5 shadow-md shadow-primary-600/25">
                        <i class="fas fa-bag-shopping text-lg"></i>
                        <div class="hidden sm:block text-left text-xs leading-tight">
                            <span class="text-[10px] text-primary-200 block">My Bag</span>
                            <span class="font-black" x-text="formatCurrency(subtotal)">৳0.00</span>
                        </div>
                        <span class="hidden sm:flex bg-white/20 text-white text-[11px] font-extrabold rounded-full px-2 py-0.5 items-center justify-center" 
                              x-text="cartCount">
                            {{ count(session('cart', [])) }}
                        </span>
                    </button>
                </div>
            </div>

            <!-- Mobile Search Bar with Instant Suggestions -->
            <div class="pb-3 md:hidden relative">
                <form method="GET" action="{{ route('shop') }}" class="flex items-center rounded-xl border border-slate-300 bg-white overflow-hidden shadow-sm">
                    <input type="text" 
                           name="search" 
                           x-model="searchQuery"
                           @input.debounce.250ms="fetchSuggestions()"
                           @focus="if (suggestions.length > 0) suggestionsOpen = true"
                           placeholder="Search products..." 
                           class="flex-1 px-3 py-2 text-xs outline-none">
                    <button type="submit" class="bg-primary-600 text-white px-4 py-2 font-bold text-xs"><i class="fas fa-search"></i></button>
                </form>

                <div x-show="suggestionsOpen && suggestions.length > 0" 
                     x-cloak 
                     class="absolute left-0 right-0 top-full mt-1 bg-white rounded-xl shadow-2xl border p-2 z-50 max-h-60 overflow-y-auto divide-y">
                    <template x-for="item in suggestions" :key="item.id">
                        <a :href="item.url" class="flex items-center gap-2 p-2 hover:bg-slate-50 text-xs">
                            <img :src="item.image" class="w-8 h-8 object-cover rounded border">
                            <div class="flex-1 truncate"><p class="font-bold text-slate-800 truncate" x-text="item.name"></p><span class="text-primary-600 font-extrabold" x-text="item.formatted_price"></span></div>
                        </a>
                    </template>
                </div>
            </div>
        </div>

        <!-- 3. EXACT HEADER MENU (Home | Shop | Wholesale | Categories | Deals | Blog | Contact) -->
        <div class="hidden lg:block bg-slate-900 text-white border-t border-slate-800">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
                
                <!-- Main Nav Menu -->
                <nav class="flex items-center space-x-1 text-xs font-bold text-slate-200">
                    <a href="{{ route('home') }}" class="px-4 py-3.5 hover:text-primary-400 hover:bg-slate-800 transition {{ request()->routeIs('home') ? 'text-primary-400 bg-slate-800' : '' }}">
                        Home
                    </a>
                    <a href="{{ route('shop') }}" class="px-4 py-3.5 hover:text-primary-400 hover:bg-slate-800 transition {{ request()->routeIs('shop') && !request('category') ? 'text-primary-400 bg-slate-800' : '' }}">
                        Shop
                    </a>
                    <a href="{{ route('wholesale') }}" class="px-4 py-3.5 hover:text-amber-400 hover:bg-slate-800 transition text-amber-300 {{ request()->routeIs('wholesale') ? 'bg-slate-800 text-amber-400' : '' }}">
                        <i class="fas fa-boxes-stacked mr-1"></i> Wholesale
                    </a>
                    <a href="{{ route('categories') }}" class="px-4 py-3.5 hover:text-primary-400 hover:bg-slate-800 transition {{ request()->routeIs('categories') ? 'text-primary-400 bg-slate-800' : '' }}">
                        Categories
                    </a>
                    <a href="{{ route('deals') }}" class="px-4 py-3.5 hover:text-rose-400 hover:bg-slate-800 transition text-rose-300 {{ request()->routeIs('deals') ? 'bg-slate-800 text-rose-400' : '' }}">
                        <i class="fas fa-fire mr-1"></i> Deals
                    </a>
                    <a href="{{ route('blog.index') }}" class="px-4 py-3.5 hover:text-primary-400 hover:bg-slate-800 transition {{ request()->routeIs('blog*') ? 'text-primary-400 bg-slate-800' : '' }}">
                        Blog
                    </a>
                    <a href="{{ route('contact') }}" class="px-4 py-3.5 hover:text-primary-400 hover:bg-slate-800 transition {{ request()->routeIs('contact') ? 'text-primary-400 bg-slate-800' : '' }}">
                        Contact
                    </a>
                </nav>

                <!-- Right Hotline -->
                <div class="flex items-center gap-3 text-xs font-bold text-slate-300 py-3.5">
                    <a href="https://wa.me/88{{ $whatsapp }}" target="_blank" class="hover:text-emerald-400 transition flex items-center gap-1.5">
                        <i class="fab fa-whatsapp text-emerald-400 text-base"></i> Hotline: {{ $whatsapp }}
                    </a>
                </div>

            </div>
        </div>
    </header>

    <!-- Mobile Slide-out Menu -->
    <div x-show="mobileMenuOpen" x-cloak class="fixed inset-0 z-50 flex lg:hidden" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm" @click="mobileMenuOpen = false"></div>
        <div class="relative max-w-xs w-full bg-white h-full shadow-2xl flex flex-col justify-between py-6 px-6 overflow-y-auto" x-transition>
            <div>
                <div class="flex items-center justify-between pb-6 border-b border-slate-100">
                    <span class="font-extrabold text-lg text-slate-900">{{ $storeName }}</span>
                    <button type="button" @click="mobileMenuOpen = false" class="text-slate-400 p-1"><i class="fas fa-times text-xl"></i></button>
                </div>
                
                <div class="mt-6 space-y-1 text-xs font-bold">
                    <a href="{{ route('home') }}" class="block px-4 py-3 rounded-xl hover:bg-primary-50">🏠 Home</a>
                    <a href="{{ route('shop') }}" class="block px-4 py-3 rounded-xl hover:bg-primary-50">🛍️ Shop</a>
                    <a href="{{ route('wholesale') }}" class="block px-4 py-3 rounded-xl text-amber-700 bg-amber-50">📦 Wholesale / B2B</a>
                    <a href="{{ route('categories') }}" class="block px-4 py-3 rounded-xl hover:bg-primary-50">🏷️ Categories</a>
                    <a href="{{ route('deals') }}" class="block px-4 py-3 rounded-xl text-rose-600 hover:bg-rose-50">🔥 Hot Deals</a>
                    <a href="{{ route('blog.index') }}" class="block px-4 py-3 rounded-xl hover:bg-primary-50">📰 Blog & Guides</a>
                    <a href="{{ route('contact') }}" class="block px-4 py-3 rounded-xl hover:bg-primary-50">📞 Contact Us</a>
                    <a href="{{ route('order.track') }}" class="block px-4 py-3 rounded-xl text-emerald-700 bg-emerald-50">🚚 Track Order</a>
                </div>
            </div>

            <div class="pt-6 border-t border-slate-100 space-y-2">
                @if(session('customer_id'))
                <a href="{{ route('account') }}" class="block w-full py-2.5 bg-slate-100 text-slate-800 font-bold rounded-xl text-xs text-center">My Account</a>
                @else
                <a href="{{ route('login') }}" class="block w-full py-2.5 bg-primary-600 text-white font-bold rounded-xl text-xs text-center">Sign In / Sign Up</a>
                @endif
                <a href="https://wa.me/88{{ $whatsapp }}" target="_blank" class="flex items-center justify-center gap-2 w-full py-2.5 bg-emerald-500 text-white font-bold rounded-xl text-xs shadow">
                    <i class="fab fa-whatsapp text-sm"></i> WhatsApp Support
                </a>
            </div>
        </div>
    </div>

    <!-- Sliding Cart Drawer -->
    <div x-show="cartOpen" x-cloak class="fixed inset-0 z-50 overflow-hidden">
        <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" @click="cartOpen = false"></div>
        <div class="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <div class="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between" x-transition>
                <div class="p-5 border-b flex items-center justify-between bg-slate-50">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-bag-shopping text-primary-600"></i>
                        <h2 class="text-base font-extrabold text-slate-900">Your Cart (<span x-text="cartCount">{{ count(session('cart', [])) }}</span>)</h2>
                    </div>
                    <button type="button" @click="cartOpen = false" class="p-2 text-slate-400 hover:text-slate-600"><i class="fas fa-times"></i></button>
                </div>

                <div class="flex-1 overflow-y-auto p-5 space-y-4">
                    <template x-if="items.length === 0">
                        <div class="h-full flex flex-col items-center justify-center text-center py-12">
                            <i class="fas fa-shopping-basket text-slate-200 text-5xl mb-4"></i>
                            <h3 class="font-bold text-slate-800">Your Cart is Empty</h3>
                            <a href="{{ route('shop') }}" @click="cartOpen = false" class="mt-4 px-6 py-2.5 bg-primary-600 text-white font-bold rounded-xl text-xs shadow">Start Shopping</a>
                        </div>
                    </template>

                    <template x-for="item in items" :key="item.id">
                        <div class="flex gap-4 p-3 rounded-2xl bg-slate-50 border border-slate-100">
                            <img :src="'/' + item.image" class="w-16 h-16 object-cover rounded-xl bg-white border shrink-0">
                            <div class="flex-1 min-w-0 flex flex-col justify-between">
                                <div>
                                    <div class="flex items-start justify-between gap-2">
                                        <h4 class="text-xs font-bold text-slate-800 line-clamp-1" x-text="item.name"></h4>
                                        <button @click="removeItem(item.id)" class="text-slate-300 hover:text-rose-500"><i class="fas fa-trash-can text-xs"></i></button>
                                    </div>
                                    <p class="text-xs font-bold text-primary-600" x-text="formatCurrency(item.price)"></p>
                                </div>
                                <div class="flex items-center justify-between mt-2">
                                    <div class="flex items-center border rounded-lg bg-white">
                                        <button @click="updateQty(item.id, item.quantity - 1)" class="w-6 h-6 flex items-center justify-center text-xs">-</button>
                                        <span class="w-8 text-center text-xs font-bold" x-text="item.quantity"></span>
                                        <button @click="updateQty(item.id, item.quantity + 1)" class="w-6 h-6 flex items-center justify-center text-xs">+</button>
                                    </div>
                                    <span class="text-xs font-extrabold" x-text="formatCurrency(item.price * item.quantity)"></span>
                                </div>
                            </div>
                        </div>
                    </template>
                </div>

                <div class="p-5 border-t bg-slate-50 space-y-3" x-show="items.length > 0">
                    <div class="flex justify-between text-sm font-extrabold text-slate-900">
                        <span>Subtotal:</span>
                        <span class="text-primary-600" x-text="formatCurrency(subtotal)"></span>
                    </div>
                    <div class="grid grid-cols-2 gap-2.5">
                        <a href="{{ route('cart.index') }}" @click="cartOpen = false" class="py-3 px-4 bg-white border font-bold rounded-xl text-xs text-center hover:bg-slate-100">View Cart</a>
                        <a href="{{ route('checkout.index') }}" class="py-3 px-4 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-xl text-xs text-center shadow">Checkout &rarr;</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Wishlist Drawer -->
    <div x-show="wishlistOpen" x-cloak class="fixed inset-0 z-50 overflow-hidden">
        <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" @click="wishlistOpen = false"></div>
        <div class="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <div class="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between" x-transition>
                <div class="p-5 border-b flex items-center justify-between bg-slate-50">
                    <div class="flex items-center gap-2 text-rose-600 font-bold">
                        <i class="fas fa-heart"></i>
                        <h2 class="text-base text-slate-900">Your Wishlist (<span x-text="wishlistCount">0</span>)</h2>
                    </div>
                    <button type="button" @click="wishlistOpen = false" class="p-2 text-slate-400 hover:text-slate-600"><i class="fas fa-times"></i></button>
                </div>

                <div class="flex-1 overflow-y-auto p-5 space-y-4">
                    <template x-if="wishlist.length === 0">
                        <div class="h-full flex flex-col items-center justify-center text-center py-12">
                            <i class="far fa-heart text-slate-200 text-5xl mb-4"></i>
                            <h3 class="font-bold text-slate-800">Your Wishlist is Empty</h3>
                            <a href="{{ route('shop') }}" @click="wishlistOpen = false" class="mt-4 px-6 py-2.5 bg-primary-600 text-white font-bold rounded-xl text-xs">Browse Items</a>
                        </div>
                    </template>

                    <template x-for="item in wishlist" :key="item.id">
                        <div class="flex gap-4 p-3 rounded-2xl bg-slate-50 border items-center justify-between">
                            <div class="flex items-center gap-3">
                                <img :src="'/' + item.image" class="w-14 h-14 object-cover rounded-xl bg-white border shrink-0">
                                <div>
                                    <h4 class="text-xs font-bold text-slate-800 line-clamp-1" x-text="item.name"></h4>
                                    <p class="text-xs font-bold text-primary-600 mt-0.5" x-text="formatCurrency(item.price)"></p>
                                </div>
                            </div>
                            <div class="flex items-center gap-2">
                                <button @click="addToCart(item.id); removeFromWishlist(item.id)" class="px-3 py-1.5 bg-slate-900 text-white text-[11px] font-bold rounded-lg">Add to Cart</button>
                                <button @click="removeFromWishlist(item.id)" class="text-slate-300 hover:text-rose-500"><i class="fas fa-trash-can text-xs"></i></button>
                            </div>
                        </div>
                    </template>
                </div>

                <div class="p-5 border-t bg-slate-50">
                    <a href="{{ route('shop') }}" @click="wishlistOpen = false" class="block w-full py-3 bg-slate-900 text-white font-bold rounded-xl text-xs text-center">Continue Shopping</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content Yield -->
    <main class="flex-1">
        @yield('content')
    </main>

    <!-- Mobile Bottom Sticky Bar -->
    <div class="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-6 py-2.5 flex items-center justify-between text-[10px] font-bold text-slate-600 shadow-xl">
        <a href="{{ route('home') }}" class="flex flex-col items-center gap-1 {{ request()->routeIs('home') ? 'text-primary-600' : '' }}">
            <i class="fas fa-house text-base"></i> <span>Home</span>
        </a>
        <a href="{{ route('shop') }}" class="flex flex-col items-center gap-1 {{ request()->routeIs('shop') ? 'text-primary-600' : '' }}">
            <i class="fas fa-boxes-stacked text-base"></i> <span>Shop</span>
        </a>
        <a href="{{ route('wholesale') }}" class="flex flex-col items-center gap-1 text-amber-600 {{ request()->routeIs('wholesale') ? 'text-amber-700 font-extrabold' : '' }}">
            <i class="fas fa-boxes-packing text-base"></i> <span>Wholesale</span>
        </a>
        <a href="{{ route('order.track') }}" class="flex flex-col items-center gap-1 text-emerald-600 font-extrabold">
            <i class="fas fa-truck-fast text-base"></i> <span>Track</span>
        </a>
        <button type="button" @click="cartOpen = true" class="flex flex-col items-center gap-1 relative text-primary-600">
            <i class="fas fa-bag-shopping text-base"></i> <span>Bag</span>
            <span class="absolute -top-1.5 right-1 bg-amber-400 text-slate-950 text-[9px] font-black rounded-full h-3.5 min-w-[14px] px-0.5 flex items-center justify-center" x-text="cartCount"></span>
        </button>
    </div>

    <!-- Floating WhatsApp Support Button -->
    <a href="https://wa.me/88{{ $whatsapp }}?text={{ urlencode('Hello! I have a question about OnlineBdMart.') }}" 
       target="_blank" 
       title="Chat on WhatsApp"
       class="fixed bottom-16 lg:bottom-6 right-6 z-30 w-14 h-14 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-all duration-300">
        <i class="fab fa-whatsapp text-2xl"></i>
    </a>

    <!-- Toast Container -->
    <div id="toast-container" class="fixed bottom-20 lg:bottom-6 left-6 z-50 flex flex-col gap-2 max-w-sm"></div>

    <!-- Luxury Footer -->
    <footer class="bg-slate-950 text-white pt-16 pb-20 lg:pb-12 border-t border-slate-800">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-slate-800">
                <div class="space-y-4">
                    <h3 class="text-xl font-extrabold">{{ $storeName }}</h3>
                    <p class="text-slate-400 text-xs sm:text-sm leading-relaxed">Your premier destination for wholesale & retail fashion accessories and electronics in Bangladesh.</p>
                    <p class="text-xs text-slate-500">{{ \App\Models\Setting::get('store_address', 'Tangail, Bangladesh') }}</p>
                </div>
                <div>
                    <h4 class="font-bold text-xs uppercase tracking-wider text-slate-200 mb-4">Quick Navigation</h4>
                    <ul class="space-y-2 text-xs text-slate-400">
                        <li><a href="{{ route('home') }}" class="hover:text-white">Home</a></li>
                        <li><a href="{{ route('shop') }}" class="hover:text-white">All Products</a></li>
                        <li><a href="{{ route('wholesale') }}" class="hover:text-white text-amber-400">Wholesale / B2B Rate</a></li>
                        <li><a href="{{ route('categories') }}" class="hover:text-white">Categories</a></li>
                        <li><a href="{{ route('deals') }}" class="hover:text-white text-rose-400">Hot Deals %</a></li>
                        <li><a href="{{ route('blog.index') }}" class="hover:text-white">Buying Guides</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-bold text-xs uppercase tracking-wider text-slate-200 mb-4">Customer Services</h4>
                    <ul class="space-y-2 text-xs text-slate-400 font-semibold">
                        <li><a href="{{ route('order.track') }}" class="text-emerald-400 hover:underline">📦 Track Your Order</a></li>
                        <li><a href="{{ route('contact') }}" class="hover:text-white">📞 Contact & Help Center</a></li>
                        <li><a href="{{ route('cart.index') }}" class="hover:text-white">🛒 View Shopping Cart</a></li>
                        <li><a href="{{ route('checkout.index') }}" class="hover:text-white">⚡ Express Checkout</a></li>
                        <li><a href="/admin-panel/login" class="hover:text-white text-slate-500">🔐 Admin Portal</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-bold text-xs uppercase tracking-wider text-slate-200 mb-4">Accepted Payments</h4>
                    <div class="flex flex-wrap gap-2 text-xs text-slate-300">
                        <span class="px-2.5 py-1 bg-slate-900 rounded font-bold text-emerald-400">Cash on Delivery</span>
                        <span class="px-2.5 py-1 bg-slate-900 rounded font-bold text-pink-400">bKash</span>
                        <span class="px-2.5 py-1 bg-slate-900 rounded font-bold text-orange-400">Nagad</span>
                        <span class="px-2.5 py-1 bg-slate-900 rounded font-bold text-purple-400">Rocket</span>
                    </div>
                </div>
            </div>
            <div class="pt-8 text-center text-xs text-slate-500">
                &copy; {{ date('Y') }} {{ $storeName }} • Online Shopping Bangladesh. Built with Laravel 11 & Tailwind CSS.
            </div>
        </div>
    </footer>

    <!-- Global App JS -->
    <script>
        function mainApp() {
            return {
                mobileMenuOpen: false,
                cartOpen: false,
                wishlistOpen: false,
                searchQuery: '',
                suggestionsOpen: false,
                suggestions: [],
                cartCount: {{ count(session('cart', [])) }},
                subtotal: {{ array_sum(array_map(fn($i) => $i['price'] * $i['quantity'], session('cart', []))) }},
                items: @json(array_values(session('cart', []))),
                wishlist: JSON.parse(localStorage.getItem('user_wishlist') || '[]'),

                get wishlistCount() { return this.wishlist.length; },

                formatCurrency(amt) {
                    return '৳' + Number(amt || 0).toLocaleString('en-BD', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                },

                fetchSuggestions() {
                    if (this.searchQuery.length < 2) {
                        this.suggestions = [];
                        this.suggestionsOpen = false;
                        return;
                    }
                    fetch('/search-suggestions?q=' + encodeURIComponent(this.searchQuery))
                        .then(r => r.json())
                        .then(d => { this.suggestions = d; this.suggestionsOpen = true; });
                },

                addToCart(productId, quantity = 1) {
                    const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
                    fetch('/cart/add', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': token, 'Accept': 'application/json' },
                        body: JSON.stringify({ product_id: productId, quantity: quantity })
                    })
                    .then(r => r.json())
                    .then(d => {
                        if (d.success) {
                            this.cartCount = d.count;
                            this.subtotal = d.subtotal;
                            this.items = d.items;
                            this.cartOpen = true;
                            showToast('Added to your bag!', 'success');
                        }
                    });
                },

                updateQty(productId, qty) {
                    const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
                    fetch('/cart/update', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': token, 'Accept': 'application/json' },
                        body: JSON.stringify({ product_id: productId, quantity: qty })
                    })
                    .then(r => r.json())
                    .then(d => {
                        if (d.success) {
                            this.cartCount = d.count;
                            this.subtotal = d.subtotal;
                            if (qty <= 0) {
                                this.items = this.items.filter(i => i.id !== productId);
                            } else {
                                const found = this.items.find(i => i.id === productId);
                                if (found) found.quantity = qty;
                            }
                        }
                    });
                },

                removeItem(productId) {
                    const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
                    fetch('/cart/remove', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': token, 'Accept': 'application/json' },
                        body: JSON.stringify({ product_id: productId })
                    })
                    .then(r => r.json())
                    .then(d => {
                        if (d.success) {
                            this.cartCount = d.count;
                            this.subtotal = d.subtotal;
                            this.items = this.items.filter(i => i.id !== productId);
                            showToast('Item removed from cart.', 'info');
                        }
                    });
                },

                toggleWishlist(prod) {
                    const exists = this.wishlist.some(i => i.id === prod.id);
                    if (exists) {
                        this.wishlist = this.wishlist.filter(i => i.id !== prod.id);
                        showToast('Removed from wishlist.', 'info');
                    } else {
                        this.wishlist.push(prod);
                        showToast('Saved to wishlist!', 'success');
                    }
                    localStorage.setItem('user_wishlist', JSON.stringify(this.wishlist));
                },

                removeFromWishlist(pid) {
                    this.wishlist = this.wishlist.filter(i => i.id !== pid);
                    localStorage.setItem('user_wishlist', JSON.stringify(this.wishlist));
                },

                isInWishlist(pid) {
                    return this.wishlist.some(i => i.id === pid);
                }
            }
        }

        function showToast(message, type = 'success') {
            const container = document.getElementById('toast-container');
            if (!container) return;

            const toast = document.createElement('div');
            const bgClass = type === 'success' ? 'bg-slate-900 text-white border-emerald-500' : 'bg-slate-900 text-white border-primary-500';
            const icon = type === 'success' ? 'fa-circle-check text-emerald-400' : 'fa-circle-info text-primary-400';

            toast.className = `flex items-center gap-3 px-4 py-3 rounded-2xl shadow-2xl border-l-4 text-xs font-semibold ${bgClass}`;
            toast.innerHTML = `<i class="fas ${icon} text-base"></i><span class="flex-1">${message}</span>`;

            container.appendChild(toast);
            setTimeout(() => { toast.remove(); }, 3500);
        }
    </script>

    @stack('scripts')
</body>
</html>
